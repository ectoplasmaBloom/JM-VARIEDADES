# Créditos das imagens de exemplo

Fotos usadas pelo seed do banco (`prisma/seed.ts`) da JM VARIEDADES, obtidas via [Openverse](https://openverse.org).
Todas estão em **domínio público (CC0 / Public Domain Mark)**: uso livre, inclusive comercial, sem obrigação de crédito.
Mesmo assim, registramos a autoria abaixo. Logotipos de marcas que aparecem nas fotos pertencem aos seus titulares.

| Arquivo | Produto | Autor | Fonte | Licença |
|---|---|---|---|---|
| `smartphone-galaxy-a55-128gb-5g-1.jpg` | Smartphone Galaxy A55 128GB 5G | pixellaphoto | [flickr](https://www.flickr.com/photos/137643065@N06/24217686692) | CC0 1.0 (domínio público) |
| `smartphone-galaxy-a55-128gb-5g-2.jpg` | Smartphone Galaxy A55 128GB 5G | Negative Space | [stocksnap](https://stocksnap.io/photo/smartphone-mobile-IU6HNPC2NT) | CC0 1.0 (domínio público) |
| `smartphone-galaxy-a55-128gb-5g-3.jpg` | Smartphone Galaxy A55 128GB 5G | StockyPics | [flickr](https://www.flickr.com/photos/135371437@N04/22389367255) | CC0 1.0 (domínio público) |
| `fone-de-ouvido-bluetooth-com-cancelamento-de-ruido-1.jpg` | Fone de Ouvido Bluetooth com Cancelamento de Ruído | Abdulla Al Muhairi | [flickr](https://www.flickr.com/photos/57866029@N00/52459692877) | CC0 1.0 (domínio público) |
| `fone-de-ouvido-bluetooth-com-cancelamento-de-ruido-2.jpg` | Fone de Ouvido Bluetooth com Cancelamento de Ruído | Image Catalog | [flickr](https://www.flickr.com/photos/132795455@N08/22921682035) | CC0 1.0 (domínio público) |
| `fone-de-ouvido-bluetooth-com-cancelamento-de-ruido-3.jpg` | Fone de Ouvido Bluetooth com Cancelamento de Ruído | Burst | [stocksnap](https://stocksnap.io/photo/woman-headphones-NOLZXJLYKF) | CC0 1.0 (domínio público) |
| `smartwatch-fitness-com-gps-e-monitor-cardiaco-1.jpg` | Smartwatch Fitness com GPS e Monitor Cardíaco | 50Fish | [stocksnap](https://stocksnap.io/photo/smartwatch-gps-XW2IM1GSYM) | CC0 1.0 (domínio público) |
| `smartwatch-fitness-com-gps-e-monitor-cardiaco-2.jpg` | Smartwatch Fitness com GPS e Monitor Cardíaco | Design by Matt | [stocksnap](https://stocksnap.io/photo/smart-watch-HN5PDS7HLL) | CC0 1.0 (domínio público) |
| `smartwatch-fitness-com-gps-e-monitor-cardiaco-3.jpg` | Smartwatch Fitness com GPS e Monitor Cardíaco | Desconhecido | [rawpixel](https://www.rawpixel.com/image/5921716/photo-image-background-public-domain-blue) | CC0 1.0 (domínio público) |
| `caixa-de-som-portatil-a-prova-d-agua-20w-1.jpg` | Caixa de Som Portátil à Prova d'Água 20W | Desconhecido | [rawpixel](https://www.rawpixel.com/image/11524244/mini-black-bluetooth-speaker) | CC0 1.0 (domínio público) |
| `caixa-de-som-portatil-a-prova-d-agua-20w-2.jpg` | Caixa de Som Portátil à Prova d'Água 20W | Desconhecido | [rawpixel](https://www.rawpixel.com/image/5915300/image-background-public-domain-technology) | CC0 1.0 (domínio público) |
| `caixa-de-som-portatil-a-prova-d-agua-20w-3.jpg` | Caixa de Som Portátil à Prova d'Água 20W | Desconhecido | [rawpixel](https://www.rawpixel.com/image/5919265/photo-image-white-background-phone-public-domain) | CC0 1.0 (domínio público) |
| `notebook-ultrafino-14-16gb-ram-ssd-512gb-1.jpg` | Notebook Ultrafino 14" 16GB RAM SSD 512GB | Negative Space | [stocksnap](https://stocksnap.io/photo/macbook-laptop-UNB7V2H5L4) | CC0 1.0 (domínio público) |
| `notebook-ultrafino-14-16gb-ram-ssd-512gb-2.jpg` | Notebook Ultrafino 14" 16GB RAM SSD 512GB | Lia Leslie | [stocksnap](https://stocksnap.io/photo/macbook-laptop-DWLWL9USBG) | CC0 1.0 (domínio público) |
| `notebook-ultrafino-14-16gb-ram-ssd-512gb-3.jpg` | Notebook Ultrafino 14" 16GB RAM SSD 512GB | Image Catalog | [flickr](https://www.flickr.com/photos/132795455@N08/17652700524) | CC0 1.0 (domínio público) |
| `teclado-mecanico-rgb-switch-brown-abnt2-1.jpg` | Teclado Mecânico RGB Switch Brown ABNT2 | Kiwithing | [flickr](https://www.flickr.com/photos/78555032@N00/5080593410) | CC0 1.0 (domínio público) |
| `teclado-mecanico-rgb-switch-brown-abnt2-2.jpg` | Teclado Mecânico RGB Switch Brown ABNT2 | Image Catalog | [flickr](https://www.flickr.com/photos/132795455@N08/17596421283) | CC0 1.0 (domínio público) |
| `teclado-mecanico-rgb-switch-brown-abnt2-3.jpg` | Teclado Mecânico RGB Switch Brown ABNT2 | Image Catalog | [flickr](https://www.flickr.com/photos/132795455@N08/17872393499) | CC0 1.0 (domínio público) |
| `mouse-sem-fio-ergonomico-4000-dpi-1.jpg` | Mouse Sem Fio Ergonômico 4000 DPI | Design by Matt | [stocksnap](https://stocksnap.io/photo/home-office-QUU0AQABSN) | CC0 1.0 (domínio público) |
| `mouse-sem-fio-ergonomico-4000-dpi-2.jpg` | Mouse Sem Fio Ergonômico 4000 DPI | Bridget Braun | [stocksnap](https://stocksnap.io/photo/iphone-keyboard-R7GVMRJWW9) | CC0 1.0 (domínio público) |
| `mouse-sem-fio-ergonomico-4000-dpi-3.jpg` | Mouse Sem Fio Ergonômico 4000 DPI | %u0141ukasz%20Popardowski | [stocksnap](https://stocksnap.io/photo/notebook-notepad-816KPMNUS2) | CC0 1.0 (domínio público) |
| `monitor-27-ips-qhd-75hz-1.jpg` | Monitor 27" IPS QHD 75Hz | personalgraphic.official | [flickr](https://www.flickr.com/photos/198895458@N04/53097628210) | CC0 1.0 (domínio público) |
| `monitor-27-ips-qhd-75hz-2.jpg` | Monitor 27" IPS QHD 75Hz | Tran Mau Tri Tam | [stocksnap](https://stocksnap.io/photo/computer-monitors-SLZRDLFT96) | CC0 1.0 (domínio público) |
| `air-fryer-4l-digital-1500w-1.jpg` | Air Fryer 4L Digital 1500W | Juhele_CZ | [flickr](https://www.flickr.com/photos/96541566@N06/54232617650) | CC0 1.0 (domínio público) |
| `jogo-de-panelas-antiaderente-5-pecas-1.jpg` | Jogo de Panelas Antiaderente 5 Peças | Desconhecido | [rawpixel](https://www.rawpixel.com/image/5970358/streaming-cooking-pot) | CC0 1.0 (domínio público) |
| `jogo-de-panelas-antiaderente-5-pecas-2.jpg` | Jogo de Panelas Antiaderente 5 Peças | Desconhecido | [rawpixel](https://www.rawpixel.com/image/5903450/photo-image-public-domain-smoke-kitchen) | CC0 1.0 (domínio público) |
| `cafeteira-eletrica-programavel-30-xicaras-1.jpg` | Cafeteira Elétrica Programável 30 Xícaras | Desconhecido | [rawpixel](https://www.rawpixel.com/image/3283223/free-photo-image-coffee-maker-banister) | CC0 1.0 (domínio público) |
| `cafeteira-eletrica-programavel-30-xicaras-2.jpg` | Cafeteira Elétrica Programável 30 Xícaras | andrew welch | [stocksnap](https://stocksnap.io/photo/coffee-maker-H8G7YBNYE0) | CC0 1.0 (domínio público) |
| `cafeteira-eletrica-programavel-30-xicaras-3.jpg` | Cafeteira Elétrica Programável 30 Xícaras | pixellaphoto | [flickr](https://www.flickr.com/photos/137643065@N06/23697054474) | CC0 1.0 (domínio público) |
| `kit-halteres-ajustaveis-20kg-1.jpg` | Kit Halteres Ajustáveis 20kg | Desconhecido | [rawpixel](https://www.rawpixel.com/image/5927274/photo-image-public-domain-free-workout) | CC0 1.0 (domínio público) |
| `kit-halteres-ajustaveis-20kg-2.jpg` | Kit Halteres Ajustáveis 20kg | Kristin Hardwick | [stocksnap](https://stocksnap.io/photo/sneakers-weights-DAVLOF8C3R) | CC0 1.0 (domínio público) |
| `kit-halteres-ajustaveis-20kg-3.jpg` | Kit Halteres Ajustáveis 20kg | %u0141ukasz%20Popardowski | [stocksnap](https://stocksnap.io/photo/weights-fitness-3H89EH3WIJ) | CC0 1.0 (domínio público) |
| `tapete-de-yoga-antiderrapante-6mm-1.jpg` | Tapete de Yoga Antiderrapante 6mm | JESHOOTS.com | [stocksnap](https://stocksnap.io/photo/woman-yoga-O5USQD0F3M) | CC0 1.0 (domínio público) |
| `tapete-de-yoga-antiderrapante-6mm-2.jpg` | Tapete de Yoga Antiderrapante 6mm | Matthew Henry | [stocksnap](https://stocksnap.io/photo/people-woman-AYWO7QN7K7) | CC0 1.0 (domínio público) |
| `tapete-de-yoga-antiderrapante-6mm-3.jpg` | Tapete de Yoga Antiderrapante 6mm | Desconhecido | [rawpixel](https://www.rawpixel.com/image/11515776/rolled-teal-yoga-mat-its-side) | CC0 1.0 (domínio público) |
| `camiseta-dry-fit-masculina-kit-com-3-1.jpg` | Camiseta Dry Fit Masculina Kit com 3 | Desconhecido | [rawpixel](https://www.rawpixel.com/image/11515804/t-shirts-hanging-wooden-hangers) | CC0 1.0 (domínio público) |
| `camiseta-dry-fit-masculina-kit-com-3-2.jpg` | Camiseta Dry Fit Masculina Kit com 3 | Desconhecido | [rawpixel](https://www.rawpixel.com/image/11515803/stack-folded-t-shirts) | CC0 1.0 (domínio público) |
| `camiseta-dry-fit-masculina-kit-com-3-3.jpg` | Camiseta Dry Fit Masculina Kit com 3 | Desconhecido | [rawpixel](https://www.rawpixel.com/image/5975415/photo-image-public-domain-t-shirts-fashion) | CC0 1.0 (domínio público) |
| `tenis-de-corrida-amortecimento-leve-1.jpg` | Tênis de Corrida Amortecimento Leve | JESHOOTS.com | [stocksnap](https://stocksnap.io/photo/running-shoes-645GI8G1W4) | CC0 1.0 (domínio público) |
| `tenis-de-corrida-amortecimento-leve-2.jpg` | Tênis de Corrida Amortecimento Leve | Desconhecido | [rawpixel](https://www.rawpixel.com/image/6042118/photo-image-public-domain-black-person) | CC0 1.0 (domínio público) |
| `tenis-de-corrida-amortecimento-leve-3.jpg` | Tênis de Corrida Amortecimento Leve | Redd Angelo | [stocksnap](https://stocksnap.io/photo/nike-sneakers-53ZL5GR6DC) | CC0 1.0 (domínio público) |
| `livro-arquitetura-limpa-robert-c-martin-1.jpg` | Livro: Arquitetura Limpa — Robert C. Martin | freestocks.org | [flickr](https://www.flickr.com/photos/135396164@N05/26421751605) | CC0 1.0 (domínio público) |
| `livro-arquitetura-limpa-robert-c-martin-2.jpg` | Livro: Arquitetura Limpa — Robert C. Martin | Matt Bango | [stocksnap](https://stocksnap.io/photo/open-books-HECYA5SP1L) | CC0 1.0 (domínio público) |
| `livro-domain-driven-design-eric-evans-1.jpg` | Livro: Domain-Driven Design — Eric Evans | Desconhecido | [rawpixel](https://www.rawpixel.com/image/3304480/free-photo-image-cc0-creative-commons) | CC0 1.0 (domínio público) |
| `livro-domain-driven-design-eric-evans-2.jpg` | Livro: Domain-Driven Design — Eric Evans | Desconhecido | [rawpixel](https://www.rawpixel.com/image/6027566/photo-image-book-public-domain-children) | CC0 1.0 (domínio público) |
| `kit-4-potes-hermeticos-de-vidro-1.jpg` | Kit 4 Potes Herméticos de Vidro | Suzy Hazelwood | [stocksnap](https://stocksnap.io/photo/herbs-parsley-XVIICAUSKR) | CC0 1.0 (domínio público) |
| `kit-4-potes-hermeticos-de-vidro-2.jpg` | Kit 4 Potes Herméticos de Vidro | Desconhecido | [rawpixel](https://www.rawpixel.com/image/5910925/aniseed-jar-free-public-domain-cc0-image) | CC0 1.0 (domínio público) |
| `kit-4-potes-hermeticos-de-vidro-3.jpg` | Kit 4 Potes Herméticos de Vidro | Caner Arıcan | [stocksnap](https://stocksnap.io/photo/glass-jar-1BKJSJJXC8) | CC0 1.0 (domínio público) |
| `vela-aromatica-em-copo-de-vidro-200g-1.jpg` | Vela Aromática em Copo de Vidro 200g | Desconhecido | [rawpixel](https://www.rawpixel.com/image/5918464/photo-image-background-christmas-public-domain) | CC0 1.0 (domínio público) |
| `vela-aromatica-em-copo-de-vidro-200g-2.jpg` | Vela Aromática em Copo de Vidro 200g | Desconhecido | [rawpixel](https://www.rawpixel.com/image/5918405/image-background-christmas-public-domain) | CC0 1.0 (domínio público) |
| `vela-aromatica-em-copo-de-vidro-200g-3.jpg` | Vela Aromática em Copo de Vidro 200g | Desconhecido | [rawpixel](https://www.rawpixel.com/image/5918468/image-public-domain-table-white) | CC0 1.0 (domínio público) |
| `vaso-de-vidro-para-flores-1.jpg` | Vaso de Vidro para Flores | Kelly Ishmael | [stocksnap](https://stocksnap.io/photo/flower-vase-VMRKBKSM2Q) | CC0 1.0 (domínio público) |
| `vaso-de-vidro-para-flores-2.jpg` | Vaso de Vidro para Flores | PICSELI | [stocksnap](https://stocksnap.io/photo/flower-vase-TKT8BUD2H6) | CC0 1.0 (domínio público) |
| `luminaria-de-mesa-articulada-1.jpg` | Luminária de Mesa Articulada | Desconhecido | [rawpixel](https://www.rawpixel.com/image/6035614/table-lamp-free-public-domain-cc0-image) | CC0 1.0 (domínio público) |
| `luminaria-de-mesa-articulada-2.jpg` | Luminária de Mesa Articulada | Desconhecido | [rawpixel](https://www.rawpixel.com/image/6031856/table-lamp-free-public-domain-cc0-image) | CC0 1.0 (domínio público) |
| `perfume-feminino-floral-100ml-1.jpg` | Perfume Feminino Floral 100ml | Desconhecido | [rawpixel](https://www.rawpixel.com/image/6113206/photo-image-public-domain-pink-beauty) | CC0 1.0 (domínio público) |
| `perfume-feminino-floral-100ml-2.jpg` | Perfume Feminino Floral 100ml | Desconhecido | [rawpixel](https://www.rawpixel.com/image/6033978/perfume-free-public-domain-cc0-photo) | CC0 1.0 (domínio público) |
| `perfume-feminino-floral-100ml-3.jpg` | Perfume Feminino Floral 100ml | Desconhecido | [rawpixel](https://www.rawpixel.com/image/6033727/photo-image-flower-public-domain-plant) | CC0 1.0 (domínio público) |
| `kit-pinceis-de-maquiagem-12-pecas-1.jpg` | Kit Pincéis de Maquiagem 12 Peças | Freestocks.org | [stocksnap](https://stocksnap.io/photo/makeup-brush-PZ0Z7K0JRR) | CC0 1.0 (domínio público) |
| `kit-pinceis-de-maquiagem-12-pecas-2.jpg` | Kit Pincéis de Maquiagem 12 Peças | Freestocks.org | [stocksnap](https://stocksnap.io/photo/makeup-brush-EE2H5SKEPA) | CC0 1.0 (domínio público) |
| `kit-pinceis-de-maquiagem-12-pecas-3.jpg` | Kit Pincéis de Maquiagem 12 Peças | Pawel Kadysz | [stocksnap](https://stocksnap.io/photo/makeup-brush-IJSBS0EFPO) | CC0 1.0 (domínio público) |
| `kit-skincare-hidratacao-facial-3-passos-1.jpg` | Kit Skincare Hidratação Facial 3 Passos | Authentic Stock | [stocksnap](https://stocksnap.io/photo/woman-skin-VEP8AYJMNI) | CC0 1.0 (domínio público) |
| `kit-skincare-hidratacao-facial-3-passos-2.jpg` | Kit Skincare Hidratação Facial 3 Passos | Authentic Stock | [stocksnap](https://stocksnap.io/photo/woman-skin-ZD257KAS8U) | CC0 1.0 (domínio público) |
| `kit-skincare-hidratacao-facial-3-passos-3.jpg` | Kit Skincare Hidratação Facial 3 Passos | Authentic Stock | [stocksnap](https://stocksnap.io/photo/woman-skin-L7CBSFA42B) | CC0 1.0 (domínio público) |
| `oculos-de-sol-unissex-protecao-uv400-1.jpg` | Óculos de Sol Unissex Proteção UV400 | roland | [flickr](https://www.flickr.com/photos/35034347371@N01/18040057233) | CC0 1.0 (domínio público) |
| `oculos-de-sol-unissex-protecao-uv400-2.jpg` | Óculos de Sol Unissex Proteção UV400 | Image Catalog | [flickr](https://www.flickr.com/photos/132795455@N08/18502942241) | CC0 1.0 (domínio público) |
| `caderno-capa-dura-160-folhas-1.jpg` | Caderno Capa Dura 160 Folhas | Negative Space | [stocksnap](https://stocksnap.io/photo/office-work-13UNSPJHCZ) | CC0 1.0 (domínio público) |
| `caderno-capa-dura-160-folhas-2.jpg` | Caderno Capa Dura 160 Folhas | Chimene Gaspar | [stocksnap](https://stocksnap.io/photo/cup-flatlay-FCPVTTJJLS) | CC0 1.0 (domínio público) |
| `caderno-capa-dura-160-folhas-3.jpg` | Caderno Capa Dura 160 Folhas | Cathryn Lavery | [stocksnap](https://stocksnap.io/photo/journal-notepad-DPKNIIN5X3) | CC0 1.0 (domínio público) |
| `kit-lapis-de-cor-36-cores-1.jpg` | Kit Lápis de Cor 36 Cores | Artsy Crafty | [stocksnap](https://stocksnap.io/photo/colorful-pencils-UFDTNK6BWQ) | CC0 1.0 (domínio público) |
| `kit-lapis-de-cor-36-cores-2.jpg` | Kit Lápis de Cor 36 Cores | Artsy Crafty | [stocksnap](https://stocksnap.io/photo/colored-pencil-KDFVIYEYB2) | CC0 1.0 (domínio público) |
| `kit-lapis-de-cor-36-cores-3.jpg` | Kit Lápis de Cor 36 Cores | Artsy Crafty | [stocksnap](https://stocksnap.io/photo/colorful-pencils-Z8EF7IZ8OR) | CC0 1.0 (domínio público) |
| `blocos-de-montar-coloridos-500-pecas-1.jpg` | Blocos de Montar Coloridos 500 Peças | Desconhecido | [rawpixel](https://www.rawpixel.com/image/6113755/photo-image-public-domain-children-free) | CC0 1.0 (domínio público) |
| `blocos-de-montar-coloridos-500-pecas-2.jpg` | Blocos de Montar Coloridos 500 Peças | Desconhecido | [rawpixel](https://www.rawpixel.com/image/6036004/photo-image-public-domain-child-plastic) | CC0 1.0 (domínio público) |
| `blocos-de-montar-coloridos-500-pecas-3.jpg` | Blocos de Montar Coloridos 500 Peças | Desconhecido | [rawpixel](https://www.rawpixel.com/image/6036005/photo-image-public-domain-child-plastic) | CC0 1.0 (domínio público) |
| `urso-de-pelucia-40cm-1.jpg` | Urso de Pelúcia 40cm | Desconhecido | [rawpixel](https://www.rawpixel.com/image/6070308/free-public-domain-cc0-photo) | CC0 1.0 (domínio público) |
| `urso-de-pelucia-40cm-2.jpg` | Urso de Pelúcia 40cm | Desconhecido | [rawpixel](https://www.rawpixel.com/image/6040956/photo-image-background-public-domain-cute) | CC0 1.0 (domínio público) |
| `urso-de-pelucia-40cm-3.jpg` | Urso de Pelúcia 40cm | Desconhecido | [rawpixel](https://www.rawpixel.com/image/6017050/photo-image-background-public-domain-cute) | CC0 1.0 (domínio público) |
| `quebra-cabeca-1000-pecas-1.jpg` | Quebra-Cabeça 1000 Peças | Desconhecido | [rawpixel](https://www.rawpixel.com/image/3286275/free-photo-image-pattern-puzzle-toy) | CC0 1.0 (domínio público) |
| `quebra-cabeca-1000-pecas-2.jpg` | Quebra-Cabeça 1000 Peças | Desconhecido | [rawpixel](https://www.rawpixel.com/image/6034079/blue-jigsaw-puzzle-free-public-domain-cc0-image) | CC0 1.0 (domínio público) |
| `quebra-cabeca-1000-pecas-3.jpg` | Quebra-Cabeça 1000 Peças | Desconhecido | [rawpixel](https://www.rawpixel.com/image/5906723/photo-image-background-public-domain-blue) | CC0 1.0 (domínio público) |
| `garrafa-termica-inox-750ml-1.jpg` | Garrafa Térmica Inox 750ml | Desconhecido | [rawpixel](https://www.rawpixel.com/image/5958970/free-public-domain-cc0-photo) | CC0 1.0 (domínio público) |
