# JM VARIEDADES — loja virtual

Loja virtual de variedades de **uma única loja**, a JM VARIEDADES: casa e cozinha, decoração, eletrônicos, beleza, moda, papelaria, brinquedos e esporte. A equipe da loja cadastra os produtos e despacha os pedidos, os clientes pagam com **Mercado Pago (Checkout Pro)** e o frete é calculado pelos **Correios**.

O nome, o slogan e a descrição da loja ficam em um único arquivo, `src/lib/store.ts`.

| Camada | Tecnologia |
|---|---|
| Frontend | Next.js 15 (App Router) + React 19 + TypeScript (strict) + Tailwind CSS 4 + shadcn/ui + Lucide |
| Backend | Next.js Route Handlers (API REST) |
| Banco | PostgreSQL (Supabase) + Prisma ORM 6 |
| Autenticação | Auth.js (NextAuth v5): Credentials + JWT |
| Pagamentos | Mercado Pago, Checkout Pro + Webhooks |
| Frete | API REST dos Correios (CWS), com simulador para desenvolvimento |
| Deploy | Vercel (+ Vercel Cron e Vercel Blob) |

---

## 1. Funcionalidades

- **Autenticação:** cadastro de clientes, login, logout, recuperação de senha por e-mail com token de uso único (expira em 1h) e dois perfis: **Cliente** (`BUYER`) e **Equipe da loja** (`ADMIN`). O cadastro público sempre cria clientes; a equipe é definida no painel.
- **Catálogo:** listagem, busca por nome, filtro por categoria e faixa de preço, ordenação, paginação e página de detalhe com galeria.
- **Carrinho:** adicionar, remover, alterar quantidade, subtotal e estimativa de frete. Avisa quando um item fica sem estoque ou indisponível.
- **Frete (Correios):** calculado **automaticamente** na página do produto (CEP do endereço padrão ou o último usado) e no checkout. Todos os pedidos saem do CEP da loja (`SHIPPING_ORIGIN_CEP` no `.env`), em um único volume.
- **Checkout:** escolher endereço (com preenchimento automático via ViaCEP) → calcular frete → resumo → pagamento no Mercado Pago.
- **Pedidos:** histórico, status, itens, frete, código do pagamento, transações e linha do tempo de status.
- **Painel da loja (`/admin`):** visão geral (total vendido, pedidos, pedidos a despachar, clientes, mais vendidos, estoque baixo, gráfico de 14 dias); produtos (cadastro com upload de imagens, edição, pausar/reativar, exclusão, busca); pedidos (envio com código de rastreio, entrega e estorno); clientes e equipe (suspender, reativar, adicionar ou remover da equipe).

### Regras de negócio implementadas

| Regra | Onde |
|---|---|
| Não permitir compra sem estoque | `cart.service.addItem/updateItemQuantity`, `checkout.service` e decremento condicional na aprovação |
| Baixar o estoque automaticamente após pagamento aprovado | `payment.service.applyPayment` (`updateMany ... where stock >= qty`, uma única vez via `stockDeducted`) |
| Cancelar o pedido automaticamente se o pagamento for recusado | `orderStatusFromPayment`: `REJECTED`/`CANCELLED` → `CANCELLED` |
| Histórico completo de transações | `Payment` + `PaymentTransaction` (payload bruto de cada notificação) + `OrderStatusHistory` |
| Cálculo de frete obrigatório | o checkout recalcula o frete no servidor e rejeita serviço inválido |
| Cada cliente vê apenas os próprios pedidos | `order.service.getOrderForUser` (cliente dono ou equipe da loja) |
| Só a equipe gerencia o catálogo e os pedidos | `requireRole("ADMIN")` em todas as rotas do painel e de escrita de produtos |
| Pagamento aprovado sem estoque (concorrência) | estorno automático no Mercado Pago e pedido `REFUNDED` |
| Valor pago divergente do total | o pedido não é aprovado e o caso fica registrado no histórico |
| Pedido pendente expirado | o Vercel Cron cancela após `ORDER_PENDING_TTL_MINUTES` |

---

## 2. Arquitetura

O projeto segue Clean Architecture em quatro camadas. As dependências apontam sempre para dentro: o domínio não conhece Next.js, Prisma nem o Mercado Pago.

```
┌──────────────────────────────────────────────────────────────┐
│ Apresentação  src/app (páginas + rotas REST), src/components │
│        │  valida entrada (Zod) · autentica · traduz erros     │
│        ▼                                                      │
│ Aplicação     src/server/services  (casos de uso)             │
│        │  checkout, pagamento, carrinho, frete, pedidos...    │
│        ▼                                                      │
│ Domínio       src/domain  (regras puras + interfaces/portas)  │
│        ▲  PaymentGateway, ShippingProvider, máquina de estados│
│        │                                                      │
│ Infraestrutura src/infrastructure (adapters)                  │
│     Prisma · MercadoPagoGateway · Correios/Mock · Blob · SMTP │
└──────────────────────────────────────────────────────────────┘
```

Aplicação dos princípios SOLID:
- **S:** cada serviço tem um caso de uso; cada adapter, uma integração.
- **O/L:** `ShippingProvider` tem duas implementações (`CorreiosShippingProvider` e `MockShippingProvider`), trocadas por variável de ambiente sem mexer em código.
- **I:** as portas (`PaymentGateway`, `ShippingProvider`, `FileStorage`) são pequenas e específicas.
- **D:** `processPaymentNotification(id, source, gateway = paymentGateway())` recebe a abstração, por isso dá para testar com um gateway fake.

### Fluxo de pagamento

```
Comprador ──POST /api/checkout──► checkout.service
                                  ├─ valida carrinho/estoque/endereço
                                  ├─ recalcula frete (Correios)
                                  ├─ cria Order PENDING + OrderItems + Shipments
                                  └─ MercadoPagoGateway.createCheckout → preference
           ◄── paymentUrl ────────┘
Comprador ──► Mercado Pago (paga) ──► back_url /checkout/result ─┐
Mercado Pago ──POST /api/webhooks/mercadopago──────────────────┤
                                                                ▼
                       payment.service.processPaymentNotification
                       ├─ valida x-signature (HMAC SHA-256)
                       ├─ GET /v1/payments/:id  (fonte da verdade)
                       ├─ upsert Payment + PaymentTransaction
                       └─ SELECT ... FOR UPDATE no pedido
                          approved → baixa estoque → APPROVED
                          rejected/cancelled → CANCELLED
                          refunded/charged_back → devolve estoque → REFUNDED
```

A página de retorno também sincroniza o pagamento. Assim, o fluxo completo funciona em `localhost`, onde o Mercado Pago não consegue chamar o webhook.

---

## 3. Estrutura de pastas

```
jm-variedades/
├── prisma/
│   ├── schema.prisma               # modelagem completa
│   ├── migrations/                 # migrations (SQL): inicial + loja única
│   └── seed.ts                     # equipe, cliente, departamentos e produtos de exemplo
├── public/uploads/                 # uploads locais (somente dev)
├── src/
│   ├── auth.ts / auth.config.ts    # Auth.js (Credentials + JWT; config edge-safe)
│   ├── middleware.ts               # proteção de páginas por perfil
│   ├── domain/                     # regras puras e portas
│   │   ├── errors.ts               # erros de domínio → HTTP
│   │   ├── payment.ts              # PaymentGateway, mapeamento de status, máquina de estados
│   │   └── shipping.ts             # ShippingProvider, consolidação de volumes
│   ├── infrastructure/             # adapters
│   │   ├── db/prisma.ts
│   │   ├── payment/mercadopago-gateway.ts
│   │   ├── payment/webhook-signature.ts
│   │   ├── shipping/correios-provider.ts
│   │   ├── shipping/mock-provider.ts
│   │   ├── shipping/index.ts       # factory por SHIPPING_PROVIDER
│   │   ├── storage/file-storage.ts # Vercel Blob | disco local
│   │   └── mail/mailer.ts          # SMTP | console
│   ├── server/                     # camada de aplicação
│   │   ├── services/               # product, cart, shipping, checkout, payment, order, user, dashboard
│   │   ├── validators.ts           # schemas Zod
│   │   ├── session.ts              # requireUser / requireRole
│   │   └── http.ts                 # helpers REST (ok, parseBody, route, erros)
│   ├── lib/                        # store (identidade da loja), env (Zod), utils, api-client
│   ├── components/
│   │   ├── ui/                     # shadcn/ui (button, card, input, table, badge...)
│   │   ├── layout/ product/ cart/ checkout/ account/ auth/ admin/ shared/
│   └── app/
│       ├── page.tsx                # Home
│       ├── products/               # Catálogo e Produto
│       ├── cart/  checkout/  checkout/result/  orders/  account/addresses/
│       ├── (auth)/                 # login, register, forgot-password, reset-password
│       ├── admin/                  # painel da loja (equipe)
│       └── api/                    # rotas REST (ver seção 5)
├── .env.example
├── vercel.json                     # build com migrate deploy + cron
└── next.config.ts                  # imagens remotas + headers de segurança
```

---

## 4. Modelagem do banco

```
Category 1──N Product 1──N CartItem N──1 Cart 1──1 User
                   │
                   └──N OrderItem
User 1──N Address
 ├──N Order (cliente) 1──N OrderItem
 │          ├──N Payment 1──N PaymentTransaction
 │          ├──N Shipment        ← o envio da loja (Correios)
 │          └──N OrderStatusHistory
 └──N PasswordResetToken
```

Decisões de modelagem:
- **Dinheiro em `Decimal(12,2)`.** Os cálculos são feitos em centavos inteiros (`toCents`) para evitar erro de ponto flutuante.
- **Snapshots:** `OrderItem` guarda título, preço e imagem, e `Order.shippingAddress` guarda o endereço em JSON. O histórico não muda se o produto ou o endereço forem alterados depois.
- **Exclusão lógica de produto (`deletedAt`):** preserva a integridade dos pedidos antigos.
- **Loja única:** os produtos não têm dono; tudo pertence à loja. Cada pedido gera **um `Shipment`** saindo do CEP da loja, com todos os itens consolidados em um volume (`buildPackage`).
- **Perfis:** `BUYER` (cliente) e `ADMIN` (equipe da loja). A migration `20261014000000_single_store` converteu a versão marketplace: vendedores viraram clientes, produtos bloqueados viraram pausados e as colunas de vendedor foram removidas, sem perder pedidos.
- **Idempotência:** `Payment.externalId` é único, `Order.stockDeducted` evita baixar o estoque duas vezes, e o lock de linha (`FOR UPDATE`) protege contra webhooks concorrentes.

`OrderStatus`: `PENDING` (Pendente), `APPROVED` (Aprovado), `CANCELLED` (Cancelado), `REFUNDED` (Reembolsado).
`PaymentStatus` espelha o Mercado Pago (`approved`, `rejected`, `in_process`, `refunded`, `charged_back`...).

---

## 5. Rotas REST

Respostas: `{ "data": ... }` em caso de sucesso, `{ "error": { "code", "message", "fields?" } }` em caso de erro (401/403/404/409/422/502).

| Método | Rota | Acesso | Descrição |
|---|---|---|---|
| POST | `/api/auth/register` | público | cadastro de cliente |
| POST | `/api/auth/forgot-password` | público | envia link de recuperação |
| POST | `/api/auth/reset-password` | público | redefine a senha com o token |
| GET/POST | `/api/auth/[...nextauth]` | público | Auth.js (login/logout/sessão) |
| GET | `/api/categories` | público | departamentos com produtos à venda |
| GET | `/api/products?q&category&minPrice&maxPrice&sort&page&pageSize` | público | catálogo paginado |
| POST | `/api/products` | ADMIN | cria produto |
| GET | `/api/products/:id` | público | detalhe |
| PATCH/DELETE | `/api/products/:id` | ADMIN | edita / exclui (lógico) |
| POST | `/api/uploads` | ADMIN | upload de imagens (multipart `files`) |
| GET/POST/DELETE | `/api/cart` | logado | ver / adicionar / esvaziar |
| PATCH/DELETE | `/api/cart/items/:productId` | logado | quantidade / remover |
| POST | `/api/shipping/quote` | público (produto) / logado (carrinho) | cotação dos Correios |
| GET/POST | `/api/addresses` · DELETE `/api/addresses/:id` | logado | endereços |
| POST | `/api/checkout` | logado | cria o pedido + preferência MP → `{ orderId, paymentUrl }` |
| GET | `/api/orders` · `/api/orders/:id` | cliente dono/ADMIN | pedidos |
| POST | `/api/webhooks/mercadopago` | Mercado Pago (assinado) | notificações de pagamento |
| GET | `/api/admin/stats` · `/users` · `/products` · `/orders` | ADMIN | painel da loja |
| PATCH | `/api/admin/products/:id` | ADMIN | pausar / reativar produto |
| PATCH | `/api/admin/shipments/:id` | ADMIN | rastreio / entregue |
| PATCH | `/api/admin/users/:id` | ADMIN | suspender, reativar, adicionar/remover da equipe |
| POST | `/api/admin/orders/:id/refund` | ADMIN | estorno no Mercado Pago |
| GET | `/api/cron/expire-orders` | Vercel Cron (Bearer) | cancela pendentes expirados |

---

## 6. Segurança

- **Validação de entrada:** todos os bodies e queries passam por schemas Zod (`src/server/validators.ts`). As variáveis de ambiente também são validadas (`src/lib/env.ts`).
- **SQL Injection:** o Prisma usa queries parametrizadas. As poucas SQL brutas usam o template tag `$queryRaw\`...\``, que parametriza os valores.
- **Autenticação/autorização:** o middleware protege as páginas por perfil, e cada rota de API chama `requireUser`/`requireRole`, que relê **perfil e status no banco** (uma suspensão vale na hora). O cadastro público ignora qualquer perfil enviado e sempre cria um cliente.
- **Senhas:** bcrypt. O token de recuperação é salvo apenas como hash SHA-256, é de uso único e expira em 1h. A resposta é sempre genérica para não revelar quais e-mails existem.
- **Webhook:** valida `x-signature` com HMAC SHA-256 e comparação em tempo constante, e **nunca confia no corpo da notificação** (sempre consulta o pagamento na API do MP). Também confere se o valor pago bate com o total do pedido.
- **Uploads:** só imagens JPG/PNG/WEBP (verificadas pela assinatura binária, não só pelo MIME), com limite de 4 MB.
- **Open redirect:** o `callbackUrl` do login é reduzido a um caminho interno.
- **Headers:** `X-Frame-Options`, `X-Content-Type-Options`, `Referrer-Policy` e `Permissions-Policy` (`next.config.ts`).
- **Segredos:** só via variáveis de ambiente (`.env` está no `.gitignore`).

---

## 7. Instalação local

Pré-requisitos: Node.js 20+ e um banco PostgreSQL. O mais simples é o mesmo projeto Supabase usado na Vercel ou um projeto Supabase separado para desenvolvimento.

**Windows, jeito rápido:** dê dois cliques em `run.bat`. Ele:

1. confere o Node.js (20+) e o npm;
2. confere se as bibliotecas instaladas batem com o `package-lock.json` e roda `npm install` se faltar ou estiver desatualizada alguma;
3. prepara o `.env` (gera o `AUTH_SECRET` e completa variáveis ausentes);
   - **se o Supabase ainda não estiver configurado** (fase de MVP), sobe automaticamente um **PostgreSQL local** — sem instalar nada no Windows, os binários vêm do pacote `embedded-postgres`. Os dados ficam em `.local-db/` e o banco roda na janela minimizada "JM VARIEDADES - banco local" (feche-a para parar). Para trocar pelo Supabase, basta preencher `POSTGRES_PRISMA_URL` e `POSTGRES_URL_NON_POOLING` no `.env`; para zerar o banco local, apague a pasta `.local-db`;
4. gera o Prisma Client, aplica as migrations e roda o seed;
5. detecta o **IP da máquina na rede local**, confere se a porta está livre e libera a porta no Firewall do Windows (quando executado como administrador);
6. sobe o servidor em todas as interfaces e abre `http://SEU_IP:3000`, acessível também por celular ou outros computadores da mesma rede.

Modos: `run.bat` (desenvolvimento), `run.bat prod` (build + `next start`), `run.bat seed` (só prepara o banco). Opções: `set PORT=3001`, `set LAN_IP=192.168.0.10` (força um IP) e `set NO_BROWSER=1`.

Passo a passo manual:

```bash
npm install
cp .env.example .env
# preencha POSTGRES_PRISMA_URL e POSTGRES_URL_NON_POOLING
#   - com a Vercel CLI: vercel link && vercel env pull .env
#   - ou copie do painel do Supabase: Project Settings > Database > Connection string
# gere o AUTH_SECRET: npx auth secret

npm run db:deploy   # aplica a migration (prisma migrate deploy)
npm run db:seed     # dados de exemplo
npm run dev         # http://localhost:3000
```

Usuários do seed (senha **`Senha123`**):

| E-mail | Perfil |
|---|---|
| admin@marketplace.dev | Equipe da loja (painel em `/admin`) |
| comprador@marketplace.dev | Cliente (endereço no RJ) |

O seed pode rodar em um banco que já tem dados: ele só cria o que falta, não altera preço, estoque nem texto de produtos existentes e retira do catálogo (exclusão lógica) os produtos de exemplo da antiga versão marketplace.

As fotos dos produtos de exemplo ficam em `public/seed/`. São fotos reais em domínio público (CC0), obtidas via [Openverse](https://openverse.org), e os créditos estão em `public/seed/CREDITS.md`.

Outros scripts: `npm run typecheck`, `npm run db:migrate` (cria novas migrations em dev), `npm run db:studio`.

### Pagamento simulado (MVP)

Com `PAYMENT_PROVIDER="mock"` (padrão do `.env.example`), o botão **Pagar** leva a uma tela local de pagamento com **Aprovar**, **Deixar em processamento** e **Recusar**. O resultado passa pelo mesmo caso de uso do webhook do Mercado Pago (baixa de estoque, cancelamento automático, estorno pelo admin), então todo o fluxo funciona sem credenciais. Para usar o Mercado Pago de verdade, troque para `PAYMENT_PROVIDER="mercadopago"` e preencha as credenciais.

### Teste ponta a ponta

Com o projeto rodando (`run.bat`) em modo de pagamento simulado:

```bash
npm run test:e2e                         # testa http://localhost:3000
node tests/e2e.mjs http://SEU_IP:3000    # ou outro endereço
```

São 169 verificações que percorrem a loja como visitante, cliente e equipe da loja. Cada botão e formulário é exercitado com a mesma requisição que o navegador faz ao clicar, incluindo cadastro, login, recuperação de senha, endereços, carrinho, frete, checkout, pagamento (aprovado, recusado e pendente), pedidos, CRUD de produtos com upload, pausar/reativar, envio com rastreio, suspensão, gestão da equipe, estorno e as regras de permissão.

### Testando pagamentos (sandbox do Mercado Pago)

1. Em [Suas integrações](https://www.mercadopago.com.br/developers/panel/app), crie uma aplicação (Checkout Pro) e copie as **credenciais de teste** para `MP_ACCESS_TOKEN` / `NEXT_PUBLIC_MP_PUBLIC_KEY`.
2. Crie **usuários de teste** (vendedor = a loja, comprador = cliente) no painel do Mercado Pago e faça o pagamento logado como o comprador de teste.
3. Use os [cartões de teste](https://www.mercadopago.com.br/developers/pt/docs/checkout-pro/integration-test/test-cards). O nome do titular define o resultado: `APRO` aprova, `OTHE` recusa.
4. Em localhost, ao voltar do Mercado Pago, a página `/checkout/result` sincroniza o pagamento. Para receber webhooks localmente, exponha o servidor (`ngrok http 3000` ou `cloudflared tunnel`) e defina `MP_NOTIFICATION_BASE_URL` com a URL https.

### Frete

- `SHIPPING_PROVIDER=mock` (padrão): simulador com PAC e SEDEX, calculado pela distância entre regiões do CEP e pelo peso cubado. Não exige contrato.
- `SHIPPING_PROVIDER=correios`: API oficial (CWS). Exige contrato com os Correios e as credenciais do Meu Correios (`CORREIOS_USER`, `CORREIOS_ACCESS_CODE` = código de acesso à API, `CORREIOS_POSTCARD` = cartão de postagem). Os códigos de serviço ficam em `CORREIOS_SERVICES`.

---

## 8. Deploy na Vercel (com Supabase)

1. **Repositório:** suba o projeto para o GitHub e importe na Vercel (*Add New → Project*). O framework (Next.js) é detectado automaticamente.
2. **Banco:** no projeto da Vercel, vá em *Storage → Create Database → Supabase* (ou conecte um projeto existente). A integração cria `POSTGRES_PRISMA_URL` e `POSTGRES_URL_NON_POOLING`, que o `schema.prisma` já usa. **Não é preciso configurar nada.**
3. **Imagens:** em *Storage → Blob*, crie um store. Isso define o `BLOB_READ_WRITE_TOKEN` (o filesystem da Vercel é somente leitura).
4. **Variáveis de ambiente** (*Settings → Environment Variables*):
   - `AUTH_SECRET` (gere com `npx auth secret`) e `AUTH_TRUST_HOST=true`
   - `APP_URL=https://seu-projeto.vercel.app`
   - `MP_ACCESS_TOKEN`, `NEXT_PUBLIC_MP_PUBLIC_KEY`, `MP_WEBHOOK_SECRET`
   - `SHIPPING_PROVIDER`, `SHIPPING_ORIGIN_CEP` = CEP de onde a loja despacha (e as credenciais dos Correios, se usar a API oficial)
   - `CRON_SECRET` (a Vercel o envia como `Authorization: Bearer` para o cron)
   - opcional: `SMTP_*` e `MAIL_FROM` para e-mails reais de recuperação de senha
5. **Build:** o `vercel.json` roda `prisma generate && prisma migrate deploy && next build`. As migrations são aplicadas pela conexão direta, e a aplicação usa o pooler (Supavisor). A região é `gru1` (São Paulo), perto do Supabase `sa-east-1`.
6. **Seed (uma vez):** localmente, com as variáveis de produção (`vercel env pull .env`), rode `npm run db:seed`.
7. **Webhook do Mercado Pago:** em *Suas integrações → Webhooks*, cadastre `https://seu-projeto.vercel.app/api/webhooks/mercadopago`, marque o evento **Pagamentos** e copie a *assinatura secreta* para `MP_WEBHOOK_SECRET`.
8. **Cron:** já está declarado no `vercel.json` (diário às 03:00 UTC, compatível com o plano Hobby) e cancela pedidos pendentes expirados.
9. **Checklist pós-deploy:** login com os usuários do seed, cálculo de frete na página do produto, compra com cartão de teste `APRO`, pedido `Aprovado` com estoque baixado, e os logs do webhook em *Logs* na Vercel.

---

## 9. Testes manuais realizados

O projeto foi validado contra um PostgreSQL real, cobrindo: migration e seed; páginas públicas e protegidas (redirecionamento por perfil); catálogo com busca, filtros e paginação; cadastro com validação; login; regras de estoque no carrinho; frete em volume único saindo do CEP da loja; checkout (frete inválido rejeitado; falha no gateway cancela o pedido e preserva o carrinho); isolamento entre clientes; painel da loja (produtos, pedidos, equipe e suspensão); migration da versão marketplace com dados existentes; proteção do cron; upload; e a máquina de estados de pagamento (aprovação, webhook duplicado, recusa, estorno, valor divergente, estorno automático por falta de estoque).
