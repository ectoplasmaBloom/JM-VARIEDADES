// Prepara o arquivo .env antes de rodar o projeto (chamado pelo run.bat).
//  - cria o .env a partir do .env.example, se não existir
//  - completa variáveis que faltarem (ex.: depois de "vercel env pull .env",
//    que sobrescreve o arquivo só com as variáveis da Vercel)
//  - gera um AUTH_SECRET aleatório, se estiver vazio ou com o valor de exemplo
//  - verifica se as URLs do banco (Supabase) foram preenchidas
// Códigos de saída: 0 = ok, 2 = banco do Supabase não configurado (run.bat usa banco local)
import { copyFileSync, existsSync, readFileSync, writeFileSync } from "node:fs";
import { randomBytes } from "node:crypto";

const ENV = ".env";
const EXAMPLE = ".env.example";

if (!existsSync(ENV)) {
  copyFileSync(EXAMPLE, ENV);
  console.log("[env] .env criado a partir do .env.example");
}

let content = readFileSync(ENV, "utf8");
const keyRegex = /^([A-Z0-9_]+)=/gm;
const keysIn = (text) => new Set([...text.matchAll(keyRegex)].map((m) => m[1]));

// Completa as variáveis ausentes com os valores padrão do exemplo
const present = keysIn(content);
const missingLines = readFileSync(EXAMPLE, "utf8")
  .split(/\r?\n/)
  .filter((line) => {
    const key = line.match(/^([A-Z0-9_]+)=/)?.[1];
    return key && !present.has(key);
  });
if (missingLines.length > 0) {
  content = `${content.trimEnd()}\n\n# Adicionadas automaticamente a partir do .env.example\n${missingLines.join("\n")}\n`;
  console.log(`[env] ${missingLines.length} variavel(is) ausente(s) adicionada(s) ao .env`);
}

if (/^AUTH_SECRET=("?troque-por-um-segredo.*|""|)\s*$/m.test(content)) {
  content = content.replace(/^AUTH_SECRET=.*$/m, `AUTH_SECRET="${randomBytes(32).toString("base64")}"`);
  console.log("[env] AUTH_SECRET gerado automaticamente");
}

writeFileSync(ENV, content);

const read = (name) => content.match(new RegExp(`^${name}="?([^"\\r\\n]*)"?`, "m"))?.[1] ?? "";
const missingDb = ["POSTGRES_PRISMA_URL", "POSTGRES_URL_NON_POOLING"].filter((name) => {
  const value = read(name);
  return !value || value.includes("SEU_PROJETO") || value.includes(":SENHA@");
});

if (missingDb.length > 0) {
  // Código 2: o run.bat sobe um PostgreSQL local (MVP) em vez de parar
  console.log("[env] Supabase ainda nao configurado no .env - sera usado um PostgreSQL local.");
  console.log("      Para usar o Supabase depois, preencha POSTGRES_PRISMA_URL e POSTGRES_URL_NON_POOLING.");
  process.exit(2);
}

console.log("[env] .env OK");
