// Verificações usadas pelo run.bat antes de subir o projeto.
//
//   node scripts/preflight.mjs node    -> exige Node.js 20+
//   node scripts/preflight.mjs deps    -> confere se as libs instaladas batem com o package-lock.json
//   node scripts/preflight.mjs stamp   -> registra que as libs foram instaladas (após npm install)
//   node scripts/preflight.mjs ip      -> imprime o IPv4 da máquina na rede local
//   node scripts/preflight.mjs port N  -> falha se a porta N já estiver em uso
//   node scripts/preflight.mjs listening N      -> ok se já houver algo escutando na porta N
//   node scripts/preflight.mjs pgready N        -> ok se um PostgreSQL de verdade responder na porta N
//   node scripts/preflight.mjs waitpg N [seg]   -> espera o PostgreSQL responder na porta N
//
// Saída 0 = ok, 1 = problema encontrado (a mensagem explica qual).
import { createHash } from "node:crypto";
import { execSync } from "node:child_process";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { connect, createServer } from "node:net";
import { networkInterfaces } from "node:os";

const STAMP = "node_modules/.marketplace-install-stamp";
const [command, arg] = process.argv.slice(2);

function lockHash() {
  const hash = createHash("sha256");
  for (const file of ["package.json", "package-lock.json"]) {
    if (existsSync(file)) hash.update(readFileSync(file));
  }
  return hash.digest("hex");
}

function checkNode() {
  const major = Number(process.versions.node.split(".")[0]);
  if (major < 20) {
    console.log(`[erro] Node.js ${process.version} encontrado; o projeto precisa do Node.js 20 ou superior.`);
    process.exit(1);
  }
  console.log(`[ok] Node.js ${process.version}`);
}

function checkDeps() {
  if (!existsSync("node_modules")) {
    console.log("[..] Bibliotecas ainda nao instaladas");
    process.exit(1);
  }
  const stamp = existsSync(STAMP) ? readFileSync(STAMP, "utf8").trim() : "";
  if (stamp !== lockHash()) {
    console.log("[..] package.json/package-lock.json mudaram desde a ultima instalacao");
    process.exit(1);
  }
  try {
    // "npm ls" falha se alguma lib estiver ausente ou com versão incompatível
    execSync("npm ls --depth=0", { stdio: "ignore" });
  } catch {
    console.log("[..] Ha bibliotecas ausentes ou com versao incompativel");
    process.exit(1);
  }
  console.log("[ok] Bibliotecas instaladas e atualizadas");
}

function writeStamp() {
  writeFileSync(STAMP, lockHash());
}

/** Escolhe o IPv4 da rede local, evitando adaptadores virtuais (WSL, Hyper-V, VPN...). */
function lanIp() {
  const virtual = /vEthernet|Hyper-V|VirtualBox|VMware|WSL|Docker|Loopback|Bluetooth|Tailscale|ZeroTier|Npcap|TAP/i;
  const candidates = [];
  for (const [name, addresses] of Object.entries(networkInterfaces())) {
    for (const a of addresses ?? []) {
      if ((a.family !== "IPv4" && a.family !== 4) || a.internal || a.address.startsWith("169.254.")) continue;
      const privateRange = /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(a.address);
      const score = (virtual.test(name) ? 0 : 2) + (privateRange ? 1 : 0);
      candidates.push({ address: a.address, score });
    }
  }
  candidates.sort((x, y) => y.score - x.score);
  console.log(candidates[0]?.address ?? "localhost");
}

function checkPort(port) {
  const server = createServer();
  server.once("error", () => {
    console.log(`[erro] A porta ${port} ja esta em uso. Feche o outro programa ou use outra porta: set PORT=3001 e depois run.bat`);
    process.exit(1);
  });
  server.once("listening", () => {
    server.close(() => {
      console.log(`[ok] Porta ${port} livre`);
      process.exit(0);
    });
  });
  server.listen(Number(port), "0.0.0.0");
}

function canConnect(port) {
  return new Promise((resolve) => {
    const socket = connect({ port: Number(port), host: "127.0.0.1" });
    socket.setTimeout(1000);
    socket.once("connect", () => {
      socket.destroy();
      resolve(true);
    });
    socket.once("timeout", () => {
      socket.destroy();
      resolve(false);
    });
    socket.once("error", () => resolve(false));
  });
}

/**
 * Conexão TCP aberta não basta: um processo órfão pode segurar a porta sem atender.
 * Envia o SSLRequest do protocolo do PostgreSQL e exige a resposta de 1 byte ("N" ou "S").
 */
function pgReady(port, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const socket = connect({ port: Number(port), host: "127.0.0.1" });
    const timer = setTimeout(() => {
      socket.destroy();
      resolve(false);
    }, timeoutMs);
    const done = (ok) => {
      clearTimeout(timer);
      socket.destroy();
      resolve(ok);
    };
    socket.once("connect", () => socket.write(Buffer.from([0, 0, 0, 8, 4, 0xd2, 0x16, 0x2f])));
    socket.once("data", (data) => done(data[0] === 0x4e || data[0] === 0x53));
    socket.once("error", () => done(false));
  });
}

async function waitPg(port, seconds) {
  const deadline = Date.now() + seconds * 1000;
  while (Date.now() < deadline) {
    if (await pgReady(port)) process.exit(0);
    await new Promise((r) => setTimeout(r, 1000));
  }
  console.log(`[erro] O PostgreSQL não respondeu na porta ${port} em ${seconds}s. Veja a janela "JM VARIEDADES - banco local".`);
  process.exit(1);
}

switch (command) {
  case "node":
    checkNode();
    break;
  case "deps":
    checkDeps();
    break;
  case "stamp":
    writeStamp();
    break;
  case "ip":
    lanIp();
    break;
  case "port":
    checkPort(arg ?? "3000");
    break;
  case "listening":
    process.exit((await canConnect(arg ?? "0")) ? 0 : 1);
    break;
  case "pgready":
    process.exit((await pgReady(arg ?? "0")) ? 0 : 1);
    break;
  case "waitpg":
    await waitPg(arg ?? "0", Number(process.argv[4] ?? 120));
    break;
  default:
    console.log("uso: node scripts/preflight.mjs node|deps|stamp|ip|port <n>|listening <n>|pgready <n>|waitpg <n> [seg]");
    process.exit(1);
}
