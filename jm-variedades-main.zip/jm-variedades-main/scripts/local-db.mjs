// Banco PostgreSQL local para desenvolvimento/MVP (usado pelo run.bat quando o
// Supabase ainda não foi configurado no .env). Não precisa instalar nada no
// Windows: os binários vêm do pacote npm "embedded-postgres".
// Os dados ficam em .local-db/ (ignorado pelo git) e persistem entre execuções.
// Para parar o banco, feche a janela "JM VARIEDADES - banco local".
import EmbeddedPostgres from "embedded-postgres";
import { existsSync, rmSync } from "node:fs";
import path from "node:path";

const port = Number(process.env.LOCAL_DB_PORT ?? 54329);
const dataDir = path.resolve(".local-db", "data");

const pg = new EmbeddedPostgres({
  databaseDir: dataDir,
  user: "postgres",
  password: "postgres",
  port,
  persistent: true,
  initdbFlags: ["--encoding=UTF8", "--locale=C"],
});

async function start() {
  if (!existsSync(path.join(dataDir, "PG_VERSION"))) {
    console.log("[db] Criando banco local em .local-db (primeira execucao)...");
    await pg.initialise();
  }
  try {
    await pg.start();
  } catch (error) {
    // Se a janela anterior foi fechada à força, sobra um postmaster.pid antigo
    const pidFile = path.join(dataDir, "postmaster.pid");
    if (!existsSync(pidFile)) throw error;
    console.log("[db] Removendo trava de uma execucao anterior e tentando de novo...");
    rmSync(pidFile);
    await pg.start();
  }
  try {
    await pg.createDatabase("marketplace");
  } catch {
    // o banco já existe
  }
  console.log(`[db] PostgreSQL local pronto na porta ${port}. Feche esta janela para parar o banco.`);
}

let stopping = false;
async function stop() {
  if (stopping) return;
  stopping = true;
  await pg.stop().catch(() => {});
  process.exit(0);
}
for (const signal of ["SIGINT", "SIGTERM", "SIGHUP", "SIGBREAK"]) process.on(signal, stop);

start().catch((error) => {
  console.error("[db] Falha ao iniciar o PostgreSQL local:", error);
  process.exit(1);
});

setInterval(() => {}, 1 << 30);
