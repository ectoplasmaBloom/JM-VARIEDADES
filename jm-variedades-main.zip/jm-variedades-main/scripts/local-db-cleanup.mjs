// Limpa um banco local travado antes de iniciá-lo de novo (chamado pelo run.bat).
//
// Quando a janela "JM VARIEDADES - banco local" é fechada à força, o processo
// principal do PostgreSQL pode morrer deixando processos filhos órfãos que
// continuam segurando a porta sem atender conexões. Este script:
//   1. encerra SOMENTE processos postgres.exe deste projeto (executável dentro de
//      node_modules/@embedded-postgres deste diretório) — nunca outros PostgreSQL;
//   2. remove a trava antiga (.local-db/data/postmaster.pid).
import { execFileSync } from "node:child_process";
import { existsSync, rmSync } from "node:fs";
import path from "node:path";

/** Compara caminhos ignorando maiúsculas e o tipo de barra. */
const normalize = (p) => p.replaceAll("/", "\\").toLowerCase();
const binDir = normalize(path.resolve("node_modules", "@embedded-postgres"));

if (process.platform === "win32") {
  let pids = [];
  try {
    // ExecutablePath pode vir vazio em processos órfãos; a linha de comando sempre traz o executável
    const out = execFileSync(
      "powershell",
      [
        "-NoProfile",
        "-Command",
        "Get-CimInstance Win32_Process -Filter \"Name='postgres.exe'\" | ForEach-Object { \"$($_.ProcessId)|$($_.ExecutablePath)|$($_.CommandLine)\" }",
      ],
      { encoding: "utf8" },
    );
    pids = out
      .split(/\r?\n/)
      .map((line) => line.trim().split("|"))
      .filter(([pid, exe = "", cmd = ""]) => pid && normalize(exe || cmd).includes(binDir))
      .map(([pid]) => Number(pid));
  } catch {
    // sem PowerShell/CIM: segue só removendo a trava
  }
  for (const pid of pids) {
    try {
      process.kill(pid, "SIGKILL");
    } catch {
      // processo já terminou
    }
  }
  if (pids.length) console.log(`[db] ${pids.length} processo(s) travado(s) do banco local encerrado(s)`);
}

const pidFile = path.resolve(".local-db", "data", "postmaster.pid");
if (existsSync(pidFile)) {
  rmSync(pidFile);
  console.log("[db] Trava antiga do banco local removida");
}
