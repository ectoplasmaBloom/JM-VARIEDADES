-- Loja única (JM VARIEDADES): remove o conceito de vendedores.
-- Os produtos, pedidos e envios passam a ser todos da loja.

-- 1. Contas de vendedor viram clientes (menor privilégio). A equipe da loja usa o perfil ADMIN.
UPDATE "User" SET "role" = 'BUYER' WHERE "role" = 'SELLER';

ALTER TYPE "Role" RENAME TO "Role_old";
CREATE TYPE "Role" AS ENUM ('BUYER', 'ADMIN');
ALTER TABLE "User" ALTER COLUMN "role" DROP DEFAULT;
ALTER TABLE "User" ALTER COLUMN "role" TYPE "Role" USING ("role"::text::"Role");
ALTER TABLE "User" ALTER COLUMN "role" SET DEFAULT 'BUYER';
DROP TYPE "Role_old";

-- 2. Sem moderação de terceiros: produtos bloqueados viram pausados.
UPDATE "Product" SET "status" = 'INACTIVE' WHERE "status" = 'BLOCKED';

ALTER TYPE "ProductStatus" RENAME TO "ProductStatus_old";
CREATE TYPE "ProductStatus" AS ENUM ('ACTIVE', 'INACTIVE');
ALTER TABLE "Product" ALTER COLUMN "status" DROP DEFAULT;
ALTER TABLE "Product" ALTER COLUMN "status" TYPE "ProductStatus" USING ("status"::text::"ProductStatus");
ALTER TABLE "Product" ALTER COLUMN "status" SET DEFAULT 'ACTIVE';
DROP TYPE "ProductStatus_old";

-- 3. Remove as colunas de vendedor (índices e FKs caem junto).
ALTER TABLE "Product" DROP CONSTRAINT "Product_sellerId_fkey";
ALTER TABLE "OrderItem" DROP CONSTRAINT "OrderItem_sellerId_fkey";
ALTER TABLE "Shipment" DROP CONSTRAINT "Shipment_sellerId_fkey";
DROP INDEX "Product_sellerId_idx";
DROP INDEX "OrderItem_sellerId_idx";
DROP INDEX "Shipment_sellerId_idx";
ALTER TABLE "Product" DROP COLUMN "sellerId";
ALTER TABLE "OrderItem" DROP COLUMN "sellerId";
ALTER TABLE "Shipment" DROP COLUMN "sellerId";
ALTER TABLE "User" DROP COLUMN "storeName",
DROP COLUMN "originCep";
