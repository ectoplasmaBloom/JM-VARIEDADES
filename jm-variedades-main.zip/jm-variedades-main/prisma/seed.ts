import { readFileSync } from "node:fs";
import path from "node:path";
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

/**
 * Seed de desenvolvimento da JM VARIEDADES: equipe, cliente de teste, departamentos e catálogo.
 * Execução: npm run db:seed. Pode rodar várias vezes: só cria o que falta e
 * nunca altera preço, estoque ou texto de produtos que já existem.
 */
const prisma = new PrismaClient();

const PASSWORD = "Senha123";

/**
 * Fotos reais (domínio público, via Openverse) em public/seed — créditos em public/seed/CREDITS.md.
 * Mapa título do produto -> imagens.
 */
const SEED_IMAGES = JSON.parse(
  readFileSync(path.join(__dirname, "seed-images.json"), "utf8"),
) as Record<string, string[]>;

/** Departamentos da loja (slugs antigos mantidos para não quebrar links). */
const CATEGORIES = [
  { name: "Casa e Cozinha", slug: "casa-e-cozinha", icon: "🏠" },
  { name: "Decoração", slug: "decoracao", icon: "🕯️" },
  { name: "Eletrônicos", slug: "eletronicos", icon: "🎧" },
  { name: "Beleza e Cuidados", slug: "beleza-e-cuidados", icon: "💄" },
  { name: "Moda e Acessórios", slug: "moda", icon: "👜" },
  { name: "Papelaria", slug: "papelaria", icon: "✏️" },
  { name: "Brinquedos", slug: "brinquedos", icon: "🧸" },
  { name: "Esporte e Lazer", slug: "esportes", icon: "🏃" },
];

/** Categorias da versão marketplace que não existem mais na loja (removidas se vazias). */
const LEGACY_CATEGORY_SLUGS = ["informatica", "livros"];

/** Produtos de exemplo da versão marketplace que não fazem parte do mix da loja. */
const LEGACY_PRODUCT_TITLES = [
  "Smartphone Galaxy A55 128GB 5G",
  'Notebook Ultrafino 14" 16GB RAM SSD 512GB',
  "Teclado Mecânico RGB Switch Brown ABNT2",
  'Monitor 27" IPS QHD 75Hz',
  "Livro: Arquitetura Limpa — Robert C. Martin",
  "Livro: Domain-Driven Design — Eric Evans",
];

type SeedProduct = {
  title: string;
  category: string;
  price: number;
  stock: number;
  weightGrams: number;
  dims: [number, number, number];
  description: string;
};

const PRODUCTS: SeedProduct[] = [
  // Casa e Cozinha
  { title: "Air Fryer 4L Digital 1500W", category: "casa-e-cozinha", price: 399.9, stock: 18, weightGrams: 4500, dims: [35, 32, 35], description: "Painel digital com 8 programas, cesto antiaderente removível e desligamento automático." },
  { title: "Jogo de Panelas Antiaderente 5 Peças", category: "casa-e-cozinha", price: 289, stock: 10, weightGrams: 3800, dims: [45, 30, 25], description: "Revestimento antiaderente, tampas de vidro temperado e cabos que não esquentam." },
  { title: "Cafeteira Elétrica Programável 30 Xícaras", category: "casa-e-cozinha", price: 189.9, stock: 8, weightGrams: 1900, dims: [30, 22, 35], description: "Timer programável, placa que mantém o café quente e filtro permanente lavável." },
  { title: "Kit 4 Potes Herméticos de Vidro", category: "casa-e-cozinha", price: 79.9, stock: 30, weightGrams: 2200, dims: [30, 22, 18], description: "Vidro borossilicato com tampa de travas e vedação de silicone. Vai ao micro-ondas e ao freezer." },
  // Decoração
  { title: "Vela Aromática em Copo de Vidro 200g", category: "decoracao", price: 59.9, stock: 40, weightGrams: 450, dims: [10, 10, 12], description: "Cera vegetal e pavio de algodão, com cerca de 40 horas de queima. Aroma suave de baunilha e âmbar." },
  { title: "Vaso de Vidro para Flores", category: "decoracao", price: 69.9, stock: 15, weightGrams: 700, dims: [15, 15, 25], description: "Vidro transparente de boca estreita, ideal para flores frescas e arranjos delicados." },
  { title: "Luminária de Mesa Articulada", category: "decoracao", price: 129.9, stock: 12, weightGrams: 1200, dims: [40, 18, 18], description: "Haste articulada, base estável e soquete E27. Acompanha lâmpada LED de luz quente." },
  // Eletrônicos
  { title: "Fone de Ouvido Bluetooth com Cancelamento de Ruído", category: "eletronicos", price: 349.9, stock: 30, weightGrams: 300, dims: [20, 18, 8], description: "Cancelamento ativo de ruído, até 30 horas de bateria e estojo de transporte." },
  { title: "Caixa de Som Portátil à Prova d'Água 20W", category: "eletronicos", price: 229.9, stock: 3, weightGrams: 700, dims: [22, 10, 10], description: "Som de 20W, resistência à água IPX7 e até 12 horas de bateria." },
  { title: "Smartwatch Fitness com GPS e Monitor Cardíaco", category: "eletronicos", price: 599, stock: 12, weightGrams: 250, dims: [12, 10, 8], description: "GPS integrado, monitor cardíaco, mais de 100 modos de esporte e bateria de até 10 dias." },
  { title: "Mouse Sem Fio Ergonômico 4000 DPI", category: "eletronicos", price: 119.9, stock: 40, weightGrams: 200, dims: [15, 10, 6], description: "Formato ergonômico, sensor de 4000 DPI ajustável e receptor USB nano." },
  // Beleza e Cuidados
  { title: "Perfume Feminino Floral 100ml", category: "beleza-e-cuidados", price: 189.9, stock: 20, weightGrams: 400, dims: [15, 10, 8], description: "Eau de parfum com notas de jasmim, peônia e almíscar branco." },
  { title: "Kit Pincéis de Maquiagem 12 Peças", category: "beleza-e-cuidados", price: 69.9, stock: 25, weightGrams: 350, dims: [24, 12, 5], description: "Cerdas sintéticas macias para pó, blush, sombra e contorno, com estojo." },
  { title: "Kit Skincare Hidratação Facial 3 Passos", category: "beleza-e-cuidados", price: 119.9, stock: 0, weightGrams: 500, dims: [18, 12, 8], description: "Gel de limpeza, tônico e hidratante com ácido hialurônico para uso diário." },
  // Moda e Acessórios
  { title: "Camiseta Dry Fit Masculina Kit com 3", category: "moda", price: 99.9, stock: 50, weightGrams: 450, dims: [30, 25, 5], description: "Tecido leve de secagem rápida, nas cores preta, cinza e azul-marinho." },
  { title: "Tênis de Corrida Amortecimento Leve", category: "moda", price: 329.9, stock: 14, weightGrams: 900, dims: [34, 22, 13], description: "Entressola com amortecimento responsivo e cabedal em tela respirável." },
  { title: "Óculos de Sol Unissex Proteção UV400", category: "moda", price: 89.9, stock: 4, weightGrams: 150, dims: [16, 7, 6], description: "Lentes com proteção UV400, armação leve e estojo rígido." },
  // Papelaria
  { title: "Caderno Capa Dura 160 Folhas", category: "papelaria", price: 34.9, stock: 60, weightGrams: 600, dims: [28, 20, 2], description: "Papel 90g/m² pautado, capa dura e elástico para fechar." },
  { title: "Kit Lápis de Cor 36 Cores", category: "papelaria", price: 49.9, stock: 35, weightGrams: 450, dims: [20, 18, 2], description: "Cores vibrantes, minas resistentes e estojo de metal." },
  // Brinquedos
  { title: "Blocos de Montar Coloridos 500 Peças", category: "brinquedos", price: 129.9, stock: 18, weightGrams: 1100, dims: [30, 22, 12], description: "Peças compatíveis entre si, com caixa organizadora. Indicado a partir de 6 anos." },
  { title: "Urso de Pelúcia 40cm", category: "brinquedos", price: 79.9, stock: 20, weightGrams: 400, dims: [30, 25, 20], description: "Pelúcia antialérgica, macia e com costuras reforçadas." },
  { title: "Quebra-Cabeça 1000 Peças", category: "brinquedos", price: 69.9, stock: 10, weightGrams: 700, dims: [30, 22, 6], description: "Peças com encaixe preciso e imagem de alta definição. Tamanho montado: 70 × 50 cm." },
  // Esporte e Lazer
  { title: "Kit Halteres Ajustáveis 20kg", category: "esportes", price: 259.9, stock: 6, weightGrams: 20000, dims: [45, 25, 20], description: "Anilhas intercambiáveis, barras com empunhadura antiderrapante e travas de rosca." },
  { title: "Tapete de Yoga Antiderrapante 6mm", category: "esportes", price: 89.9, stock: 25, weightGrams: 900, dims: [62, 12, 12], description: "Superfície antiderrapante dos dois lados, 6 mm de espessura e alça para transporte." },
  { title: "Garrafa Térmica Inox 750ml", category: "esportes", price: 79.9, stock: 45, weightGrams: 400, dims: [28, 9, 9], description: "Parede dupla de inox: gelado por 24h e quente por 12h. Livre de BPA." },
];

function slugify(text: string): string {
  return text
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 80);
}

async function main() {
  const passwordHash = await bcrypt.hash(PASSWORD, 10);

  const upsertUser = (data: { email: string; name: string; role: "ADMIN" | "BUYER" }) =>
    prisma.user.upsert({ where: { email: data.email }, update: {}, create: { ...data, passwordHash } });

  await upsertUser({ email: "admin@marketplace.dev", name: "Equipe JM", role: "ADMIN" });
  const buyer = await upsertUser({ email: "comprador@marketplace.dev", name: "João Silva", role: "BUYER" });

  if ((await prisma.address.count({ where: { userId: buyer.id } })) === 0) {
    await prisma.address.create({
      data: {
        userId: buyer.id,
        label: "Casa",
        recipient: "João Silva",
        cep: "20040020",
        street: "Avenida Rio Branco",
        number: "100",
        district: "Centro",
        city: "Rio de Janeiro",
        state: "RJ",
        isDefault: true,
      },
    });
  }

  const categories = new Map<string, string>();
  for (const c of CATEGORIES) {
    const saved = await prisma.category.upsert({
      where: { slug: c.slug },
      update: { name: c.name, icon: c.icon },
      create: c,
    });
    categories.set(c.slug, saved.id);
  }

  // Catálogo: cria o que falta; produtos de exemplo que já existem só são movidos para o departamento certo
  let created = 0;
  for (const p of PRODUCTS) {
    const categoryId = categories.get(p.category)!;
    const existing = await prisma.product.findFirst({ where: { title: p.title }, select: { id: true, deletedAt: true, images: true } });
    if (existing) {
      if (!existing.deletedAt) {
        const stale = existing.images.length === 0 || existing.images.every((url) => url.includes("picsum.photos"));
        await prisma.product.update({
          where: { id: existing.id },
          data: { categoryId, ...(stale && SEED_IMAGES[p.title] ? { images: SEED_IMAGES[p.title] } : {}) },
        });
      }
      continue;
    }
    await prisma.product.create({
      data: {
        title: p.title,
        slug: slugify(p.title),
        description: `${p.description}\n\nProduto novo, com nota fiscal e garantia. Despachamos em até 1 dia útil após a confirmação do pagamento.`,
        price: p.price,
        stock: p.stock,
        images: SEED_IMAGES[p.title] ?? [],
        weightGrams: p.weightGrams,
        lengthCm: p.dims[0],
        widthCm: p.dims[1],
        heightCm: p.dims[2],
        categoryId,
      },
    });
    created++;
  }

  // Itens da antiga versão marketplace saem do catálogo (exclusão lógica: o histórico de pedidos é mantido)
  const now = new Date();
  const retired = await prisma.product.findMany({
    where: { title: { in: LEGACY_PRODUCT_TITLES }, deletedAt: null },
    select: { id: true },
  });
  if (retired.length) {
    const ids = retired.map((r) => r.id);
    await prisma.$transaction([
      prisma.cartItem.deleteMany({ where: { productId: { in: ids } } }),
      prisma.product.updateMany({ where: { id: { in: ids } }, data: { deletedAt: now, status: "INACTIVE" } }),
    ]);
  }
  const { count: removedCategories } = await prisma.category.deleteMany({
    where: { slug: { in: LEGACY_CATEGORY_SLUGS }, products: { none: {} } },
  });

  if (created) console.log(`${created} produto(s) criado(s).`);
  if (retired.length) console.log(`${retired.length} produto(s) da versão marketplace retirado(s) do catálogo.`);
  if (removedCategories) console.log(`${removedCategories} categoria(s) antiga(s) removida(s).`);
  console.log("Seed concluído. Usuários (senha: %s):", PASSWORD);
  console.log("  admin@marketplace.dev     (equipe da loja - painel em /admin)");
  console.log("  comprador@marketplace.dev (cliente)");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
