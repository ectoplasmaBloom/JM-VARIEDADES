/**
 * Identidade da loja. Tudo que aparece com o nome da loja (logo, títulos,
 * e-mails, rodapé) vem daqui: para renomear, altere só este arquivo.
 * O CEP de onde a loja despacha fica no .env (SHIPPING_ORIGIN_CEP).
 */
export const STORE = {
  name: "JM VARIEDADES",
  /** Iniciais usadas no monograma da logo */
  monogram: "JM",
  tagline: "Variedades escolhidas com cuidado",
  description:
    "Casa, cozinha, beleza, moda, papelaria, brinquedos e eletrônicos em um só lugar. Frete dos Correios calculado na hora e pagamento seguro pelo Mercado Pago.",
} as const;
