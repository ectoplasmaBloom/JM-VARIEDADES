/**
 * Cliente HTTP para componentes "use client" consumirem as rotas REST.
 * Lança ApiError com a mensagem padronizada do backend.
 */
export class ApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly code?: string,
    readonly fields?: Record<string, string[] | undefined>,
  ) {
    super(message);
  }
}

interface ApiEnvelope<T> {
  data?: T;
  error?: { code: string; message: string; fields?: Record<string, string[] | undefined> };
}

export async function api<T>(
  path: string,
  init: Omit<RequestInit, "body"> & { body?: unknown } = {},
): Promise<T> {
  const isForm = init.body instanceof FormData;
  const res = await fetch(path, {
    ...init,
    headers: isForm ? init.headers : { "Content-Type": "application/json", ...init.headers },
    body: init.body === undefined ? undefined : isForm ? (init.body as FormData) : JSON.stringify(init.body),
  });

  const json = (await res.json().catch(() => ({}))) as ApiEnvelope<T>;
  if (!res.ok || json.error) {
    throw new ApiError(json.error?.message ?? fallbackMessage(res.status), res.status, json.error?.code, json.error?.fields);
  }
  return json.data as T;
}

/** Mensagem amigável quando a resposta não traz o erro padronizado da API. */
function fallbackMessage(status: number): string {
  if (status === 401) return "Sua sessão expirou. Entre novamente.";
  if (status === 403) return "Você não tem permissão para esta ação.";
  if (status === 404) return "Não encontrado.";
  if (status === 422) return "Alguns dados estão inválidos. Revise o formulário.";
  if (status >= 500) return "Erro no servidor. Tente novamente em instantes.";
  return "Algo deu errado. Tente novamente.";
}

export function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : "Algo deu errado. Tente novamente.";
}
