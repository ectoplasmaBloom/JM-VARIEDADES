import "server-only";
import { z } from "zod";

/**
 * Variáveis de ambiente validadas em tempo de execução.
 * Nenhuma chave de API é escrita no código: tudo vem daqui.
 */
const schema = z.object({
  POSTGRES_PRISMA_URL: z.string().min(1),
  APP_URL: z.string().url().default("http://localhost:3000"),

  /** mercadopago = Checkout Pro real; mock = pagamento simulado (MVP/apresentação) */
  PAYMENT_PROVIDER: z.enum(["mercadopago", "mock"]).default("mercadopago"),
  MP_ACCESS_TOKEN: z.string().default(""),
  MP_WEBHOOK_SECRET: z.string().default(""),
  MP_NOTIFICATION_BASE_URL: z.string().default(""),

  SHIPPING_PROVIDER: z.enum(["mock", "correios"]).default("mock"),
  /** CEP de onde a loja despacha os pedidos */
  SHIPPING_ORIGIN_CEP: z.string().regex(/^\d{8}$/).default("01001000"),
  CORREIOS_API_URL: z.string().url().default("https://api.correios.com.br"),
  CORREIOS_USER: z.string().default(""),
  CORREIOS_ACCESS_CODE: z.string().default(""),
  CORREIOS_POSTCARD: z.string().default(""),
  CORREIOS_SERVICES: z.string().default("03298:PAC,03220:SEDEX"),

  BLOB_READ_WRITE_TOKEN: z.string().default(""),

  SMTP_HOST: z.string().default(""),
  SMTP_PORT: z.coerce.number().default(587),
  SMTP_USER: z.string().default(""),
  SMTP_PASS: z.string().default(""),
  MAIL_FROM: z.string().default("JM VARIEDADES <no-reply@jmvariedades.local>"),

  CRON_SECRET: z.string().default(""),
  ORDER_PENDING_TTL_MINUTES: z.coerce.number().int().positive().default(1440),
});

export type Env = z.infer<typeof schema>;

let cached: Env | undefined;

export function env(): Env {
  if (!cached) {
    const parsed = schema.safeParse(process.env);
    if (!parsed.success) {
      throw new Error(
        `Variáveis de ambiente inválidas: ${JSON.stringify(parsed.error.flatten().fieldErrors)}`,
      );
    }
    cached = parsed.data;
  }
  return cached;
}
