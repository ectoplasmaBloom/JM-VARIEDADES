import type { Metadata } from "next";
import Link from "next/link";
import { ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/shared/empty-state";
import { CartView } from "@/components/cart/cart-view";
import { requireUser } from "@/server/session";
import { getCart } from "@/server/services/cart.service";
import { listAddresses } from "@/server/services/user.service";

export const metadata: Metadata = { title: "Carrinho" };
export const dynamic = "force-dynamic";

export default async function CartPage() {
  const user = await requireUser();
  const [cart, addresses] = await Promise.all([getCart(user.id), listAddresses(user.id)]);

  return (
    <div className="mx-auto max-w-6xl px-6 py-14">
      <h1 className="mb-12 border-b border-line pb-8 text-5xl">Carrinho</h1>
      {cart.items.length === 0 ? (
        <EmptyState
          icon={<ShoppingCart />}
          title="Seu carrinho está vazio"
          description="Encontre produtos incríveis no catálogo."
          action={
            <Button asChild>
              <Link href="/products">Ver produtos</Link>
            </Button>
          }
        />
      ) : (
        <CartView cart={cart} defaultCep={addresses.find((a) => a.isDefault)?.cep ?? addresses[0]?.cep ?? null} />
      )}
    </div>
  );
}
