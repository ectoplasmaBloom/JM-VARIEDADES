import type { Metadata } from "next";
import { AddressBook } from "@/components/account/address-book";
import { requireUser } from "@/server/session";
import { listAddresses } from "@/server/services/user.service";

export const metadata: Metadata = { title: "Meus endereços" };
export const dynamic = "force-dynamic";

export default async function AddressesPage() {
  const user = await requireUser();
  const addresses = await listAddresses(user.id);
  return (
    <div className="mx-auto max-w-3xl px-6 py-14">
      <h1 className="mb-12 border-b border-line pb-8 text-5xl">Meus endereços</h1>
      <AddressBook initial={addresses} />
    </div>
  );
}
