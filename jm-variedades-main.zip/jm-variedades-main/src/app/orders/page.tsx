import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Package } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { EmptyState } from "@/components/shared/empty-state";
import { OrderStatusBadge } from "@/components/shared/status-badge";
import { requireUser } from "@/server/session";
import { listBuyerOrders } from "@/server/services/order.service";
import { formatBRL, formatDate } from "@/lib/utils";

export const metadata: Metadata = { title: "Minhas compras" };
export const dynamic = "force-dynamic";

export default async function OrdersPage() {
  const user = await requireUser();
  const orders = await listBuyerOrders(user.id);

  return (
    <div className="mx-auto max-w-4xl px-6 py-14">
      <h1 className="mb-12 border-b border-line pb-8 text-5xl">Minhas compras</h1>
      {orders.length === 0 ? (
        <EmptyState
          icon={<Package />}
          title="Você ainda não fez compras"
          action={
            <Button asChild>
              <Link href="/products">Explorar produtos</Link>
            </Button>
          }
        />
      ) : (
        <div className="space-y-3">
          {orders.map((order) => {
            const first = order.items[0];
            const more = order.items.length - 1;
            return (
              <Card key={order.id} className="py-4">
                <CardContent className="flex flex-wrap items-center gap-4">
                  <div className="relative size-16 shrink-0 overflow-hidden rounded-sm bg-sand">
                    {first?.imageUrl && <Image src={first.imageUrl} alt="" fill sizes="64px" className="object-contain p-1" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="mb-1 flex items-center gap-2">
                      <OrderStatusBadge status={order.status} />
                      <span className="text-xs text-muted-foreground">{formatDate(order.createdAt)}</span>
                    </div>
                    <p className="truncate text-sm font-medium">
                      {first?.title}
                      {more > 0 && <span className="text-muted-foreground"> e mais {more} item(ns)</span>}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Pedido #{order.id.slice(-8).toUpperCase()}
                      {order.payments[0] && <> · Pagamento {order.payments[0].externalId}</>}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">{formatBRL(order.total)}</p>
                    <Link href={`/orders/${order.id}`} className="link text-sm">
                      Ver detalhes
                    </Link>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
