import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { NotFoundError, ForbiddenError } from "@/domain/errors";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { OrderStatusBadge, PaymentStatusBadge, ShipmentStatusBadge } from "@/components/shared/status-badge";
import { ORDER_STATUS_LABEL } from "@/domain/payment";
import { requireUser } from "@/server/session";
import { getOrderForUser, type ShippingAddressSnapshot } from "@/server/services/order.service";
import { formatBRL, formatCep, formatDate } from "@/lib/utils";

export const metadata: Metadata = { title: "Detalhes do pedido" };
export const dynamic = "force-dynamic";

export default async function OrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireUser();
  const order = await getOrderForUser(user, (await params).id).catch((e: unknown) => {
    if (e instanceof NotFoundError || e instanceof ForbiddenError) notFound();
    throw e;
  });

  const address = order.shippingAddress as unknown as ShippingAddressSnapshot;
  const isBuyer = order.buyerId === user.id;

  return (
    <div className="mx-auto max-w-5xl space-y-8 px-6 py-14">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-5xl">Pedido #{order.id.slice(-8).toUpperCase()}</h1>
          <p className="text-sm text-muted-foreground">Realizado em {formatDate(order.createdAt)}</p>
        </div>
        <div className="flex items-center gap-2">
          <OrderStatusBadge status={order.status} />
          {isBuyer && order.status === "PENDING" && order.paymentUrl && (
            <Button asChild size="sm">
              <a href={order.paymentUrl}>Pagar agora</a>
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Itens</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Produto</TableHead>
                  <TableHead className="text-right">Qtd.</TableHead>
                  <TableHead className="text-right">Subtotal</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {order.items.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>
                      <Link href={`/products/${item.product.slug}`} className="link-hover">
                        {item.title}
                      </Link>
                      <p className="text-xs text-muted-foreground">{formatBRL(item.unitPrice)} cada</p>
                    </TableCell>
                    <TableCell className="text-right">{item.quantity}</TableCell>
                    <TableCell className="text-right">{formatBRL(item.subtotal)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Resumo</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <Row label="Produtos" value={formatBRL(order.subtotal)} />
            <Row label={`Frete (${order.shippingService})`} value={formatBRL(order.shippingTotal)} />
            <Separator />
            <Row label="Total" value={formatBRL(order.total)} strong />
            <Separator />
            <p className="font-medium">Entrega</p>
            <p className="text-muted-foreground">
              {address.recipient}
              <br />
              {address.street}, {address.number}
              {address.complement ? ` - ${address.complement}` : ""}
              <br />
              {address.district} · {address.city}/{address.state}
              <br />
              CEP {formatCep(address.cep)}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Envios (Correios)</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          {order.shipments.map((s) => (
            <div key={s.id} className="flex flex-wrap items-center justify-between gap-2 rounded-md border p-3">
              <div>
                <p className="font-medium">
                  Correios {s.service}
                </p>
                <p className="text-xs text-muted-foreground">
                  De {formatCep(s.originCep)} para {formatCep(s.destinationCep)} · {s.deadlineDays} dias úteis · {formatBRL(s.price)}
                </p>
                {s.trackingCode && (
                  <a
                    href={`https://rastreamento.correios.com.br/app/index.php?objeto=${s.trackingCode}`}
                    target="_blank"
                    rel="noreferrer"
                    className="link text-xs"
                  >
                    Rastrear {s.trackingCode}
                  </a>
                )}
              </div>
              <ShipmentStatusBadge status={s.status} />
            </div>
          ))}
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Pagamentos (Mercado Pago)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            {order.payments.length === 0 && <p className="text-muted-foreground">Nenhum pagamento registrado ainda.</p>}
            {order.payments.map((p) => (
              <div key={p.id} className="rounded-md border p-3">
                <div className="flex items-center justify-between">
                  <p className="font-medium">Código {p.externalId}</p>
                  <PaymentStatusBadge status={p.status} />
                </div>
                <p className="text-xs text-muted-foreground">
                  {p.paymentMethod ?? "—"} · {formatBRL(p.amount)} · {p.statusDetail ?? ""}
                </p>
                {p.transactions.length > 0 && (
                  <ul className="mt-2 space-y-0.5 border-t pt-2 text-xs text-muted-foreground">
                    {p.transactions.map((t) => (
                      <li key={t.id}>
                        {formatDate(t.createdAt)} — {t.status} ({t.source})
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Histórico do pedido</CardTitle>
          </CardHeader>
          <CardContent>
            <ol className="relative space-y-5 border-l border-line pl-6 text-sm">
              {order.statusHistory.map((h) => (
                <li key={h.id}>
                  <span className="absolute -left-[5px] mt-1.5 size-2 rounded-full bg-gold" />
                  <p className="font-medium">{ORDER_STATUS_LABEL[h.toStatus]}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatDate(h.createdAt)}
                    {h.reason ? ` — ${h.reason}` : ""}
                  </p>
                </li>
              ))}
            </ol>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className={`flex justify-between ${strong ? "text-base font-semibold" : ""}`}>
      <span>{label}</span>
      <span>{value}</span>
    </div>
  );
}
