import type { Metadata } from "next";
import Link from "next/link";
import { AuthCard } from "@/components/auth/auth-card";
import { ResetPasswordForm } from "@/components/auth/reset-password-form";

export const metadata: Metadata = { title: "Redefinir senha" };

export default async function ResetPasswordPage({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const { token } = await searchParams;
  return (
    <AuthCard title="Redefinir senha" description="Escolha uma nova senha para sua conta.">
      {token ? (
        <ResetPasswordForm token={token} />
      ) : (
        <p className="text-sm">
          Link inválido.{" "}
          <Link href="/forgot-password" className="link">
            Solicite um novo
          </Link>
          .
        </p>
      )}
    </AuthCard>
  );
}
