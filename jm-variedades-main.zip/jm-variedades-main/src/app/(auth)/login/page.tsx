import type { Metadata } from "next";
import Link from "next/link";
import { AuthCard, Notice } from "@/components/auth/auth-card";
import { LoginForm } from "@/components/auth/login-form";

export const metadata: Metadata = { title: "Entrar" };

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ callbackUrl?: string; registered?: string; reset?: string }>;
}) {
  const { callbackUrl, registered, reset } = await searchParams;
  // Evita open redirect: o middleware envia URL absoluta; aproveitamos só o caminho interno
  const safeCallback = toInternalPath(callbackUrl);

  return (
    <AuthCard
      title="Entrar"
      description="Acesse sua conta para comprar e vender."
      footer={
        <>
          Não tem conta?{" "}
          <Link href="/register" className="link">
            Cadastre-se
          </Link>
        </>
      }
    >
      {registered && <Notice>Conta criada! Agora é só entrar.</Notice>}
      {reset && <Notice>Senha redefinida! Entre com a nova senha.</Notice>}
      <LoginForm callbackUrl={safeCallback} />
    </AuthCard>
  );
}

function toInternalPath(url: string | undefined): string {
  if (!url) return "/";
  try {
    const parsed = new URL(url, "http://internal");
    return `${parsed.pathname}${parsed.search}` || "/";
  } catch {
    return "/";
  }
}
