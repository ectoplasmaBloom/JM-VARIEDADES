"use client";

import Link from "next/link";
import { useState } from "react";
import { Loader2, MailCheck } from "lucide-react";
import { AuthCard } from "@/components/auth/auth-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { api, errorMessage } from "@/lib/api-client";

export default function ForgotPasswordPage() {
  const [sent, setSent] = useState(false);
  const [devLink, setDevLink] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const result = await api<{ devResetLink?: string }>("/api/auth/forgot-password", {
        method: "POST",
        body: { email: new FormData(e.currentTarget).get("email") },
      });
      setDevLink(result.devResetLink ?? null);
      setSent(true);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthCard
      title="Recuperar senha"
      description="Enviaremos um link para você criar uma nova senha."
      footer={
        <Link href="/login" className="link">
          Voltar para o login
        </Link>
      }
    >
      {sent ? (
        <div className="flex flex-col items-center gap-2 text-center text-sm">
          <MailCheck className="size-10 text-success" />
          <p>Se o e-mail estiver cadastrado, você receberá o link em instantes.</p>
          {devLink && (
            <div className="mt-2 w-full rounded-md border border-dashed p-3 text-xs">
              <p className="mb-2 text-muted-foreground">Ambiente de desenvolvimento sem SMTP: o e-mail não foi enviado.</p>
              <a href={devLink} className="link">
                Abrir link de redefinição de senha
              </a>
            </div>
          )}
        </div>
      ) : (
        <form onSubmit={onSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">E-mail</Label>
            <Input id="email" name="email" type="email" required />
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <Button type="submit" className="w-full" disabled={loading}>
            {loading && <Loader2 className="animate-spin" />} Enviar link
          </Button>
        </form>
      )}
    </AuthCard>
  );
}
