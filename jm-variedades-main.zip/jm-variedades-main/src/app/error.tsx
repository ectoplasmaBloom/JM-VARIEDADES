"use client";

import { Button } from "@/components/ui/button";

export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  const session = error.message.includes("Autenticação") || error.message.includes("suspensa");
  return (
    <div className="px-6 py-32">
      <div className="mx-auto flex max-w-md flex-col items-center gap-5 text-center">
        <p className="eyebrow flex items-center gap-3">
          <span className="rule-gold" /> Algo não saiu como esperado <span className="rule-gold" />
        </p>
        <h1 className="text-5xl">{session ? "Sessão encerrada" : "Não foi possível carregar"}</h1>
        <p className="leading-relaxed text-stone">
          {session ? "Sua sessão expirou ou a conta está inativa. Entre novamente." : "Tente novamente em instantes."}
        </p>
        <Button onClick={reset} className="mt-2">
          Tentar novamente
        </Button>
      </div>
    </div>
  );
}
