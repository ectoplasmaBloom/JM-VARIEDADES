import { ok, parseBody, parseQuery, route } from "@/server/http";
import { requireRole } from "@/server/session";
import { createProduct, listProducts } from "@/server/services/product.service";
import { productQuerySchema, productSchema } from "@/server/validators";

/**
 * GET /api/products?q=&category=&minPrice=&maxPrice=&sort=&page=&pageSize=
 * Catálogo público com busca, filtros e paginação.
 */
export const GET = route(async (req) => ok(await listProducts(parseQuery(req, productQuerySchema))));

/** POST /api/products — cadastro de produto (equipe da loja) */
export const POST = route(async (req) => {
  await requireRole("ADMIN");
  const input = await parseBody(req, productSchema);
  return ok(await createProduct(input), 201);
});
