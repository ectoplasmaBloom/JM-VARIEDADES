import { NotFoundError } from "@/domain/errors";
import { ok, parseBody, route } from "@/server/http";
import { requireRole } from "@/server/session";
import {
  deleteProduct,
  getPublicProductById,
  updateProduct,
} from "@/server/services/product.service";
import { productUpdateSchema } from "@/server/validators";

type Ctx = { params: Promise<{ id: string }> };

/** GET /api/products/:id — detalhe público */
export const GET = route<Ctx>(async (_req, { params }) => {
  const product = await getPublicProductById((await params).id);
  if (!product) throw new NotFoundError("Produto");
  return ok(product);
});

/** PATCH /api/products/:id — edição (equipe da loja) */
export const PATCH = route<Ctx>(async (req, { params }) => {
  await requireRole("ADMIN");
  const input = await parseBody(req, productUpdateSchema);
  return ok(await updateProduct((await params).id, input));
});

/** DELETE /api/products/:id — exclusão lógica (equipe da loja) */
export const DELETE = route<Ctx>(async (_req, { params }) => {
  await requireRole("ADMIN");
  await deleteProduct((await params).id);
  return ok({ deleted: true });
});
