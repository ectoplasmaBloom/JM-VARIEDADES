import { z } from "zod";
import { ForbiddenError, NotFoundError, ValidationError } from "@/domain/errors";
import { prisma } from "@/infrastructure/db/prisma";
import { isMockPayment, paymentGateway } from "@/infrastructure/payment";
import { MockPaymentGateway } from "@/infrastructure/payment/mock-gateway";
import { ok, parseBody, route } from "@/server/http";
import { requireUser } from "@/server/session";
import { processPaymentNotification } from "@/server/services/payment.service";

const schema = z.object({
  orderId: z.string().min(1),
  outcome: z.enum(["approved", "rejected", "pending"]),
});

/**
 * POST /api/payments/mock { orderId, outcome }
 * Somente com PAYMENT_PROVIDER=mock: simula o pagamento do pedido e processa o
 * resultado pelo mesmo caso de uso do webhook do Mercado Pago.
 */
export const POST = route(async (req) => {
  if (!isMockPayment()) throw new ForbiddenError("Pagamento simulado desativado (PAYMENT_PROVIDER != mock)");
  const user = await requireUser();
  const { orderId, outcome } = await parseBody(req, schema);

  const order = await prisma.order.findUnique({ where: { id: orderId }, select: { buyerId: true, status: true } });
  if (!order) throw new NotFoundError("Pedido");
  if (order.buyerId !== user.id) throw new ForbiddenError();
  if (order.status !== "PENDING") throw new ValidationError("Este pedido não está aguardando pagamento");

  const gateway = paymentGateway() as MockPaymentGateway;
  const externalId = await gateway.simulate(orderId, outcome);
  const result = await processPaymentNotification(externalId, "mock", gateway);
  return ok({ externalId, ...result });
});
