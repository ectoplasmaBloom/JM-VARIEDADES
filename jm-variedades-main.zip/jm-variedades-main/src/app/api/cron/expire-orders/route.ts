import { NextResponse } from "next/server";
import { env } from "@/lib/env";
import { expirePendingOrders } from "@/server/services/order.service";

export const dynamic = "force-dynamic";

/**
 * GET /api/cron/expire-orders — executado pelo Vercel Cron (ver vercel.json).
 * A Vercel envia "Authorization: Bearer <CRON_SECRET>".
 */
export async function GET(req: Request): Promise<Response> {
  const { CRON_SECRET, ORDER_PENDING_TTL_MINUTES } = env();
  if (!CRON_SECRET || req.headers.get("authorization") !== `Bearer ${CRON_SECRET}`) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  const cancelled = await expirePendingOrders(ORDER_PENDING_TTL_MINUTES);
  return NextResponse.json({ cancelled });
}
