import { ok, route } from "@/server/http";
import { requireUser } from "@/server/session";
import { listBuyerOrders } from "@/server/services/order.service";

/** GET /api/orders — histórico de pedidos do comprador logado */
export const GET = route(async () => {
  const user = await requireUser();
  return ok(await listBuyerOrders(user.id));
});
