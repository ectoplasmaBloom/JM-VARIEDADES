import { ok, route } from "@/server/http";
import { requireUser } from "@/server/session";
import { getOrderForUser } from "@/server/services/order.service";

type Ctx = { params: Promise<{ id: string }> };

/** GET /api/orders/:id — detalhes (cliente dono do pedido ou equipe da loja) */
export const GET = route<Ctx>(async (_req, { params }) => {
  const user = await requireUser();
  return ok(await getOrderForUser(user, (await params).id));
});
