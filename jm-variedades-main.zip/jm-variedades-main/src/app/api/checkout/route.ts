import { ok, parseBody, route } from "@/server/http";
import { requireUser } from "@/server/session";
import { checkout } from "@/server/services/checkout.service";
import { checkoutSchema } from "@/server/validators";

/**
 * POST /api/checkout { addressId, serviceCode }
 * Cria o pedido a partir do carrinho e a preferência no Mercado Pago.
 * Resposta: { orderId, paymentUrl } — o cliente é redirecionado para paymentUrl.
 */
export const POST = route(async (req) => {
  const user = await requireUser();
  const input = await parseBody(req, checkoutSchema);
  return ok(await checkout(user, input), 201);
});
