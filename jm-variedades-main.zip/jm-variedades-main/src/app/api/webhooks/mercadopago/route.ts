import { NextResponse } from "next/server";
import { env } from "@/lib/env";
import { verifyMercadoPagoSignature } from "@/infrastructure/payment/webhook-signature";
import { processPaymentNotification } from "@/server/services/payment.service";

export const dynamic = "force-dynamic";

interface WebhookBody {
  type?: string;
  action?: string;
  topic?: string;
  data?: { id?: string | number };
  resource?: string;
}

/**
 * POST /api/webhooks/mercadopago
 *
 * Aceita os dois formatos de notificação do Mercado Pago:
 *  - Webhooks: ?type=payment&data.id=123  + body { type: "payment", data: { id } }
 *  - IPN legado: ?topic=payment&id=123
 *
 * 1. Valida a assinatura x-signature (quando MP_WEBHOOK_SECRET configurado)
 * 2. Consulta o pagamento na API do MP (fonte da verdade)
 * 3. Atualiza pagamento, histórico e status do pedido
 *
 * Responde 200 rapidamente; erros transitórios retornam 500 para o MP reenviar.
 */
export async function POST(req: Request): Promise<Response> {
  const url = new URL(req.url);
  const body = (await req.json().catch(() => ({}))) as WebhookBody;

  const type = url.searchParams.get("type") ?? url.searchParams.get("topic") ?? body.type ?? body.topic;
  const dataId =
    url.searchParams.get("data.id") ??
    url.searchParams.get("id") ??
    (body.data?.id !== undefined ? String(body.data.id) : null);

  const secret = env().MP_WEBHOOK_SECRET;
  if (secret) {
    const valid = verifyMercadoPagoSignature({
      secret,
      signatureHeader: req.headers.get("x-signature"),
      requestId: req.headers.get("x-request-id"),
      dataId: url.searchParams.get("data.id") ?? dataId,
    });
    if (!valid) {
      console.warn("[webhook:mp] assinatura inválida", { dataId });
      return NextResponse.json({ error: "invalid signature" }, { status: 401 });
    }
  }

  if (type !== "payment" || !dataId || !/^\d+$/.test(dataId)) {
    // merchant_order, plan, etc. não são usados pela loja
    return NextResponse.json({ received: true, ignored: true });
  }

  try {
    const result = await processPaymentNotification(dataId, "webhook");
    console.info("[webhook:mp]", dataId, result);
    return NextResponse.json({ received: true, ...result });
  } catch (error) {
    console.error("[webhook:mp] falha ao processar", dataId, error);
    return NextResponse.json({ error: "processing failed" }, { status: 500 });
  }
}

/** GET de verificação manual (útil para testar se a URL pública está acessível). */
export function GET(): Response {
  return NextResponse.json({ ok: true, endpoint: "mercadopago-webhook" });
}
