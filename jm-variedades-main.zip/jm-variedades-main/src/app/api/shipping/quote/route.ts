import { ok, parseBody, route } from "@/server/http";
import { requireUser } from "@/server/session";
import { quoteCart, quoteProduct } from "@/server/services/shipping.service";
import { shippingQuoteSchema } from "@/server/validators";

/**
 * POST /api/shipping/quote
 *  { destinationCep, productId, quantity } -> frete de um produto (público)
 *  { destinationCep }                      -> frete do carrinho do usuário logado
 */
export const POST = route(async (req) => {
  const input = await parseBody(req, shippingQuoteSchema);
  if (input.productId) {
    return ok(await quoteProduct(input.productId, input.quantity, input.destinationCep));
  }
  const user = await requireUser();
  return ok(await quoteCart(user.id, input.destinationCep));
});
