import { ValidationError } from "@/domain/errors";
import { ALLOWED_IMAGE_TYPES, MAX_IMAGE_BYTES, fileStorage, sniffImageType } from "@/infrastructure/storage/file-storage";
import { ok, route } from "@/server/http";
import { requireRole } from "@/server/session";

/**
 * POST /api/uploads (multipart/form-data, campo "files")
 * Upload de imagens de produtos. Valida tipo (JPEG/PNG/WEBP) e tamanho (4 MB).
 */
export const POST = route(async (req) => {
  await requireRole("ADMIN");
  const form = await req.formData().catch(() => {
    throw new ValidationError("Envie os arquivos como multipart/form-data");
  });

  const files = form.getAll("files").filter((f): f is File => f instanceof File);
  if (files.length === 0) throw new ValidationError("Nenhum arquivo enviado");
  if (files.length > 8) throw new ValidationError("Máximo de 8 imagens por envio");

  for (const file of files) {
    if (file.size > MAX_IMAGE_BYTES) throw new ValidationError(`${file.name} excede 4 MB`);
    const realType = await sniffImageType(file);
    if (!realType || !ALLOWED_IMAGE_TYPES.includes(file.type) || realType !== file.type) {
      throw new ValidationError(`Formato não suportado: ${file.name} (use JPG, PNG ou WEBP)`);
    }
  }

  const storage = fileStorage();
  const urls = await Promise.all(files.map((f) => storage.save(f, "products")));
  return ok({ urls }, 201);
});
