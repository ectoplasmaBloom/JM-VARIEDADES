import { ok, route } from "@/server/http";
import { requireRole } from "@/server/session";
import { storeDashboard } from "@/server/services/dashboard.service";

/** GET /api/admin/stats — métricas do painel da loja */
export const GET = route(async () => {
  await requireRole("ADMIN");
  return ok(await storeDashboard());
});
