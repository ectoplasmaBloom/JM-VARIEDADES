import { ok, parseBody, route } from "@/server/http";
import { requireRole } from "@/server/session";
import { updateShipment } from "@/server/services/order.service";
import { shipmentUpdateSchema } from "@/server/validators";

type Ctx = { params: Promise<{ id: string }> };

/** PATCH /api/admin/shipments/:id { status, trackingCode? } — postagem e rastreio do envio */
export const PATCH = route<Ctx>(async (req, { params }) => {
  await requireRole("ADMIN");
  const input = await parseBody(req, shipmentUpdateSchema);
  return ok(await updateShipment((await params).id, input));
});
