import { ok, parseBody, route } from "@/server/http";
import { requireRole } from "@/server/session";
import { adminUpdateUser } from "@/server/services/user.service";
import { adminUserUpdateSchema } from "@/server/validators";

type Ctx = { params: Promise<{ id: string }> };

/** PATCH /api/admin/users/:id { status?, role? } — suspender/reativar contas, promover à equipe */
export const PATCH = route<Ctx>(async (req, { params }) => {
  const admin = await requireRole("ADMIN");
  const input = await parseBody(req, adminUserUpdateSchema);
  return ok(await adminUpdateUser(admin, (await params).id, input));
});
