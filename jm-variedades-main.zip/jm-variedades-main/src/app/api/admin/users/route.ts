import { z } from "zod";
import { ok, parseQuery, route } from "@/server/http";
import { requireRole } from "@/server/session";
import { listUsers } from "@/server/services/user.service";

const querySchema = z.object({ role: z.enum(["BUYER", "ADMIN"]).optional() });

/** GET /api/admin/users?role= — clientes e equipe */
export const GET = route(async (req) => {
  await requireRole("ADMIN");
  return ok(await listUsers(parseQuery(req, querySchema).role));
});
