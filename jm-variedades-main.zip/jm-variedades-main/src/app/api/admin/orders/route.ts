import { z } from "zod";
import { ok, parseQuery, route } from "@/server/http";
import { requireRole } from "@/server/session";
import { listStoreOrders } from "@/server/services/order.service";

const querySchema = z.object({ status: z.enum(["PENDING", "APPROVED", "CANCELLED", "REFUNDED"]).optional() });

/** GET /api/admin/orders?status= — pedidos da loja com itens e envio */
export const GET = route(async (req) => {
  await requireRole("ADMIN");
  return ok(await listStoreOrders(parseQuery(req, querySchema).status));
});
