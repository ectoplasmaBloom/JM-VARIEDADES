import { NotFoundError, ValidationError } from "@/domain/errors";
import { prisma } from "@/infrastructure/db/prisma";
import { paymentGateway } from "@/infrastructure/payment";
import { ok, route } from "@/server/http";
import { requireRole } from "@/server/session";
import { processPaymentNotification } from "@/server/services/payment.service";

type Ctx = { params: Promise<{ id: string }> };

/**
 * POST /api/admin/orders/:id/refund
 * Solicita o estorno do pagamento aprovado no Mercado Pago e sincroniza o pedido
 * (o webhook de "refunded" também chegará e será processado de forma idempotente).
 */
export const POST = route<Ctx>(async (_req, { params }) => {
  await requireRole("ADMIN");
  const { id } = await params;

  const payment = await prisma.payment.findFirst({ where: { orderId: id, status: "APPROVED" } });
  if (!payment) {
    const exists = await prisma.order.count({ where: { id } });
    if (!exists) throw new NotFoundError("Pedido");
    throw new ValidationError("Pedido não possui pagamento aprovado para estornar");
  }

  await paymentGateway().refund(payment.externalId);
  return ok(await processPaymentNotification(payment.externalId, "admin_refund"));
});
