import { ok, parseBody, route } from "@/server/http";
import { requireRole } from "@/server/session";
import { setProductStatus } from "@/server/services/product.service";
import { adminProductUpdateSchema } from "@/server/validators";

type Ctx = { params: Promise<{ id: string }> };

/** PATCH /api/admin/products/:id { status } — pausa ou reativa o produto no catálogo */
export const PATCH = route<Ctx>(async (req, { params }) => {
  await requireRole("ADMIN");
  const { status } = await parseBody(req, adminProductUpdateSchema);
  return ok(await setProductStatus((await params).id, status));
});
