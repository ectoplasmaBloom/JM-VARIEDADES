import { z } from "zod";
import { ok, parseQuery, route } from "@/server/http";
import { requireRole } from "@/server/session";
import { listManagedProducts } from "@/server/services/product.service";

const querySchema = z.object({ q: z.string().trim().max(100).optional() });

/** GET /api/admin/products?q= — produtos da loja, inclusive os pausados */
export const GET = route(async (req) => {
  await requireRole("ADMIN");
  return ok(await listManagedProducts(parseQuery(req, querySchema).q));
});
