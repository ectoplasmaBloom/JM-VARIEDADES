import { ok, parseBody, route } from "@/server/http";
import { registerUser } from "@/server/services/user.service";
import { registerSchema } from "@/server/validators";

/** POST /api/auth/register — cadastro de cliente */
export const POST = route(async (req) => {
  const input = await parseBody(req, registerSchema);
  return ok(await registerUser(input), 201);
});
