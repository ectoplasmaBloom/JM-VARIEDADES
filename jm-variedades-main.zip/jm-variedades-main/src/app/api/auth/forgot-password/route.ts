import { ok, parseBody, route } from "@/server/http";
import { requestPasswordReset } from "@/server/services/user.service";
import { forgotPasswordSchema } from "@/server/validators";

/** POST /api/auth/forgot-password — envia link de recuperação (resposta sempre genérica) */
export const POST = route(async (req) => {
  const { email } = await parseBody(req, forgotPasswordSchema);
  const devResetLink = await requestPasswordReset(email);
  return ok({
    message: "Se o e-mail estiver cadastrado, você receberá um link de recuperação.",
    // Somente em desenvolvimento sem SMTP (o e-mail não é enviado de verdade)
    ...(devResetLink ? { devResetLink } : {}),
  });
});
