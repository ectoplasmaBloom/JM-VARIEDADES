import { ok, parseBody, route } from "@/server/http";
import { resetPassword } from "@/server/services/user.service";
import { resetPasswordSchema } from "@/server/validators";

/** POST /api/auth/reset-password — redefine a senha com o token recebido por e-mail */
export const POST = route(async (req) => {
  const { token, password } = await parseBody(req, resetPasswordSchema);
  await resetPassword(token, password);
  return ok({ message: "Senha redefinida com sucesso" });
});
