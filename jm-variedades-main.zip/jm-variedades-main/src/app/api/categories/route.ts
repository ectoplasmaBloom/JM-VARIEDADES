import { ok, route } from "@/server/http";
import { listCategories } from "@/server/services/product.service";

/** GET /api/categories */
export const GET = route(async () => ok(await listCategories()));
