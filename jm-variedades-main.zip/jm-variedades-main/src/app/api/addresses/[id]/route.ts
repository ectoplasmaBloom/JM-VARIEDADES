import { ok, route } from "@/server/http";
import { requireUser } from "@/server/session";
import { deleteAddress } from "@/server/services/user.service";

type Ctx = { params: Promise<{ id: string }> };

/** DELETE /api/addresses/:id */
export const DELETE = route<Ctx>(async (_req, { params }) => {
  const user = await requireUser();
  await deleteAddress(user.id, (await params).id);
  return ok({ deleted: true });
});
