import { ok, parseBody, route } from "@/server/http";
import { requireUser } from "@/server/session";
import { createAddress, listAddresses } from "@/server/services/user.service";
import { addressSchema } from "@/server/validators";

/** GET /api/addresses */
export const GET = route(async () => {
  const user = await requireUser();
  return ok(await listAddresses(user.id));
});

/** POST /api/addresses */
export const POST = route(async (req) => {
  const user = await requireUser();
  const input = await parseBody(req, addressSchema);
  return ok(await createAddress(user.id, input), 201);
});
