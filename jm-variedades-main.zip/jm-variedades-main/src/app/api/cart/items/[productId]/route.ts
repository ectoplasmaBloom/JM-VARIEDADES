import { ok, parseBody, route } from "@/server/http";
import { requireUser } from "@/server/session";
import { getCart, removeItem, updateItemQuantity } from "@/server/services/cart.service";
import { updateCartItemSchema } from "@/server/validators";

type Ctx = { params: Promise<{ productId: string }> };

/** PATCH /api/cart/items/:productId — altera a quantidade { quantity } */
export const PATCH = route<Ctx>(async (req, { params }) => {
  const user = await requireUser();
  const { quantity } = await parseBody(req, updateCartItemSchema);
  await updateItemQuantity(user.id, (await params).productId, quantity);
  return ok(await getCart(user.id));
});

/** DELETE /api/cart/items/:productId — remove o item */
export const DELETE = route<Ctx>(async (_req, { params }) => {
  const user = await requireUser();
  await removeItem(user.id, (await params).productId);
  return ok(await getCart(user.id));
});
