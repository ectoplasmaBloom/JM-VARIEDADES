import { ok, parseBody, route } from "@/server/http";
import { requireUser } from "@/server/session";
import { addItem, clearCart, getCart } from "@/server/services/cart.service";
import { addCartItemSchema } from "@/server/validators";

/** GET /api/cart — carrinho com subtotal e alertas de estoque */
export const GET = route(async () => {
  const user = await requireUser();
  return ok(await getCart(user.id));
});

/** POST /api/cart — adiciona item { productId, quantity } */
export const POST = route(async (req) => {
  const user = await requireUser();
  const { productId, quantity } = await parseBody(req, addCartItemSchema);
  await addItem(user.id, productId, quantity);
  return ok(await getCart(user.id), 201);
});

/** DELETE /api/cart — esvazia o carrinho */
export const DELETE = route(async () => {
  const user = await requireUser();
  await clearCart(user.id);
  return ok(await getCart(user.id));
});
