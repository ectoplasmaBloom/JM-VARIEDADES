import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/product/product-card";
import { listCategories, listProducts, type ProductCardDTO } from "@/server/services/product.service";
import { formatBRL } from "@/lib/utils";
import { STORE } from "@/lib/store";

export const dynamic = "force-dynamic";

const edition = new Intl.DateTimeFormat("pt-BR", { month: "long", year: "numeric" }).format(new Date());

export default async function HomePage({ searchParams }: { searchParams: Promise<{ denied?: string }> }) {
  const [{ denied }, categories, latest, cheapest] = await Promise.all([
    searchParams,
    listCategories(),
    listProducts({ sort: "recent", page: 1, pageSize: 10 }),
    listProducts({ sort: "price_asc", page: 1, pageSize: 5 }),
  ]);
  const featured = latest.items.find((p) => p.image);

  return (
    <div className="pb-4">
      {denied && (
        <p className="mx-auto mt-6 max-w-7xl border-l-2 border-destructive px-6 py-2 text-sm text-destructive">
          Você não tem permissão para acessar aquela página.
        </p>
      )}

      {/* ---------------------------------------------------------------- Hero */}
      <section className="mx-auto grid max-w-7xl items-center gap-14 px-6 pt-16 pb-24 lg:grid-cols-[1.05fr_1fr] lg:pt-24">
        <div className="space-y-9">
          <p className="eyebrow flex items-center gap-3">
            <span className="rule-gold" /> {STORE.name} · {edition}
          </p>
          <h1 className="text-[3.4rem] leading-[0.98] sm:text-7xl lg:text-[5.4rem]">
            De tudo um pouco, <em className="font-normal">escolhido</em> com cuidado.
          </h1>
          <p className="max-w-md text-[17px] leading-relaxed text-stone">
            Casa, cozinha, beleza, moda, papelaria, brinquedos e eletrônicos em um só lugar. Frete dos Correios calculado antes da
            compra e pagamento protegido pelo Mercado Pago.
          </p>
          <div className="flex flex-wrap items-center gap-6">
            <Button asChild size="lg">
              <Link href="/products">
                Ver produtos <ArrowRight strokeWidth={1.5} />
              </Link>
            </Button>
            <Link href="#departamentos" className="link text-sm">
              Ver departamentos
            </Link>
          </div>
          <dl className="grid max-w-md grid-cols-3 divide-x divide-line border-t border-line pt-6">
            <Fact value={String(latest.total)} label="Produtos" />
            <Fact value={String(categories.length)} label="Departamentos" />
            <Fact value="24h" label="Para despacho" />
          </dl>
        </div>

        {featured && <FeaturedProduct product={featured} />}
      </section>

      {/* ---------------------------------------------------------- Categorias */}
      <section id="departamentos" className="mx-auto max-w-7xl scroll-mt-40 px-6 pb-24">
        <SectionHeading eyebrow="Explore" title="Departamentos" />
        <div className="grid grid-cols-1 border-t border-l border-line sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((c, i) => (
            <Link
              key={c.id}
              href={`/products?category=${c.slug}`}
              className="group flex items-end justify-between gap-4 border-r border-b border-line px-6 py-8 transition-colors duration-500 hover:bg-card"
            >
              <span>
                <span className="block font-serif text-sm text-gold-deep tabular-nums">{String(i + 1).padStart(2, "0")}</span>
                <span className="mt-2 block font-serif text-3xl">{c.name}</span>
              </span>
              <ArrowUpRight
                className="size-5 text-stone opacity-0 transition-all duration-500 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-ink group-hover:opacity-100"
                strokeWidth={1.25}
              />
            </Link>
          ))}
        </div>
      </section>

      <ProductSection eyebrow="Recém-chegados" title="Novidades" href="/products?sort=recent" products={latest.items} />

      {/* ------------------------------------------------------ Como funciona */}
      <section className="border-y border-line bg-card">
        <div className="mx-auto max-w-7xl px-6 py-24">
          <SectionHeading eyebrow="A experiência" title="Simples, do início ao fim" />
          <ol className="grid gap-12 md:grid-cols-3">
            <Step n="I" title="Escolha com calma" text="Um mix variado e bem escolhido, com estoque próprio e preço claro." />
            <Step n="II" title="Frete sem surpresa" text="Informe seu CEP e veja preço e prazo dos Correios antes de decidir." />
            <Step n="III" title="Pague com segurança" text="Pix, cartão ou boleto pelo Mercado Pago. Sem aprovação, sem cobrança." />
          </ol>
        </div>
      </section>

      <div className="pt-24">
        <ProductSection eyebrow="Seleção acessível" title="Menores preços" href="/products?sort=price_asc" products={cheapest.items} />
      </div>

      {/* ------------------------------------------------------------ A loja */}
      <section className="mx-auto max-w-7xl px-6">
        <div className="grid gap-10 rounded-lg bg-ink px-8 py-16 text-ivory md:grid-cols-[1.4fr_1fr] md:items-end md:px-14">
          <div className="space-y-5">
            <p className="text-[11px] tracking-[0.22em] text-gold uppercase">{STORE.name}</p>
            <h2 className="text-4xl leading-tight text-ivory md:text-5xl">
              Uma loja, <em>muitas</em> variedades.
            </h2>
          </div>
          <div className="space-y-6">
            <p className="text-sm leading-relaxed text-ivory/60">
              Estoque próprio, separação cuidadosa e despacho pelos Correios em até 24 horas após a confirmação do pagamento, com
              rastreio do começo ao fim.
            </p>
            <Button asChild variant="outline" size="lg" className="border-ivory/30 text-ivory hover:border-ivory hover:bg-ivory hover:text-ink">
              <Link href="/products">
                Conhecer a loja <ArrowRight strokeWidth={1.5} />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}

function Fact({ value, label }: { value: string; label: string }) {
  return (
    <div className="px-4 first:pl-0">
      <dd className="font-serif text-3xl tabular-nums">{value}</dd>
      <dt className="mt-1 text-[11px] tracking-[0.14em] text-stone uppercase">{label}</dt>
    </div>
  );
}

function FeaturedProduct({ product }: { product: ProductCardDTO }) {
  return (
    <Link href={`/products/${product.slug}`} className="group relative mx-auto block w-full max-w-md lg:max-w-none">
      <div className="relative aspect-[4/5] overflow-hidden rounded-md bg-sand">
        <Image
          src={product.image!}
          alt={product.title}
          fill
          priority
          sizes="(max-width: 1024px) 100vw, 560px"
          className="object-cover transition-transform duration-[1600ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.03]"
        />
      </div>
      <div className="absolute -bottom-8 left-6 right-6 flex items-end justify-between gap-4 rounded-md border border-line bg-card/95 px-6 py-5 shadow-soft backdrop-blur sm:right-auto sm:min-w-80">
        <div className="min-w-0">
          <p className="eyebrow">Em destaque</p>
          <p className="mt-1.5 truncate font-serif text-xl">{product.title}</p>
        </div>
        <p className="price shrink-0 text-sm">{formatBRL(product.price)}</p>
      </div>
    </Link>
  );
}

function SectionHeading({ eyebrow, title, href }: { eyebrow: string; title: string; href?: string }) {
  return (
    <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
      <div>
        <p className="eyebrow flex items-center gap-3">
          <span className="rule-gold" /> {eyebrow}
        </p>
        <h2 className="mt-3 text-4xl md:text-5xl">{title}</h2>
      </div>
      {href && (
        <Link href={href} className="group flex items-center gap-2 text-sm text-ink link-hover">
          Ver todos <ArrowRight className="size-4 transition-transform duration-500 group-hover:translate-x-1" strokeWidth={1.5} />
        </Link>
      )}
    </div>
  );
}

function ProductSection({ eyebrow, title, href, products }: { eyebrow: string; title: string; href: string; products: ProductCardDTO[] }) {
  if (products.length === 0) return null;
  return (
    <section className="mx-auto max-w-7xl px-6 pb-24">
      <SectionHeading eyebrow={eyebrow} title={title} href={href} />
      <div className="grid grid-cols-2 gap-x-6 gap-y-12 sm:grid-cols-3 lg:grid-cols-5">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  );
}

function Step({ n, title, text }: { n: string; title: string; text: string }) {
  return (
    <li className="border-t border-ink/15 pt-6">
      <span className="font-serif text-lg text-gold-deep">{n}</span>
      <h3 className="mt-3 text-2xl">{title}</h3>
      <p className="mt-2 max-w-xs text-sm leading-relaxed text-stone">{text}</p>
    </li>
  );
}
