import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ShieldCheck } from "lucide-react";
import { ProductCard } from "@/components/product/product-card";
import { ProductGallery } from "@/components/product/product-gallery";
import { ProductPurchasePanel } from "@/components/product/product-purchase-panel";
import { currentUser } from "@/server/session";
import { getProductBySlug, listRelatedProducts } from "@/server/services/product.service";
import { listAddresses } from "@/server/services/user.service";
import { formatBRL } from "@/lib/utils";
import { STORE } from "@/lib/store";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const product = await getProductBySlug((await params).slug);
  return { title: product?.title ?? "Produto não encontrado" };
}

export default async function ProductPage({ params }: Props) {
  const product = await getProductBySlug((await params).slug);
  if (!product) notFound();

  const user = await currentUser();
  const [related, addresses] = await Promise.all([
    listRelatedProducts(product.categorySlug, product.id),
    user ? listAddresses(user.id) : Promise.resolve([]),
  ]);
  // CEP padrão do comprador: o frete é calculado automaticamente ao abrir a página
  const defaultCep = addresses.find((a) => a.isDefault)?.cep ?? addresses[0]?.cep ?? null;

  const installment = formatBRL(Math.ceil((product.price / 12) * 100) / 100);

  return (
    <div className="mx-auto max-w-7xl px-6 pt-10">
      <nav className="eyebrow mb-10 flex flex-wrap items-center gap-2">
        <Link href="/products" className="transition hover:text-ink">
          Produtos
        </Link>
        <span>/</span>
        <Link href={`/products?category=${product.categorySlug}`} className="transition hover:text-ink">
          {product.categoryName}
        </Link>
      </nav>

      <div className="grid gap-12 lg:grid-cols-[1.25fr_1fr] lg:gap-20">
        <ProductGallery images={product.images} title={product.title} />

        <aside className="lg:sticky lg:top-40 lg:self-start">
          <p className="eyebrow">{product.categoryName}</p>
          <h1 className="mt-3 text-4xl leading-[1.05] md:text-5xl">{product.title}</h1>
          <p className="price mt-6 text-2xl">{formatBRL(product.price)}</p>
          <p className="mt-1 text-sm text-stone">ou 12x de {installment} no Mercado Pago</p>
          <p className="mt-4 text-xs tracking-[0.14em] uppercase">
            {product.stock > 0 ? (
              <span className={product.stock <= 5 ? "text-gold-deep" : "text-stone"}>
                {product.stock <= 5 ? `Últimas ${product.stock} unidades` : `${product.stock} disponíveis`}
              </span>
            ) : (
              <span className="text-stone">Esgotado</span>
            )}
          </p>

          <ProductPurchasePanel
            productId={product.id}
            stock={product.stock}
            isLoggedIn={Boolean(user)}
            defaultCep={defaultCep}
          />

          <div className="mt-10 divide-y divide-line border-y border-line">
            <Detail title="Sobre o produto">
              <p className="leading-relaxed whitespace-pre-line text-stone">{product.description}</p>
            </Detail>
            <Detail title="Características">
              <dl className="grid grid-cols-[auto_1fr] gap-x-8 gap-y-2 text-sm">
                <dt className="text-stone">Peso</dt>
                <dd>{product.weightGrams} g</dd>
                <dt className="text-stone">Dimensões</dt>
                <dd>
                  {product.lengthCm} × {product.widthCm} × {product.heightCm} cm
                </dd>
                <dt className="text-stone">Categoria</dt>
                <dd>{product.categoryName}</dd>
              </dl>
            </Detail>
            <Detail title="Compra garantida">
              <p className="flex items-start gap-3 text-sm leading-relaxed text-stone">
                <ShieldCheck className="mt-0.5 size-4 shrink-0 text-gold-deep" strokeWidth={1.5} />
                Vendido e entregue por {STORE.name}. Se o pagamento não for aprovado, nada é cobrado; após a compra, acompanhe o envio
                com rastreio dos Correios.
              </p>
            </Detail>
          </div>
        </aside>
      </div>

      {related.length > 0 && (
        <section className="mt-28">
          <p className="eyebrow flex items-center gap-3">
            <span className="rule-gold" /> Da mesma categoria
          </p>
          <h2 className="mt-3 mb-10 text-4xl md:text-5xl">Você também pode gostar</h2>
          <div className="grid grid-cols-2 gap-x-6 gap-y-12 md:grid-cols-4">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function Detail({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <details className="group py-5" open={title === "Sobre o produto"}>
      <summary className="flex cursor-pointer list-none items-center justify-between font-serif text-xl [&::-webkit-details-marker]:hidden">
        {title}
        <span aria-hidden className="text-stone transition-transform duration-300 group-open:rotate-45">
          +
        </span>
      </summary>
      <div className="pt-4">{children}</div>
    </details>
  );
}
