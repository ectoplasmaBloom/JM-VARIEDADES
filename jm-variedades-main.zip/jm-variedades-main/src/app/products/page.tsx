import type { Metadata } from "next";
import Link from "next/link";
import { SearchX, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/product/product-card";
import { CatalogFilters } from "@/components/product/catalog-filters";
import { Pagination } from "@/components/shared/pagination";
import { EmptyState } from "@/components/shared/empty-state";
import { listCategories, listProducts } from "@/server/services/product.service";
import { productQuerySchema } from "@/server/validators";
import { formatBRL } from "@/lib/utils";

export const metadata: Metadata = { title: "Produtos" };
export const dynamic = "force-dynamic";

type SearchParams = Record<string, string | string[] | undefined>;

const SORT_LABEL = { recent: "Mais recentes", price_asc: "Menor preço", price_desc: "Maior preço" } as const;

export default async function CatalogPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  const raw = await searchParams;
  const flat = Object.fromEntries(Object.entries(raw).map(([k, v]) => [k, Array.isArray(v) ? v[0] : v]));
  const parsed = productQuerySchema.safeParse(flat);
  const query = parsed.success ? parsed.data : productQuerySchema.parse({});

  const [result, categories] = await Promise.all([listProducts(query), listCategories()]);
  const currentCategory = categories.find((c) => c.slug === query.category);

  const params = {
    q: query.q,
    category: query.category,
    minPrice: query.minPrice?.toString(),
    maxPrice: query.maxPrice?.toString(),
    sort: query.sort,
  };

  const without = (key: keyof typeof params) => {
    const qs = new URLSearchParams();
    for (const [k, v] of Object.entries({ ...params, [key]: undefined })) if (v) qs.set(k, v);
    return `/products?${qs}`;
  };
  const activeFilters = [
    query.q && { key: "q" as const, label: `“${query.q}”` },
    currentCategory && { key: "category" as const, label: currentCategory.name },
    query.minPrice !== undefined && { key: "minPrice" as const, label: `a partir de ${formatBRL(query.minPrice)}` },
    query.maxPrice !== undefined && { key: "maxPrice" as const, label: `até ${formatBRL(query.maxPrice)}` },
  ].filter(Boolean) as Array<{ key: keyof typeof params; label: string }>;

  return (
    <div className="mx-auto max-w-7xl px-6">
      <header className="border-b border-line pt-14 pb-10">
        <nav className="eyebrow mb-6 flex items-center gap-2">
          <Link href="/" className="transition hover:text-ink">
            Início
          </Link>
          <span>/</span>
          <Link href="/products" className="transition hover:text-ink">
            Produtos
          </Link>
          {currentCategory && (
            <>
              <span>/</span>
              <span className="text-ink">{currentCategory.name}</span>
            </>
          )}
        </nav>
        <h1 className="text-5xl md:text-6xl">
          {query.q ? (
            <>
              Resultados para <em>{query.q}</em>
            </>
          ) : (
            (currentCategory?.name ?? "Todos os produtos")
          )}
        </h1>
        <div className="mt-6 flex flex-wrap items-center gap-3 text-sm text-stone">
          <span>{result.total} resultado(s)</span>
          <span aria-hidden>·</span>
          <span>{SORT_LABEL[query.sort]}</span>
          {activeFilters.map((f) => (
            <Link
              key={f.key}
              href={without(f.key)}
              className="flex items-center gap-1.5 rounded-full border border-line bg-card px-3 py-1 text-xs text-ink transition hover:border-ink/40"
              aria-label={`Remover filtro ${f.label}`}
            >
              {f.label} <X className="size-3" strokeWidth={1.5} />
            </Link>
          ))}
        </div>
      </header>

      <div className="grid gap-12 py-12 md:grid-cols-[220px_1fr]">
        <CatalogFilters categories={categories} current={params} />

        <div className="space-y-12">
          {result.items.length === 0 ? (
            <EmptyState
              icon={<SearchX />}
              title="Nenhum produto encontrado"
              description="Revise a busca ou remova alguns filtros."
              action={
                <Button asChild variant="outline">
                  <Link href="/products">Ver todos os produtos</Link>
                </Button>
              }
            />
          ) : (
            <div className="grid grid-cols-2 gap-x-6 gap-y-12 lg:grid-cols-3 xl:grid-cols-4">
              {result.items.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}
          <Pagination page={result.page} totalPages={result.totalPages} params={params} basePath="/products" />
        </div>
      </div>
    </div>
  );
}
