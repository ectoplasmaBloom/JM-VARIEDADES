import type { Metadata } from "next";
import Link from "next/link";
import { CheckCircle2, Clock, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { prisma } from "@/infrastructure/db/prisma";
import { requireUser } from "@/server/session";
import { processPaymentNotification } from "@/server/services/payment.service";

export const metadata: Metadata = { title: "Status do pagamento" };
export const dynamic = "force-dynamic";

type Search = { order?: string; payment_id?: string; collection_id?: string; status?: string };

/**
 * Página de retorno do Checkout Pro (back_urls).
 * Além do webhook, sincroniza o pagamento aqui: assim o fluxo funciona
 * em localhost, onde o Mercado Pago não consegue chamar o webhook.
 * O status exibido vem sempre do banco/API, nunca do parâmetro da URL.
 */
export default async function CheckoutResultPage({ searchParams }: { searchParams: Promise<Search> }) {
  const user = await requireUser();
  const params = await searchParams;
  const paymentId = params.payment_id ?? params.collection_id;

  const order = params.order
    ? await prisma.order.findFirst({ where: { id: params.order, buyerId: user.id }, select: { id: true } })
    : null;

  if (order && paymentId && /^\d+$/.test(paymentId)) {
    try {
      await processPaymentNotification(paymentId, "return_url");
    } catch (error) {
      console.error("[checkout:result] falha ao sincronizar pagamento", error);
    }
  }

  const current = order
    ? await prisma.order.findUnique({ where: { id: order.id }, select: { id: true, status: true, paymentUrl: true } })
    : null;

  if (!current) {
    return <Result icon={<XCircle className="text-destructive" />} title="Pedido não encontrado" />;
  }

  if (current.status === "APPROVED") {
    return (
      <Result icon={<CheckCircle2 className="text-success" />} title="Pagamento aprovado!" text="Seu pedido foi confirmado e já está sendo preparado para envio.">
        <Button asChild>
          <Link href={`/orders/${current.id}`}>Ver pedido</Link>
        </Button>
      </Result>
    );
  }

  if (current.status === "PENDING") {
    return (
      <Result
        icon={<Clock className="text-warning" />}
        title="Pagamento em processamento"
        text="Assim que o Mercado Pago confirmar (Pix e boleto podem levar alguns minutos), o status será atualizado automaticamente."
      >
        <div className="flex gap-2">
          <Button asChild variant="outline">
            <Link href={`/orders/${current.id}`}>Acompanhar pedido</Link>
          </Button>
          {current.paymentUrl && (
            <Button asChild>
              <a href={current.paymentUrl}>Tentar pagar novamente</a>
            </Button>
          )}
        </div>
      </Result>
    );
  }

  return (
    <Result
      icon={<XCircle className="text-destructive" />}
      title={current.status === "REFUNDED" ? "Pagamento estornado" : "Pagamento não aprovado"}
      text="O pedido foi cancelado automaticamente. Nenhum valor foi cobrado."
    >
      <Button asChild>
        <Link href="/cart">Voltar ao carrinho</Link>
      </Button>
    </Result>
  );
}

function Result({ icon, title, text, children }: { icon: React.ReactNode; title: string; text?: string; children?: React.ReactNode }) {
  return (
    <div className="mx-auto max-w-lg px-4 py-16">
      <Card className="py-10">
        <CardContent className="flex flex-col items-center gap-3 text-center [&>svg]:size-14">
          {icon}
          <h1 className="text-2xl font-semibold">{title}</h1>
          {text && <p className="text-muted-foreground">{text}</p>}
          <div className="mt-2">{children}</div>
        </CardContent>
      </Card>
    </div>
  );
}
