import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { FlaskConical } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { MockPaymentActions } from "@/components/checkout/mock-payment-actions";
import { prisma } from "@/infrastructure/db/prisma";
import { isMockPayment } from "@/infrastructure/payment";
import { requireUser } from "@/server/session";
import { formatBRL } from "@/lib/utils";

export const metadata: Metadata = { title: "Pagamento simulado" };
export const dynamic = "force-dynamic";

/** Tela de pagamento do modo simulado (PAYMENT_PROVIDER=mock), no lugar do Mercado Pago. */
export default async function MockCheckoutPage({ searchParams }: { searchParams: Promise<{ order?: string }> }) {
  if (!isMockPayment()) notFound();
  const user = await requireUser();
  const { order: orderId } = await searchParams;
  const order = orderId
    ? await prisma.order.findFirst({ where: { id: orderId, buyerId: user.id }, include: { items: true } })
    : null;
  if (!order) notFound();

  return (
    <div className="px-6 py-20">
      <Card className="mx-auto max-w-lg shadow-soft">
        <CardHeader>
          <p className="mb-4 flex items-center gap-2 border-l-2 border-gold py-1 pl-4 text-sm text-stone">
            <FlaskConical className="size-4" /> Pagamento simulado (modo MVP) — nenhuma cobrança real é feita.
          </p>
          <CardTitle>Pedido #{order.id.slice(-8).toUpperCase()}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <ul className="space-y-1">
            {order.items.map((i) => (
              <li key={i.id} className="flex justify-between gap-3">
                <span className="text-muted-foreground">
                  {i.quantity}× {i.title}
                </span>
                <span>{formatBRL(i.subtotal)}</span>
              </li>
            ))}
          </ul>
          <Separator />
          <div className="flex justify-between">
            <span>Frete ({order.shippingService})</span>
            <span>{formatBRL(order.shippingTotal)}</span>
          </div>
          <div className="flex justify-between text-lg font-semibold">
            <span>Total</span>
            <span>{formatBRL(order.total)}</span>
          </div>
          {order.status === "PENDING" ? (
            <MockPaymentActions orderId={order.id} />
          ) : (
            <p className="rounded-md bg-muted p-3">Este pedido não está mais aguardando pagamento.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
