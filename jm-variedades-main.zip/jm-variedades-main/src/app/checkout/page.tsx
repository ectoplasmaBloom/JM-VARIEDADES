import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { CheckoutFlow } from "@/components/checkout/checkout-flow";
import { requireUser } from "@/server/session";
import { getCart } from "@/server/services/cart.service";
import { listAddresses } from "@/server/services/user.service";

export const metadata: Metadata = { title: "Checkout" };
export const dynamic = "force-dynamic";

export default async function CheckoutPage() {
  const user = await requireUser();
  const [cart, addresses] = await Promise.all([getCart(user.id), listAddresses(user.id)]);
  if (cart.items.length === 0 || cart.hasProblems) redirect("/cart");

  return (
    <div className="mx-auto max-w-6xl px-6 py-14">
      <h1 className="mb-12 border-b border-line pb-8 text-5xl">Finalizar compra</h1>
      <CheckoutFlow cart={cart} initialAddresses={addresses} />
    </div>
  );
}
