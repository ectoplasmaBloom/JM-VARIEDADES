import Link from "next/link";
import { DollarSign, Package, Receipt, Truck, Users } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { PageTitle } from "@/components/layout/dashboard-shell";
import { SalesChart } from "@/components/shared/sales-chart";
import { StatCard } from "@/components/shared/stat-card";
import { OrderStatusBadge } from "@/components/shared/status-badge";
import { ORDER_STATUS_LABEL } from "@/domain/payment";
import { requireRole } from "@/server/session";
import { storeDashboard } from "@/server/services/dashboard.service";
import { formatBRL, formatDate } from "@/lib/utils";

export default async function AdminDashboardPage() {
  const [user, data] = await Promise.all([requireRole("ADMIN"), storeDashboard()]);

  return (
    <>
      <PageTitle title={`Olá, ${user.name.split(" ")[0]}`} description="Resumo da loja: vendas aprovadas, pedidos e estoque." />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <StatCard label="Total vendido" value={formatBRL(data.totalSold)} icon={<DollarSign className="size-5" />} hint={`${data.unitsSold} unidade(s)`} />
        <StatCard
          label="Pedidos"
          value={data.totalOrders}
          icon={<Receipt className="size-5" />}
          tone="sky"
          hint={`${data.ordersByStatus.PENDING} aguardando pagamento`}
        />
        <StatCard label="A despachar" value={data.toShip} icon={<Truck className="size-5" />} tone="tangerine" />
        <StatCard label="Produtos" value={data.productsCount} icon={<Package className="size-5" />} tone="lilac" />
        <StatCard label="Clientes" value={data.customersCount} icon={<Users className="size-5" />} tone="rose" />
      </div>

      {data.toShip > 0 && (
        <p className="mt-6 border-l-2 border-gold py-1 pl-4 text-sm text-stone">
          {data.toShip} pedido(s) pago(s) aguardando envio.{" "}
          <Link href="/admin/orders?status=APPROVED" className="link">
            Ver pedidos
          </Link>
        </p>
      )}

      <div className="mt-6 grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader>
            <CardTitle>Vendas aprovadas por dia</CardTitle>
          </CardHeader>
          <CardContent>
            <SalesChart data={data.daily} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Pedidos por status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {(Object.keys(data.ordersByStatus) as Array<keyof typeof data.ordersByStatus>).map((s) => {
              const count = data.ordersByStatus[s];
              const pct = data.totalOrders ? (count / data.totalOrders) * 100 : 0;
              return (
                <div key={s} className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>{ORDER_STATUS_LABEL[s]}</span>
                    <span className="tabular-nums">{count}</span>
                  </div>
                  <div className="h-px overflow-hidden bg-line">
                    <div className="h-full bg-gold" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Mais vendidos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {data.topProducts.length === 0 && <p className="text-muted-foreground">Sem vendas ainda.</p>}
            {data.topProducts.map((p) => (
              <div key={p.productId} className="flex justify-between gap-2">
                <span className="truncate">{p.title}</span>
                <span className="shrink-0 text-muted-foreground">{p.quantity} un.</span>
              </div>
            ))}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Estoque baixo</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {data.lowStock.length === 0 && <p className="text-muted-foreground">Tudo certo com o estoque.</p>}
            {data.lowStock.map((p) => (
              <Link key={p.id} href={`/admin/products/${p.id}/edit`} className="flex justify-between gap-2 link-hover">
                <span className="truncate">{p.title}</span>
                <span className={p.stock === 0 ? "font-bold text-destructive" : "font-bold text-ink"}>{p.stock} un.</span>
              </Link>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Pedidos recentes</CardTitle>
        </CardHeader>
        <CardContent>
          {data.recentOrders.length === 0 ? (
            <p className="text-sm text-muted-foreground">Nenhum pedido ainda.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Pedido</TableHead>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.recentOrders.map((o) => (
                  <TableRow key={o.id}>
                    <TableCell>
                      <Link href={`/orders/${o.id}`} className="link">
                        #{o.id.slice(-8).toUpperCase()}
                      </Link>
                    </TableCell>
                    <TableCell>{o.buyerName}</TableCell>
                    <TableCell className="text-muted-foreground">{formatDate(o.createdAt)}</TableCell>
                    <TableCell>
                      <OrderStatusBadge status={o.status} />
                    </TableCell>
                    <TableCell className="text-right">{formatBRL(o.total)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </>
  );
}
