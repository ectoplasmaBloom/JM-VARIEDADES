import Link from "next/link";
import type { Role } from "@prisma/client";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { PageTitle } from "@/components/layout/dashboard-shell";
import { UserStatusBadge } from "@/components/shared/status-badge";
import { UserActions } from "@/components/admin/user-actions";
import { requireRole } from "@/server/session";
import { listUsers } from "@/server/services/user.service";
import { cn, formatDate } from "@/lib/utils";

const ROLE_LABEL: Record<Role, string> = { BUYER: "Cliente", ADMIN: "Equipe" };
const FILTERS: Array<{ value?: Role; label: string }> = [
  { label: "Todos" },
  { value: "BUYER", label: "Clientes" },
  { value: "ADMIN", label: "Equipe" },
];

export default async function AdminUsersPage({ searchParams }: { searchParams: Promise<{ role?: string }> }) {
  const admin = await requireRole("ADMIN");
  const { role: raw } = await searchParams;
  const role = FILTERS.find((f) => f.value === raw)?.value;
  const users = await listUsers(role);

  return (
    <>
      <PageTitle title="Clientes e equipe" description="Suspenda contas e defina quem tem acesso ao painel da loja." />
      <div className="mb-4 flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <Link
            key={f.label}
            href={f.value ? `/admin/users?role=${f.value}` : "/admin/users"}
            className={cn(
              "rounded-full border px-3 py-1 text-sm",
              role === f.value ? "border-primary bg-secondary text-secondary-foreground" : "bg-card hover:bg-muted",
            )}
          >
            {f.label}
          </Link>
        ))}
      </div>
      <Card className="py-2">
        <CardContent className="px-2">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Perfil</TableHead>
                <TableHead className="text-right">Pedidos</TableHead>
                <TableHead>Desde</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map((u) => (
                <TableRow key={u.id}>
                  <TableCell>
                    <p className="font-medium">{u.name}</p>
                    <p className="text-xs text-muted-foreground">{u.email}</p>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{ROLE_LABEL[u.role]}</Badge>
                  </TableCell>
                  <TableCell className="text-right tabular-nums">{u._count.orders}</TableCell>
                  <TableCell className="text-muted-foreground">{formatDate(u.createdAt)}</TableCell>
                  <TableCell>
                    <UserStatusBadge status={u.status} />
                  </TableCell>
                  <TableCell className="text-right">
                    {u.id === admin.id ? (
                      <span className="text-xs text-muted-foreground">Você</span>
                    ) : (
                      <UserActions userId={u.id} status={u.status} role={u.role} />
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </>
  );
}
