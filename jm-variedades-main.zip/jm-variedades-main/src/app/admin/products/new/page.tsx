import { PageTitle } from "@/components/layout/dashboard-shell";
import { ProductForm } from "@/components/admin/product-form";
import { listCategories } from "@/server/services/product.service";

export default async function NewProductPage() {
  const categories = await listCategories("all");
  return (
    <>
      <PageTitle title="Novo produto" description="Preencha os dados do produto." />
      <ProductForm categories={categories} />
    </>
  );
}
