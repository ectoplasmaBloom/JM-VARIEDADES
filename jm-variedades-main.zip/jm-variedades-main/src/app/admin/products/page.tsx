import Image from "next/image";
import Link from "next/link";
import { Package, Pencil, Plus, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { PageTitle } from "@/components/layout/dashboard-shell";
import { EmptyState } from "@/components/shared/empty-state";
import { ProductStatusBadge } from "@/components/shared/status-badge";
import { DeleteProductButton } from "@/components/admin/delete-product-button";
import { ProductStatusToggle } from "@/components/admin/product-status-toggle";
import { listManagedProducts } from "@/server/services/product.service";
import { formatBRL } from "@/lib/utils";

export default async function AdminProductsPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q } = await searchParams;
  const products = await listManagedProducts(q?.slice(0, 100));

  const newButton = (
    <Button asChild>
      <Link href="/admin/products/new">
        <Plus /> Novo produto
      </Link>
    </Button>
  );

  return (
    <>
      <PageTitle title="Produtos" description={`${products.length} produto(s)${q ? ` para "${q}"` : " na loja"}`} action={newButton} />
      <form className="mb-4 flex max-w-md gap-2" role="search">
        <Input name="q" defaultValue={q} placeholder="Buscar por título" aria-label="Buscar produtos" />
        <Button type="submit" variant="outline" size="icon" aria-label="Buscar">
          <Search />
        </Button>
      </form>
      {products.length === 0 ? (
        <EmptyState
          icon={<Package />}
          title={q ? "Nenhum produto encontrado" : "Nenhum produto cadastrado"}
          description={q ? "Tente outro termo de busca." : "Cadastre o primeiro produto da loja."}
          action={q ? undefined : newButton}
        />
      ) : (
        <Card className="py-2">
          <CardContent className="px-2">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Produto</TableHead>
                  <TableHead>Categoria</TableHead>
                  <TableHead className="text-right">Preço</TableHead>
                  <TableHead className="text-right">Estoque</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {products.map((p) => (
                  <TableRow key={p.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="relative size-10 shrink-0 overflow-hidden rounded-sm bg-sand">
                          {p.image && <Image src={p.image} alt="" fill sizes="40px" className="object-cover" />}
                        </div>
                        <Link href={`/products/${p.slug}`} className="line-clamp-2 max-w-xs link-hover">
                          {p.title}
                        </Link>
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{p.categoryName}</TableCell>
                    <TableCell className="text-right">{formatBRL(p.price)}</TableCell>
                    <TableCell className={`text-right tabular-nums ${p.stock === 0 ? "text-destructive" : ""}`}>{p.stock}</TableCell>
                    <TableCell>
                      <ProductStatusBadge status={p.status} />
                    </TableCell>
                    <TableCell>
                      <div className="flex justify-end gap-1">
                        <ProductStatusToggle productId={p.id} status={p.status} />
                        <Button asChild variant="ghost" size="icon" aria-label="Editar" title="Editar">
                          <Link href={`/admin/products/${p.id}/edit`}>
                            <Pencil />
                          </Link>
                        </Button>
                        <DeleteProductButton productId={p.id} title={p.title} />
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </>
  );
}
