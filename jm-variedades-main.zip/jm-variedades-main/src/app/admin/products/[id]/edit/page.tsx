import { notFound } from "next/navigation";
import { NotFoundError } from "@/domain/errors";
import { PageTitle } from "@/components/layout/dashboard-shell";
import { ProductForm } from "@/components/admin/product-form";
import { getProductForEdit, listCategories } from "@/server/services/product.service";

export default async function EditProductPage({ params }: { params: Promise<{ id: string }> }) {
  const [product, categories] = await Promise.all([
    getProductForEdit((await params).id).catch((e: unknown) => {
      if (e instanceof NotFoundError) notFound();
      throw e;
    }),
    listCategories("all"),
  ]);

  return (
    <>
      <PageTitle title="Editar produto" description={product.title} />
      <ProductForm
        productId={product.id}
        categories={categories}
        initial={{
          title: product.title,
          description: product.description,
          price: product.price,
          stock: product.stock,
          categoryId: product.categoryId,
          images: product.images,
          status: product.status,
          weightGrams: product.weightGrams,
          lengthCm: product.lengthCm,
          widthCm: product.widthCm,
          heightCm: product.heightCm,
        }}
      />
    </>
  );
}
