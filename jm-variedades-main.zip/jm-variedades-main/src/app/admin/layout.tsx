import { LayoutDashboard, Package, PlusCircle, Receipt, Users } from "lucide-react";
import { DashboardShell } from "@/components/layout/dashboard-shell";
import { requireRole } from "@/server/session";

export const dynamic = "force-dynamic";

/** Painel da loja: acesso exclusivo da equipe (perfil ADMIN). */
export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requireRole("ADMIN");
  return (
    <DashboardShell
      title="Painel da loja"
      nav={[
        { href: "/admin", label: "Visão geral", icon: <LayoutDashboard /> },
        { href: "/admin/orders", label: "Pedidos", icon: <Receipt /> },
        { href: "/admin/products", label: "Produtos", icon: <Package /> },
        { href: "/admin/products/new", label: "Novo produto", icon: <PlusCircle /> },
        { href: "/admin/users", label: "Clientes e equipe", icon: <Users /> },
      ]}
    >
      {children}
    </DashboardShell>
  );
}
