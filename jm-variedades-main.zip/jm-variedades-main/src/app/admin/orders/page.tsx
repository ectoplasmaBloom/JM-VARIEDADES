import Link from "next/link";
import type { OrderStatus } from "@prisma/client";
import { Receipt } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { PageTitle } from "@/components/layout/dashboard-shell";
import { EmptyState } from "@/components/shared/empty-state";
import { OrderStatusBadge, ShipmentStatusBadge } from "@/components/shared/status-badge";
import { RefundButton } from "@/components/admin/refund-button";
import { ShipmentActions } from "@/components/admin/shipment-actions";
import { ORDER_STATUS_LABEL } from "@/domain/payment";
import { listStoreOrders } from "@/server/services/order.service";
import { cn, formatBRL, formatDate } from "@/lib/utils";

const STATUSES = Object.keys(ORDER_STATUS_LABEL) as OrderStatus[];

export default async function AdminOrdersPage({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  const { status: raw } = await searchParams;
  const status = STATUSES.find((s) => s === raw);
  const orders = await listStoreOrders(status);

  return (
    <>
      <PageTitle title="Pedidos" description="Despache os pedidos pagos e acompanhe pagamentos e estornos." />
      <div className="mb-4 flex flex-wrap gap-2">
        {[undefined, ...STATUSES].map((s) => (
          <Link
            key={s ?? "all"}
            href={s ? `/admin/orders?status=${s}` : "/admin/orders"}
            className={cn(
              "rounded-full border px-3 py-1 text-sm",
              status === s ? "border-primary bg-secondary text-secondary-foreground" : "bg-card hover:bg-muted",
            )}
          >
            {s ? ORDER_STATUS_LABEL[s] : "Todos"}
          </Link>
        ))}
      </div>

      {orders.length === 0 ? (
        <EmptyState icon={<Receipt />} title="Nenhum pedido encontrado" />
      ) : (
        <div className="space-y-3">
          {orders.map((o) => (
            <Card key={o.id} className="py-4">
              <CardContent className="space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <Link href={`/orders/${o.id}`} className="font-medium link-hover">
                      #{o.id.slice(-8).toUpperCase()}
                    </Link>
                    <OrderStatusBadge status={o.status} />
                    {o.shipments.map((s) => (
                      <ShipmentStatusBadge key={s.id} status={s.status} />
                    ))}
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {formatDate(o.createdAt)} · {o.buyerName} ({o.buyerEmail})
                  </span>
                </div>
                <ul className="text-sm text-muted-foreground">
                  {o.items.map((i, idx) => (
                    <li key={idx}>
                      {i.quantity}× {i.title} — {formatBRL(i.subtotal)}
                    </li>
                  ))}
                </ul>
                <div className="flex flex-wrap items-center justify-between gap-3 border-t pt-3">
                  <p className="text-sm">
                    Total <span className="font-semibold">{formatBRL(o.total)}</span>
                    <span className="text-muted-foreground">
                      {" "}
                      · Produtos {formatBRL(o.subtotal)} · Frete {formatBRL(o.shippingTotal)}
                    </span>
                  </p>
                  <div className="flex flex-wrap items-center gap-2">
                    {o.status === "APPROVED" &&
                      o.shipments.map((s) => (
                        <ShipmentActions key={s.id} shipmentId={s.id} status={s.status} trackingCode={s.trackingCode} />
                      ))}
                    {o.status === "APPROVED" && <RefundButton orderId={o.id} />}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </>
  );
}
