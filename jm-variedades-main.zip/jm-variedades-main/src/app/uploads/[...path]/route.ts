import { readFile } from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";
import { LOCAL_UPLOAD_DIR } from "@/infrastructure/storage/file-storage";

const TYPES: Record<string, string> = { ".jpg": "image/jpeg", ".png": "image/png", ".webp": "image/webp" };

/**
 * GET /uploads/... — serve as imagens enviadas no armazenamento local.
 * Com Vercel Blob (BLOB_READ_WRITE_TOKEN) as URLs são do Blob e esta rota não é usada.
 */
export async function GET(_req: Request, { params }: { params: Promise<{ path: string[] }> }) {
  const segments = (await params).path;
  const file = path.resolve(LOCAL_UPLOAD_DIR, ...segments);
  const type = TYPES[path.extname(file).toLowerCase()];

  // Impede path traversal (../) e tipos fora da lista
  if (!file.startsWith(LOCAL_UPLOAD_DIR + path.sep) || !type) {
    return new NextResponse("Not found", { status: 404 });
  }
  try {
    const data = await readFile(file);
    return new NextResponse(new Uint8Array(data), {
      headers: { "Content-Type": type, "Cache-Control": "public, max-age=31536000, immutable" },
    });
  } catch {
    return new NextResponse("Not found", { status: 404 });
  }
}
