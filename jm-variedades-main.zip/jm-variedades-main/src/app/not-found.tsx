import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="px-6 py-32">
      <div className="mx-auto flex max-w-md flex-col items-center gap-5 text-center">
        <p className="eyebrow flex items-center gap-3">
          <span className="rule-gold" /> Erro 404 <span className="rule-gold" />
        </p>
        <h1 className="text-5xl">Página não encontrada</h1>
        <p className="leading-relaxed text-stone">O que você procura não está aqui, ou não faz mais parte da loja.</p>
        <Button asChild size="lg" className="mt-2">
          <Link href="/">Voltar ao início</Link>
        </Button>
      </div>
    </div>
  );
}
