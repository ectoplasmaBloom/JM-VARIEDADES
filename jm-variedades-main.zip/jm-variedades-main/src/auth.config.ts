import type { NextAuthConfig } from "next-auth";
import type { Role } from "@prisma/client";

/**
 * Configuração "edge-safe" do Auth.js (sem Prisma/bcrypt), usada pelo middleware.
 * O provider Credentials completo fica em src/auth.ts.
 */

/** Prefixos de rota -> perfis autorizados */
export const ROUTE_ROLES: Array<{ prefix: string; roles: Role[] }> = [
  { prefix: "/admin", roles: ["ADMIN"] },
  { prefix: "/checkout", roles: ["BUYER", "ADMIN"] },
  { prefix: "/orders", roles: ["BUYER", "ADMIN"] },
  { prefix: "/account", roles: ["BUYER", "ADMIN"] },
  { prefix: "/cart", roles: ["BUYER", "ADMIN"] },
];

export const authConfig = {
  pages: { signIn: "/login" },
  session: { strategy: "jwt", maxAge: 60 * 60 * 24 * 7 },
  providers: [],
  callbacks: {
    authorized({ auth, request }) {
      const { pathname } = request.nextUrl;
      const rule = ROUTE_ROLES.find((r) => pathname.startsWith(r.prefix));
      if (!rule) return true;
      if (!auth?.user) return false; // redireciona para /login?callbackUrl=...
      if (!rule.roles.includes(auth.user.role)) {
        return Response.redirect(new URL("/?denied=1", request.nextUrl));
      }
      return true;
    },
    jwt({ token, user }) {
      if (user?.id) {
        token.id = user.id;
        token.role = user.role;
      }
      return token;
    },
    session({ session, token }) {
      session.user.id = token.id;
      session.user.role = token.role;
      return session;
    },
  },
} satisfies NextAuthConfig;
