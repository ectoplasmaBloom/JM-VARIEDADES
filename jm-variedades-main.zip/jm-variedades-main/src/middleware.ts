import NextAuth from "next-auth";
import { authConfig } from "@/auth.config";

/**
 * Middleware de autenticação: protege as páginas por perfil (ver ROUTE_ROLES).
 * As rotas /api/* fazem sua própria verificação (requireUser/requireRole)
 * para responderem 401/403 em JSON em vez de redirecionar.
 */
export default NextAuth(authConfig).auth;

export const config = {
  matcher: ["/admin/:path*", "/checkout/:path*", "/orders/:path*", "/account/:path*", "/cart"],
};
