"use client";

import { useCallback, useEffect, useState } from "react";
import { Loader2, Truck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { api, errorMessage } from "@/lib/api-client";
import { formatBRL, formatCep, onlyDigits } from "@/lib/utils";

export interface ShippingOptionView {
  serviceCode: string;
  service: string;
  price: number;
  deadlineDays: number;
}

const STORAGE_KEY = "mf:cep";

/**
 * Calculadora de frete (Correios). Na página do produto, o cálculo ocorre
 * automaticamente com o CEP salvo (endereço padrão ou último CEP digitado).
 */
export function ShippingCalculator({
  productId,
  quantity,
  defaultCep,
}: {
  productId: string;
  quantity: number;
  defaultCep: string | null;
}) {
  const [cep, setCep] = useState("");
  const [options, setOptions] = useState<ShippingOptionView[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const calculate = useCallback(
    async (value: string) => {
      const digits = onlyDigits(value);
      if (digits.length !== 8) {
        setError("Informe um CEP válido com 8 dígitos");
        return;
      }
      setLoading(true);
      setError(null);
      try {
        const result = await api<ShippingOptionView[]>("/api/shipping/quote", {
          method: "POST",
          body: { destinationCep: digits, productId, quantity },
        });
        setOptions(result);
        try {
          localStorage.setItem(STORAGE_KEY, digits);
        } catch {
          /* armazenamento indisponível */
        }
      } catch (e) {
        setOptions(null);
        setError(errorMessage(e));
      } finally {
        setLoading(false);
      }
    },
    [productId, quantity],
  );

  // Cálculo automático: CEP do endereço padrão ou o último usado neste navegador
  useEffect(() => {
    let saved: string | null = null;
    try {
      saved = localStorage.getItem(STORAGE_KEY);
    } catch {
      /* ignore */
    }
    const initial = defaultCep ?? saved;
    if (initial) {
      setCep(formatCep(initial));
      void calculate(initial);
    }
  }, [defaultCep, calculate]);

  return (
    <div className="space-y-3 rounded-md border border-line bg-card p-5">
      <p className="flex items-center gap-2.5 text-sm">
        <Truck className="size-4 text-gold-deep" strokeWidth={1.5} />
        Calcular frete e prazo
      </p>
      <form
        className="flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          void calculate(cep);
        }}
      >
        <Input
          value={cep}
          onChange={(e) => setCep(formatCep(onlyDigits(e.target.value).slice(0, 8)))}
          placeholder="Seu CEP"
          inputMode="numeric"
          aria-label="CEP de destino"
        />
        <Button type="submit" variant="outline" className="h-11" disabled={loading}>
          {loading ? <Loader2 className="animate-spin" /> : "OK"}
        </Button>
      </form>
      <a
        href="https://buscacepinter.correios.com.br/app/endereco/index.php"
        target="_blank"
        rel="noreferrer"
        className="link-hover text-xs text-stone"
      >
        Não sei meu CEP
      </a>
      {error && <p className="text-sm text-destructive">{error}</p>}
      {options && (
        <ul className="divide-y divide-line border-t border-line text-sm">
          {options.map((o) => (
            <li key={o.serviceCode} className="flex items-center justify-between py-3">
              <div>
                <p>{o.service}</p>
                <p className="text-xs text-stone">
                  Chega em até {o.deadlineDays} dia{o.deadlineDays > 1 ? "s" : ""} úte{o.deadlineDays > 1 ? "is" : "il"}
                </p>
              </div>
              <span className="price">{formatBRL(o.price)}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
