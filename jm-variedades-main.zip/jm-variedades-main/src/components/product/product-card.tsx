import Image from "next/image";
import Link from "next/link";
import { ImageOff } from "lucide-react";
import type { ProductCardDTO } from "@/server/services/product.service";
import { formatBRL } from "@/lib/utils";

/** Card de produto editorial: foto em fundo neutro, texto sóbrio, zoom lento no hover. */
export function ProductCard({ product }: { product: ProductCardDTO }) {
  const outOfStock = product.stock <= 0;

  return (
    <Link href={`/products/${product.slug}`} className="group flex flex-col gap-4 focus-visible:outline-none">
      <div className="relative aspect-[4/5] overflow-hidden rounded-md bg-sand transition-shadow duration-500 group-focus-visible:ring-2 group-focus-visible:ring-gold/60">
        {product.image ? (
          <Image
            src={product.image}
            alt={product.title}
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
            className="object-cover transition-transform duration-[1200ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.04]"
          />
        ) : (
          <div className="grid h-full place-items-center text-stone/40">
            <ImageOff className="size-8" strokeWidth={1.25} />
          </div>
        )}
        {outOfStock ? (
          <span className="absolute top-3 left-3 rounded-full bg-card/90 px-2.5 py-1 text-[10px] tracking-[0.14em] text-stone uppercase backdrop-blur">
            Esgotado
          </span>
        ) : product.stock <= 5 ? (
          <span className="absolute top-3 left-3 rounded-full bg-card/90 px-2.5 py-1 text-[10px] tracking-[0.14em] text-gold-deep uppercase backdrop-blur">
            Últimas unidades
          </span>
        ) : null}
      </div>

      <div className="space-y-1.5">
        <p className="eyebrow">{product.categoryName}</p>
        <p className="line-clamp-2 text-[15px] leading-snug text-ink">{product.title}</p>
        <p className="price pt-0.5 text-[15px] text-ink">{formatBRL(product.price)}</p>
      </div>
    </Link>
  );
}
