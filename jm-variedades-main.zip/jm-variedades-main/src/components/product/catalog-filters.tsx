import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { cn } from "@/lib/utils";

interface Props {
  categories: Array<{ id: string; name: string; slug: string; icon?: string | null }>;
  current: Record<string, string | undefined>;
}

/** Filtros do catálogo via GET (funciona sem JavaScript e mantém a URL compartilhável). */
export function CatalogFilters({ categories, current }: Props) {
  const withCategory = (slug?: string) => {
    const qs = new URLSearchParams();
    for (const [k, v] of Object.entries({ ...current, category: slug })) if (v) qs.set(k, v);
    return `/products?${qs}`;
  };

  const item = (active: boolean) =>
    cn(
      "flex items-center justify-between py-1.5 text-sm transition-colors duration-300",
      active ? "text-ink" : "text-stone hover:text-ink",
    );

  return (
    <aside className="space-y-10 md:sticky md:top-40 md:self-start">
      <div>
        <p className="eyebrow mb-4">Categorias</p>
        <ul className="flex flex-wrap gap-x-5 md:flex-col">
          <li>
            <Link href={withCategory(undefined)} className={item(!current.category)}>
              Todas {!current.category && <span className="ml-3 h-px w-4 bg-gold" />}
            </Link>
          </li>
          {categories.map((c) => (
            <li key={c.id}>
              <Link href={withCategory(c.slug)} className={item(current.category === c.slug)}>
                {c.name} {current.category === c.slug && <span className="ml-3 h-px w-4 bg-gold" />}
              </Link>
            </li>
          ))}
        </ul>
      </div>

      <form action="/products" className="space-y-6 border-t border-line pt-8">
        {current.q && <input type="hidden" name="q" value={current.q} />}
        {current.category && <input type="hidden" name="category" value={current.category} />}

        <div className="space-y-3">
          <p className="eyebrow">Faixa de preço</p>
          <div className="flex items-center gap-2">
            <Input name="minPrice" type="number" min={0} step="0.01" placeholder="Mín." defaultValue={current.minPrice} aria-label="Preço mínimo" />
            <span className="text-stone">—</span>
            <Input name="maxPrice" type="number" min={0} step="0.01" placeholder="Máx." defaultValue={current.maxPrice} aria-label="Preço máximo" />
          </div>
        </div>

        <div className="space-y-3">
          <Label htmlFor="sort" className="eyebrow">
            Ordenar por
          </Label>
          <Select id="sort" name="sort" defaultValue={current.sort ?? "recent"}>
            <option value="recent">Mais recentes</option>
            <option value="price_asc">Menor preço</option>
            <option value="price_desc">Maior preço</option>
          </Select>
        </div>

        <div className="flex items-center gap-4">
          <Button type="submit" className="flex-1">
            Aplicar
          </Button>
          <Link href="/products" className="link text-sm">
            Limpar
          </Link>
        </div>
      </form>
    </aside>
  );
}
