"use client";

import Image from "next/image";
import { useState } from "react";
import { ImageOff } from "lucide-react";
import { cn } from "@/lib/utils";

export function ProductGallery({ images, title }: { images: string[]; title: string }) {
  const [active, setActive] = useState(0);
  const current = images[active];

  return (
    <div className="space-y-4">
      <div className="relative aspect-[4/5] w-full overflow-hidden rounded-md bg-sand">
        {current ? (
          <Image
            key={current}
            src={current}
            alt={title}
            fill
            priority
            sizes="(max-width: 1024px) 100vw, 700px"
            className="object-cover"
          />
        ) : (
          <div className="grid h-full place-items-center text-stone/40">
            <ImageOff className="size-12" strokeWidth={1} />
          </div>
        )}
        {images.length > 1 && (
          <span className="absolute right-4 bottom-4 rounded-full bg-card/90 px-3 py-1 text-[11px] tracking-[0.14em] text-stone tabular-nums backdrop-blur">
            {active + 1} / {images.length}
          </span>
        )}
      </div>
      {images.length > 1 && (
        <div className="flex gap-3" role="tablist" aria-label="Fotos do produto">
          {images.map((src, i) => (
            <button
              key={src}
              role="tab"
              aria-selected={i === active}
              onMouseEnter={() => setActive(i)}
              onClick={() => setActive(i)}
              aria-label={`Foto ${i + 1}`}
              className={cn(
                "relative aspect-[4/5] w-20 overflow-hidden rounded-sm bg-sand transition-opacity duration-300",
                i === active ? "opacity-100 ring-1 ring-ink ring-offset-2 ring-offset-ivory" : "opacity-55 hover:opacity-100",
              )}
            >
              <Image src={src} alt="" fill sizes="80px" className="object-cover" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
