"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Minus, Plus, ShoppingBag } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { api, errorMessage } from "@/lib/api-client";
import { ShippingCalculator } from "./shipping-calculator";

export function ProductPurchasePanel({
  productId,
  stock,
  isLoggedIn,
  defaultCep,
}: {
  productId: string;
  stock: number;
  isLoggedIn: boolean;
  defaultCep: string | null;
}) {
  const router = useRouter();
  const [quantity, setQuantity] = useState(1);
  const [pending, startTransition] = useTransition();
  const [busy, setBusy] = useState<"cart" | "buy" | null>(null);

  async function add(goToCart: boolean) {
    if (!isLoggedIn) {
      router.push(`/login?callbackUrl=${encodeURIComponent(window.location.pathname)}`);
      return;
    }
    setBusy(goToCart ? "buy" : "cart");
    try {
      await api("/api/cart", { method: "POST", body: { productId, quantity } });
      if (goToCart) {
        router.push("/cart");
      } else {
        toast.success("Produto adicionado ao carrinho");
        startTransition(() => router.refresh());
      }
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(null);
    }
  }

  if (stock <= 0) {
    return (
      <p className="mt-8 rounded-md border border-line bg-card px-5 py-4 text-sm text-stone">
        Esgotado no momento. Volte em breve.
      </p>
    );
  }

  return (
    <div className="mt-8 space-y-6">
      <div className="flex items-center gap-5">
        <span className="eyebrow">Quantidade</span>
        <div className="flex items-center rounded-full border border-line bg-card">
          <button
            className="grid size-10 place-items-center rounded-full text-stone transition hover:text-ink disabled:opacity-30"
            onClick={() => setQuantity((q) => Math.max(1, q - 1))}
            disabled={quantity <= 1}
            aria-label="Diminuir"
          >
            <Minus className="size-3.5" strokeWidth={1.5} />
          </button>
          <span className="w-8 text-center text-sm tabular-nums">{quantity}</span>
          <button
            className="grid size-10 place-items-center rounded-full text-stone transition hover:text-ink disabled:opacity-30"
            onClick={() => setQuantity((q) => Math.min(stock, q + 1))}
            disabled={quantity >= stock}
            aria-label="Aumentar"
          >
            <Plus className="size-3.5" strokeWidth={1.5} />
          </button>
        </div>
      </div>

      <div className="grid gap-3">
        <Button size="lg" onClick={() => add(true)} disabled={busy !== null}>
          {busy === "buy" && <Loader2 className="animate-spin" />} Comprar agora
        </Button>
        <Button size="lg" variant="outline" onClick={() => add(false)} disabled={busy !== null || pending}>
          {busy === "cart" ? <Loader2 className="animate-spin" /> : <ShoppingBag strokeWidth={1.5} />} Adicionar ao carrinho
        </Button>
      </div>

      <ShippingCalculator productId={productId} quantity={quantity} defaultCep={defaultCep} />
    </div>
  );
}
