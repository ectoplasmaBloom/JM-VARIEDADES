import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

/** Selos discretos: pílula fina, caixa alta com espaçamento, cores dessaturadas. */
const badgeVariants = cva(
  "inline-flex w-fit shrink-0 items-center justify-center gap-1.5 whitespace-nowrap rounded-full border px-2.5 py-0.5 text-[10px] font-medium tracking-[0.12em] uppercase [&>svg]:size-3",
  {
    variants: {
      variant: {
        default: "border-ink bg-ink text-ivory",
        secondary: "border-line bg-sand text-ink",
        success: "border-success/25 bg-success/8 text-success",
        warning: "border-gold/40 bg-gold/10 text-gold-deep",
        destructive: "border-destructive/25 bg-destructive/6 text-destructive",
        outline: "border-ink/20 bg-transparent text-ink",
      },
    },
    defaultVariants: { variant: "default" },
  },
);

function Badge({ className, variant, ...props }: React.ComponentProps<"span"> & VariantProps<typeof badgeVariants>) {
  return <span data-slot="badge" className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { Badge, badgeVariants };
