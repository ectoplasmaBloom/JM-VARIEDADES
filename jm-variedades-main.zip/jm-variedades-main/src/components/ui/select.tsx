import * as React from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { fieldClasses } from "./input";

/** Select nativo com o visual da marca (acessível e funciona sem JS). */
function Select({ className, children, ...props }: React.ComponentProps<"select">) {
  return (
    <div className="relative">
      <select data-slot="select" className={cn("flex h-11 appearance-none px-3.5 pr-9", fieldClasses, className)} {...props}>
        {children}
      </select>
      <ChevronDown className="pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-stone" strokeWidth={1.5} />
    </div>
  );
}

export { Select };
