import * as React from "react";
import { cn } from "@/lib/utils";

/** Campo discreto: linha fina que escurece no foco, com um halo dourado sutil. */
export const fieldClasses =
  "w-full min-w-0 rounded-md border border-input bg-card text-base text-ink transition-[border-color,box-shadow] duration-300 outline-none placeholder:text-stone/70 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm hover:border-ink/40 focus-visible:border-ink focus-visible:ring-4 focus-visible:ring-gold/15 aria-invalid:border-destructive aria-invalid:ring-destructive/10";

function Input({ className, type, ...props }: React.ComponentProps<"input">) {
  return (
    <input
      type={type}
      data-slot="input"
      className={cn("flex h-11 px-3.5 py-1 file:border-0 file:bg-transparent file:text-sm file:font-medium", fieldClasses, className)}
      {...props}
    />
  );
}

export { Input };
