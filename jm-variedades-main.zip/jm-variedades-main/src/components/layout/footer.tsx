import Link from "next/link";
import { Logo } from "@/components/brand/logo";
import { STORE } from "@/lib/store";
import { listCategories } from "@/server/services/product.service";

export async function Footer() {
  const categories = await listCategories();
  return (
    <footer className="mt-28 bg-ink text-ivory">
      <div className="mx-auto grid max-w-7xl gap-10 border-b border-ivory/10 px-6 py-14 md:grid-cols-3">
        <Pledge title="Pagamento seguro">Pix, cartão ou boleto, com a proteção do Mercado Pago.</Pledge>
        <Pledge title="Frete transparente">Preço e prazo dos Correios calculados pelo seu CEP, antes de comprar.</Pledge>
        <Pledge title="Compra garantida">Se o pagamento não for aprovado, o pedido é cancelado automaticamente.</Pledge>
      </div>

      <div className="mx-auto grid max-w-7xl gap-10 px-6 py-14 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div className="space-y-4">
          <Logo inverted />
          <p className="max-w-xs text-sm leading-relaxed text-ivory/55">
            {STORE.description}
          </p>
        </div>
        <FooterColumn title="Comprar" links={[["/products", "Todos os produtos"], ["/cart", "Carrinho"], ["/orders", "Minhas compras"]]} />
        <FooterColumn title="Departamentos" links={categories.slice(0, 5).map((c): [string, string] => [`/products?category=${c.slug}`, c.name])} />
        <FooterColumn title="Conta" links={[["/login", "Entrar"], ["/register", "Criar conta"], ["/account/addresses", "Meus endereços"]]} />
      </div>

      <div className="border-t border-ivory/10 px-6 py-6 text-center text-[11px] tracking-[0.16em] text-ivory/40 uppercase">
        {STORE.name} © {new Date().getFullYear()} · Projeto acadêmico
      </div>
    </footer>
  );
}

function Pledge({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <p className="flex items-center gap-3 font-serif text-xl">
        <span className="h-px w-6 bg-gold" aria-hidden />
        {title}
      </p>
      <p className="pl-9 text-sm leading-relaxed text-ivory/55">{children}</p>
    </div>
  );
}

function FooterColumn({ title, links }: { title: string; links: Array<[string, string]> }) {
  return (
    <div>
      <p className="mb-4 text-[11px] font-medium tracking-[0.2em] text-gold uppercase">{title}</p>
      <ul className="space-y-2.5 text-sm">
        {links.map(([href, label]) => (
          <li key={href}>
            <Link href={href} className="text-ivory/70 transition-colors duration-300 hover:text-ivory">
              {label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
