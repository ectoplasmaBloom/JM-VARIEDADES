"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

export interface NavItem {
  href: string;
  label: string;
  icon: React.ReactNode;
}

/** Menu do painel; a página atual recebe um fio dourado à esquerda. */
export function DashboardNav({ items }: { items: NavItem[] }) {
  const pathname = usePathname();
  const active = items
    .filter((i) => pathname === i.href || pathname.startsWith(`${i.href}/`))
    .sort((a, b) => b.href.length - a.href.length)[0]?.href;

  return (
    <nav className="flex gap-1 overflow-x-auto border-line md:flex-col md:border-l" aria-label="Menu do painel">
      {items.map((item) => {
        const isActive = item.href === active;
        return (
          <Link
            key={item.href}
            href={item.href}
            aria-current={isActive ? "page" : undefined}
            className={cn(
              "relative flex items-center gap-3 py-2 pr-3 pl-5 text-sm whitespace-nowrap transition-colors duration-300 [&_svg]:size-4 [&_svg]:stroke-[1.5]",
              isActive ? "text-ink" : "text-stone hover:text-ink",
            )}
          >
            {isActive && <span aria-hidden className="absolute top-1.5 bottom-1.5 -left-px hidden w-px bg-gold md:block" />}
            {item.icon}
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}
