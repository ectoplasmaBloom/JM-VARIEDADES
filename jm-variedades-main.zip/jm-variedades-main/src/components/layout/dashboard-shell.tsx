import { DashboardNav, type NavItem } from "./dashboard-nav";

export type { NavItem };

/** Layout com menu lateral usado pelo painel da loja. */
export function DashboardShell({
  title,
  nav,
  children,
}: {
  title: string;
  /** Mantido por compatibilidade; a identidade atual usa um único tom. */
  tone?: string;
  nav: NavItem[];
  children: React.ReactNode;
}) {
  return (
    <div className="mx-auto grid max-w-7xl gap-12 px-6 py-12 md:grid-cols-[210px_1fr]">
      <aside className="md:sticky md:top-40 md:self-start">
        <p className="eyebrow mb-5 flex items-center gap-3">
          <span className="rule-gold" /> {title}
        </p>
        <DashboardNav items={nav} />
      </aside>
      <section className="min-w-0">{children}</section>
    </div>
  );
}

export function PageTitle({ title, description, action }: { title: string; description?: string; action?: React.ReactNode }) {
  return (
    <div className="mb-10 flex flex-wrap items-end justify-between gap-4 border-b border-line pb-8">
      <div>
        <h1 className="text-4xl md:text-5xl">{title}</h1>
        {description && <p className="mt-2 text-sm text-stone">{description}</p>}
      </div>
      {action}
    </div>
  );
}
