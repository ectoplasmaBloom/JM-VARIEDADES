/** Barra de anúncio fixa e discreta (sem animação), no topo do site. */
export function AnnouncementBar() {
  return (
    <div className="bg-ink px-4 py-2 text-center text-[11px] tracking-[0.18em] text-ivory/80 uppercase">
      Despacho em até 24h
      <span aria-hidden className="mx-3 text-gold">
        ·
      </span>
      Frete dos Correios calculado na hora
      <span aria-hidden className="mx-3 hidden text-gold sm:inline">
        ·
      </span>
      <span className="hidden sm:inline">Pagamento seguro pelo Mercado Pago</span>
    </div>
  );
}
