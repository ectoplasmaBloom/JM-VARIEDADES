import Link from "next/link";
import { Search, ShoppingBag } from "lucide-react";
import { currentUser } from "@/server/session";
import { getCartCount } from "@/server/services/cart.service";
import { listCategories } from "@/server/services/product.service";
import { Logo } from "@/components/brand/logo";
import { STORE } from "@/lib/store";
import { AnnouncementBar } from "./marquee";
import { UserMenu } from "./user-menu";

export async function Header() {
  const user = await currentUser();
  const [cartCount, categories] = await Promise.all([
    user ? getCartCount(user.id) : Promise.resolve(0),
    listCategories(),
  ]);

  return (
    <header className="sticky top-0 z-40">
      <AnnouncementBar />
      <div className="border-b border-line bg-ivory/90 backdrop-blur-md supports-[backdrop-filter]:bg-ivory/80">
        <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-4 md:gap-10 md:px-6">
          <Link href="/" aria-label={`${STORE.name} — início`} className="shrink-0">
            <Logo className="[&>span:last-child]:hidden sm:[&>span:last-child]:flex" />
          </Link>

          <form action="/products" className="flex flex-1 justify-center" role="search">
            <label htmlFor="q" className="sr-only">
              Buscar produtos
            </label>
            <div className="group flex h-11 w-full max-w-xl items-center rounded-full border border-line bg-card px-4 transition-[border-color,box-shadow] duration-300 focus-within:border-ink/50 focus-within:ring-4 focus-within:ring-gold/10 hover:border-ink/25">
              <Search className="size-4 shrink-0 text-stone" strokeWidth={1.5} />
              <input
                id="q"
                name="q"
                placeholder="O que você procura?"
                className="h-full w-full bg-transparent px-3 text-sm text-ink outline-none placeholder:text-stone/70"
              />
              <button type="submit" className="shrink-0 text-xs font-medium tracking-[0.16em] text-stone uppercase transition hover:text-ink">
                Buscar
              </button>
            </div>
          </form>

          <nav className="flex shrink-0 items-center gap-1 md:gap-3" aria-label="Conta">
            {user ? (
              <UserMenu name={user.name} role={user.role} />
            ) : (
              <>
                <Link href="/register" className="hidden px-2 text-sm text-stone transition hover:text-ink md:inline">
                  Crie a sua conta
                </Link>
                <Link href="/login" className="px-2 text-sm font-medium text-ink link-hover">
                  Entre
                </Link>
              </>
            )}
            <Link href="/cart" className="relative grid size-10 place-items-center rounded-full transition hover:bg-ink/5" aria-label="Carrinho">
              <ShoppingBag className="size-5" strokeWidth={1.5} />
              {cartCount > 0 && (
                <span className="absolute top-0.5 right-0 grid h-[18px] min-w-[18px] place-items-center rounded-full bg-ink px-1 text-[10px] font-medium text-ivory">
                  {cartCount > 99 ? "99+" : cartCount}
                </span>
              )}
            </Link>
          </nav>
        </div>

        <nav aria-label="Categorias" className="mx-auto hidden max-w-7xl justify-center gap-8 overflow-x-auto px-6 pb-3 md:flex">
          <CategoryLink href="/products">Todos</CategoryLink>
          {categories.map((c) => (
            <CategoryLink key={c.id} href={`/products?category=${c.slug}`}>
              {c.name}
            </CategoryLink>
          ))}
        </nav>
      </div>
    </header>
  );
}

function CategoryLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link
      href={href}
      className="group relative py-1 text-[11px] font-medium tracking-[0.18em] whitespace-nowrap text-stone uppercase transition-colors duration-300 hover:text-ink"
    >
      {children}
      <span className="absolute inset-x-0 -bottom-px h-px origin-left scale-x-0 bg-gold transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-x-100" />
    </Link>
  );
}
