"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { signOut } from "next-auth/react";
import { ChevronDown } from "lucide-react";
import type { Role } from "@prisma/client";

const ROLE_LABEL: Record<Role, string> = { ADMIN: "Equipe da loja", BUYER: "Cliente" };

export function UserMenu({ name, role }: { name: string; role: Role }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const close = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const esc = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", close);
    document.addEventListener("keydown", esc);
    return () => {
      document.removeEventListener("mousedown", close);
      document.removeEventListener("keydown", esc);
    };
  }, []);

  const firstName = name.split(" ")[0] ?? name;
  const initial = name.trim()[0]?.toUpperCase() ?? "";

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-2 rounded-full py-1 pr-2 pl-1 text-sm text-ink transition hover:bg-ink/5"
        aria-expanded={open}
        aria-haspopup="menu"
      >
        <span className="grid size-8 place-items-center rounded-full border border-ink/20 font-serif text-base">{initial}</span>
        <span className="hidden max-w-28 truncate sm:inline">{firstName}</span>
        <ChevronDown className={`size-3.5 text-stone transition duration-300 ${open ? "rotate-180" : ""}`} strokeWidth={1.5} />
      </button>

      {open && (
        <div
          role="menu"
          className="absolute right-0 mt-3 w-64 overflow-hidden rounded-lg border border-line bg-card py-2 text-sm shadow-soft-lg"
          onClick={() => setOpen(false)}
        >
          <div className="border-b border-line px-5 pt-2 pb-4">
            <p className="truncate font-serif text-lg leading-tight">{name}</p>
            <p className="eyebrow mt-1">{ROLE_LABEL[role]}</p>
          </div>
          <div className="py-2">
            <MenuLink href="/orders">Minhas compras</MenuLink>
            <MenuLink href="/account/addresses">Endereços</MenuLink>
            {role === "ADMIN" && <MenuLink href="/admin">Painel da loja</MenuLink>}
          </div>
          <div className="border-t border-line pt-2">
            <button
              role="menuitem"
              // Redireciona no mesmo host em que o usuário está (localhost, IP da rede ou domínio)
              onClick={() => signOut({ redirect: false }).then(() => window.location.assign("/"))}
              className="w-full px-5 py-2 text-left text-stone transition hover:bg-ivory hover:text-ink"
            >
              Sair
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function MenuLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link href={href} role="menuitem" className="block px-5 py-2 text-ink transition hover:bg-ivory">
      {children}
    </Link>
  );
}
