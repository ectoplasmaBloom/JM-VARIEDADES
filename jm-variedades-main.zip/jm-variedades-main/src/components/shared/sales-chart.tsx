import type { DailySales } from "@/server/services/dashboard.service";
import { formatBRL } from "@/lib/utils";

/** Gráfico de barras finas (CSS puro), com destaque dourado no melhor dia. */
export function SalesChart({ data }: { data: DailySales[] }) {
  const max = Math.max(1, ...data.map((d) => d.total));
  const total = data.reduce((s, d) => s + d.total, 0);
  const best = data.reduce((a, b) => (b.total > a.total ? b : a), data[0] ?? { day: "", total: 0 });

  return (
    <div>
      <div className="mb-8 flex flex-wrap items-end justify-between gap-2">
        <div>
          <p className="eyebrow">Últimos {data.length} dias</p>
          <p className="mt-2 font-serif text-3xl tabular-nums">{formatBRL(total)}</p>
        </div>
        {best.total > 0 && (
          <p className="text-xs text-stone">
            Melhor dia <span className="text-ink">{best.day.split("-").reverse().slice(0, 2).join("/")}</span>
          </p>
        )}
      </div>
      <div className="flex h-40 items-end gap-2 border-b border-line" role="img" aria-label={`Vendas por dia, total ${formatBRL(total)}`}>
        {data.map((d) => {
          const [, month, day] = d.day.split("-");
          const isBest = best.total > 0 && d.day === best.day;
          return (
            <div key={d.day} className="group relative flex h-full flex-1 flex-col justify-end">
              <div
                className={`w-full rounded-t-[2px] transition-colors duration-300 ${d.total === 0 ? "bg-line" : isBest ? "bg-gold" : "bg-ink/80 group-hover:bg-ink"}`}
                style={{ height: d.total === 0 ? "2px" : `${Math.max(4, (d.total / max) * 100)}%` }}
              />
              <span className="pointer-events-none absolute -top-8 left-1/2 z-10 hidden -translate-x-1/2 rounded bg-ink px-2 py-1 text-[10px] whitespace-nowrap text-ivory group-hover:block">
                {formatBRL(d.total)}
              </span>
              <span className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[10px] text-stone/70">
                {day}/{month}
              </span>
            </div>
          );
        })}
      </div>
      <div className="h-6" />
    </div>
  );
}
