export function EmptyState({
  icon,
  title,
  description,
  action,
}: {
  icon: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center gap-4 rounded-lg border border-line bg-card px-6 py-20 text-center">
      <div className="grid size-14 place-items-center rounded-full border border-line text-stone [&_svg]:size-6 [&_svg]:stroke-[1.25]">{icon}</div>
      <h2 className="text-3xl">{title}</h2>
      {description && <p className="max-w-sm text-sm leading-relaxed text-stone">{description}</p>}
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}
