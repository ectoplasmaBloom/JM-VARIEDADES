/** Indicador numérico sóbrio: rótulo em caixa alta, número em serifada. */
export function StatCard({
  label,
  value,
  icon,
  hint,
}: {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  hint?: string;
  /** Mantido por compatibilidade; a identidade atual usa um único tom. */
  tone?: string;
}) {
  return (
    <div className="flex flex-col justify-between gap-6 rounded-lg border border-line bg-card p-5">
      <div className="flex items-center justify-between gap-3">
        <p className="eyebrow">{label}</p>
        <span className="text-stone [&_svg]:size-4 [&_svg]:stroke-[1.5]">{icon}</span>
      </div>
      <div>
        <p className="truncate font-serif text-4xl leading-none font-medium tabular-nums">{value}</p>
        {hint && <p className="mt-2 text-xs text-stone">{hint}</p>}
      </div>
    </div>
  );
}
