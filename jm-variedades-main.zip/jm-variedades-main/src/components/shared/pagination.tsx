import Link from "next/link";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface Props {
  page: number;
  totalPages: number;
  /** Parâmetros atuais da URL (sem "page") */
  params: Record<string, string | undefined>;
  basePath: string;
}

export function Pagination({ page, totalPages, params, basePath }: Props) {
  if (totalPages <= 1) return null;

  const href = (p: number) => {
    const qs = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) if (v) qs.set(k, v);
    qs.set("page", String(p));
    return `${basePath}?${qs}`;
  };

  const start = Math.max(1, page - 2);
  const end = Math.min(totalPages, start + 4);
  const pages = Array.from({ length: end - start + 1 }, (_, i) => start + i);

  return (
    <nav className="flex items-center justify-center gap-6 border-t border-line pt-8" aria-label="Paginação">
      <PageLink href={href(page - 1)} disabled={page <= 1} label="Anterior">
        <ArrowLeft className="size-4" strokeWidth={1.5} />
      </PageLink>
      <div className="flex items-center gap-1">
        {pages.map((p) => (
          <Link
            key={p}
            href={href(p)}
            aria-current={p === page ? "page" : undefined}
            className={cn(
              "relative grid size-9 place-items-center text-sm tabular-nums transition-colors duration-300",
              p === page ? "text-ink" : "text-stone hover:text-ink",
            )}
          >
            {p}
            {p === page && <span className="absolute bottom-1 h-px w-4 bg-gold" />}
          </Link>
        ))}
      </div>
      <PageLink href={href(page + 1)} disabled={page >= totalPages} label="Próxima">
        <ArrowRight className="size-4" strokeWidth={1.5} />
      </PageLink>
    </nav>
  );
}

function PageLink({ href, disabled, label, children }: { href: string; disabled: boolean; label: string; children: React.ReactNode }) {
  const cls = "grid size-9 place-items-center rounded-full border transition-colors duration-300";
  if (disabled) {
    return (
      <span aria-disabled className={cn(cls, "border-line text-stone/40")}>
        {children}
      </span>
    );
  }
  return (
    <Link href={href} aria-label={label} className={cn(cls, "border-line text-ink hover:border-ink")}>
      {children}
    </Link>
  );
}
