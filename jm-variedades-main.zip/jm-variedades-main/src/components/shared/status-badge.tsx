import type { OrderStatus, PaymentStatus, ProductStatus, ShipmentStatus, UserStatus } from "@prisma/client";
import { Badge } from "@/components/ui/badge";
import { ORDER_STATUS_LABEL } from "@/domain/payment";

type Variant = "success" | "warning" | "destructive" | "secondary" | "outline";

const ORDER: Record<OrderStatus, Variant> = {
  PENDING: "warning",
  APPROVED: "success",
  CANCELLED: "destructive",
  REFUNDED: "secondary",
};

export function OrderStatusBadge({ status }: { status: OrderStatus }) {
  return <Badge variant={ORDER[status]}>{ORDER_STATUS_LABEL[status]}</Badge>;
}

const PAYMENT_LABEL: Record<PaymentStatus, [string, Variant]> = {
  PENDING: ["Pendente", "warning"],
  AUTHORIZED: ["Autorizado", "warning"],
  IN_PROCESS: ["Em análise", "warning"],
  IN_MEDIATION: ["Em mediação", "warning"],
  APPROVED: ["Aprovado", "success"],
  REJECTED: ["Recusado", "destructive"],
  CANCELLED: ["Cancelado", "destructive"],
  REFUNDED: ["Reembolsado", "secondary"],
  CHARGED_BACK: ["Chargeback", "destructive"],
};

export function PaymentStatusBadge({ status }: { status: PaymentStatus }) {
  const [label, variant] = PAYMENT_LABEL[status];
  return <Badge variant={variant}>{label}</Badge>;
}

const SHIPMENT_LABEL: Record<ShipmentStatus, [string, Variant]> = {
  PENDING: ["Aguardando pagamento", "outline"],
  READY_TO_SHIP: ["Pronto para envio", "warning"],
  SHIPPED: ["Enviado", "secondary"],
  DELIVERED: ["Entregue", "success"],
  CANCELLED: ["Cancelado", "destructive"],
};

export function ShipmentStatusBadge({ status }: { status: ShipmentStatus }) {
  const [label, variant] = SHIPMENT_LABEL[status];
  return <Badge variant={variant}>{label}</Badge>;
}

const PRODUCT_LABEL: Record<ProductStatus, [string, Variant]> = {
  ACTIVE: ["Ativo", "success"],
  INACTIVE: ["Pausado", "outline"],
};

export function ProductStatusBadge({ status }: { status: ProductStatus }) {
  const [label, variant] = PRODUCT_LABEL[status];
  return <Badge variant={variant}>{label}</Badge>;
}

export function UserStatusBadge({ status }: { status: UserStatus }) {
  return status === "ACTIVE" ? <Badge variant="success">Ativo</Badge> : <Badge variant="destructive">Suspenso</Badge>;
}
