"use client";

import { useCallback, useEffect, useState } from "react";
import type { Address } from "@prisma/client";
import { CreditCard, Loader2, MapPin, Plus, Truck } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { AddressForm } from "@/components/account/address-form";
import type { ShippingOptionView } from "@/components/product/shipping-calculator";
import { api, errorMessage } from "@/lib/api-client";
import { cn, formatBRL, formatCep } from "@/lib/utils";
import type { CartDTO } from "@/server/services/cart.service";

/**
 * Fluxo do checkout:
 *  1. Escolher endereço  2. Calcular frete (automático)  3. Resumo  4. Pagar com Mercado Pago
 */
export function CheckoutFlow({ cart, initialAddresses }: { cart: CartDTO; initialAddresses: Address[] }) {
  const [addresses, setAddresses] = useState(initialAddresses);
  const [addressId, setAddressId] = useState<string | null>(
    initialAddresses.find((a) => a.isDefault)?.id ?? initialAddresses[0]?.id ?? null,
  );
  const [showForm, setShowForm] = useState(initialAddresses.length === 0);
  const [options, setOptions] = useState<ShippingOptionView[] | null>(null);
  const [serviceCode, setServiceCode] = useState<string | null>(null);
  const [quoting, setQuoting] = useState(false);
  const [quoteError, setQuoteError] = useState<string | null>(null);
  const [paying, setPaying] = useState(false);

  const address = addresses.find((a) => a.id === addressId) ?? null;
  const shipping = options?.find((o) => o.serviceCode === serviceCode) ?? null;

  const quote = useCallback(async (cep: string) => {
    setQuoting(true);
    setQuoteError(null);
    setOptions(null);
    setServiceCode(null);
    try {
      const result = await api<ShippingOptionView[]>("/api/shipping/quote", {
        method: "POST",
        body: { destinationCep: cep },
      });
      setOptions(result);
      setServiceCode(result[0]?.serviceCode ?? null);
    } catch (e) {
      setQuoteError(errorMessage(e));
    } finally {
      setQuoting(false);
    }
  }, []);

  // Frete calculado automaticamente sempre que o endereço muda
  useEffect(() => {
    if (address) void quote(address.cep);
  }, [address, quote]);

  async function pay() {
    if (!addressId || !serviceCode) return;
    setPaying(true);
    try {
      const { paymentUrl } = await api<{ orderId: string; paymentUrl: string }>("/api/checkout", {
        method: "POST",
        body: { addressId, serviceCode },
      });
      window.location.assign(paymentUrl);
    } catch (e) {
      toast.error(errorMessage(e));
      setPaying(false);
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="size-5" /> 1. Endereço de entrega
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {addresses.map((a) => (
              <label
                key={a.id}
                className={cn(
                  "flex cursor-pointer gap-3 rounded-lg border p-3 text-sm transition",
                  a.id === addressId ? "border-ink bg-ivory" : "border-line hover:border-ink/30",
                )}
              >
                <input
                  type="radio"
                  name="address"
                  className="mt-1 accent-[var(--ink)]"
                  checked={a.id === addressId}
                  onChange={() => setAddressId(a.id)}
                />
                <div>
                  <p className="font-medium">
                    {a.label} · {a.recipient}
                  </p>
                  <p className="text-muted-foreground">
                    {a.street}, {a.number}
                    {a.complement ? ` - ${a.complement}` : ""} · {a.district} · {a.city}/{a.state} · CEP {formatCep(a.cep)}
                  </p>
                </div>
              </label>
            ))}
            {showForm ? (
              <div className="rounded-lg border p-4">
                <AddressForm
                  onCreated={(a) => {
                    setAddresses((list) => [...list, a]);
                    setAddressId(a.id);
                    setShowForm(false);
                  }}
                  onCancel={addresses.length ? () => setShowForm(false) : undefined}
                />
              </div>
            ) : (
              <Button variant="outline" size="sm" onClick={() => setShowForm(true)}>
                <Plus /> Novo endereço
              </Button>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Truck className="size-5" /> 2. Frete (Correios)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {!address && <p className="text-sm text-muted-foreground">Selecione um endereço para calcular o frete.</p>}
            {quoting && (
              <p className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="size-4 animate-spin" /> Calculando frete…
              </p>
            )}
            {quoteError && (
              <div className="flex items-center justify-between gap-2 rounded-md bg-destructive/10 p-3 text-sm text-destructive">
                {quoteError}
                {address && (
                  <Button size="sm" variant="outline" onClick={() => quote(address.cep)}>
                    Tentar novamente
                  </Button>
                )}
              </div>
            )}
            {options?.map((o) => (
              <label
                key={o.serviceCode}
                className={cn(
                  "flex cursor-pointer items-center justify-between rounded-lg border p-3 text-sm",
                  o.serviceCode === serviceCode ? "border-ink bg-ivory" : "border-line hover:border-ink/30",
                )}
              >
                <span className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="shipping"
                    className="accent-[var(--ink)]"
                    checked={o.serviceCode === serviceCode}
                    onChange={() => setServiceCode(o.serviceCode)}
                  />
                  <span>
                    <span className="font-medium">{o.service}</span>
                    <span className="block text-xs text-muted-foreground">Entrega em até {o.deadlineDays} dias úteis</span>
                  </span>
                </span>
                <span className="font-medium">{formatBRL(o.price)}</span>
              </label>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card className="h-fit lg:sticky lg:top-28">
        <CardHeader>
          <CardTitle>3. Resumo do pedido</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <ul className="space-y-2">
            {cart.items.map((i) => (
              <li key={i.productId} className="flex justify-between gap-3">
                <span className="line-clamp-1 text-muted-foreground">
                  {i.quantity}× {i.title}
                </span>
                <span className="shrink-0">{formatBRL(i.subtotal)}</span>
              </li>
            ))}
          </ul>
          <Separator />
          <div className="flex justify-between">
            <span>Produtos</span>
            <span>{formatBRL(cart.subtotal)}</span>
          </div>
          <div className="flex justify-between">
            <span>Frete</span>
            <span>{shipping ? formatBRL(shipping.price) : "—"}</span>
          </div>
          <Separator />
          <div className="flex justify-between text-lg font-semibold">
            <span>Total</span>
            <span>{formatBRL(cart.subtotal + (shipping?.price ?? 0))}</span>
          </div>
          <Button size="lg" className="w-full" disabled={!shipping || !address || paying} onClick={pay}>
            {paying ? <Loader2 className="animate-spin" /> : <CreditCard />} 4. Pagar com Mercado Pago
          </Button>
          <p className="text-center text-xs text-muted-foreground">
            Você será redirecionado ao Mercado Pago para pagar com cartão, Pix ou boleto.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
