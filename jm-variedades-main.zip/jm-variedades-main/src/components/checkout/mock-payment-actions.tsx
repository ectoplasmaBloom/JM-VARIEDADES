"use client";

import { useState } from "react";
import { CheckCircle2, Clock, Loader2, XCircle } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { api, errorMessage } from "@/lib/api-client";

type Outcome = "approved" | "rejected" | "pending";

export function MockPaymentActions({ orderId }: { orderId: string }) {
  const [busy, setBusy] = useState<Outcome | null>(null);

  async function pay(outcome: Outcome) {
    setBusy(outcome);
    try {
      await api("/api/payments/mock", { method: "POST", body: { orderId, outcome } });
      window.location.assign(`/checkout/result?order=${orderId}`);
    } catch (e) {
      toast.error(errorMessage(e));
      setBusy(null);
    }
  }

  const icon = (o: Outcome, node: React.ReactNode) => (busy === o ? <Loader2 className="animate-spin" /> : node);

  return (
    <div className="grid gap-2 pt-2">
      <Button size="lg" onClick={() => pay("approved")} disabled={busy !== null}>
        {icon("approved", <CheckCircle2 />)} Aprovar pagamento
      </Button>
      <Button size="lg" variant="outline" onClick={() => pay("pending")} disabled={busy !== null}>
        {icon("pending", <Clock />)} Deixar em processamento (ex.: boleto)
      </Button>
      <Button size="lg" variant="outline" className="text-destructive" onClick={() => pay("rejected")} disabled={busy !== null}>
        {icon("rejected", <XCircle />)} Recusar pagamento
      </Button>
    </div>
  );
}
