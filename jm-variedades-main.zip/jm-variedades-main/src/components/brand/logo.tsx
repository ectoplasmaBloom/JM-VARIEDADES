import { STORE } from "@/lib/store";
import { cn } from "@/lib/utils";

/** Monograma: iniciais serifadas num círculo de traço fino, com um ponto dourado. */
export function LogoMark({ className, inverted = false }: { className?: string; inverted?: boolean }) {
  return (
    <span
      aria-hidden
      className={cn(
        "relative grid size-9 place-items-center rounded-full border font-serif text-[0.95rem] leading-none font-semibold tracking-[0.04em]",
        inverted ? "border-ivory/40 text-ivory" : "border-ink/25 text-ink",
        className,
      )}
    >
      {STORE.monogram}
      <span className="absolute top-1 right-1 size-1 rounded-full bg-gold" />
    </span>
  );
}

/** Logotipo: "JM" em serifa com "VARIEDADES" espaçado, tudo em caixa-alta. */
export function Logo({ className, inverted = false }: { className?: string; inverted?: boolean }) {
  const [first, ...rest] = STORE.name.split(" ");
  return (
    <span className={cn("flex items-center gap-3", className)}>
      <LogoMark inverted={inverted} />
      <span className={cn("flex items-baseline gap-2 leading-none whitespace-nowrap", inverted ? "text-ivory" : "text-ink")}>
        <span className="font-serif text-[1.55rem] font-semibold tracking-[0.06em]">{first}</span>
        {rest.length > 0 && <span className="text-[0.7rem] font-medium tracking-[0.34em]">{rest.join(" ")}</span>}
      </span>
    </span>
  );
}
