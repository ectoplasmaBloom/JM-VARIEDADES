import { LogoMark } from "@/components/brand/logo";

export function AuthCard({
  title,
  description,
  children,
  footer,
}: {
  title: string;
  description?: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
}) {
  return (
    <div className="px-6 py-20">
      <div className="mx-auto flex max-w-[26rem] flex-col gap-8">
        <div className="text-center">
          <LogoMark className="mx-auto mb-8 size-12 text-2xl" />
          <h1 className="text-5xl">{title}</h1>
          {description && <p className="mt-3 text-sm text-stone">{description}</p>}
        </div>
        <div className="rounded-lg border border-line bg-card p-8 shadow-soft">{children}</div>
        {footer && <div className="text-center text-sm text-stone">{footer}</div>}
      </div>
    </div>
  );
}

export function FieldError({ messages }: { messages?: string[] }) {
  if (!messages?.length) return null;
  return <p className="text-xs text-destructive">{messages[0]}</p>;
}

export function Notice({ tone = "success", children }: { tone?: "success" | "error"; children: React.ReactNode }) {
  return (
    <p
      role="status"
      className={`mb-6 border-l-2 py-1 pl-4 text-sm ${tone === "success" ? "border-gold text-ink" : "border-destructive text-destructive"}`}
    >
      {children}
    </p>
  );
}
