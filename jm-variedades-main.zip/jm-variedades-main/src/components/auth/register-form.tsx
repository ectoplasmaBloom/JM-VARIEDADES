"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { AlertCircle, Check, Circle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FieldError } from "@/components/auth/auth-card";
import { ApiError, api, errorMessage } from "@/lib/api-client";
import { cn } from "@/lib/utils";

/** Mesmas regras do registerSchema (src/server/validators.ts), mostradas ao vivo. */
const PASSWORD_RULES = [
  { label: "Pelo menos 8 caracteres", test: (p: string) => p.length >= 8 },
  { label: "Pelo menos uma letra", test: (p: string) => /[A-Za-z]/.test(p) },
  { label: "Pelo menos um número", test: (p: string) => /\d/.test(p) },
];

export function RegisterForm() {
  const router = useRouter();
  const [values, setValues] = useState({ name: "", email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fields, setFields] = useState<Record<string, string[] | undefined>>({});

  const set = (key: keyof typeof values) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setValues((v) => ({ ...v, [key]: e.target.value }));
    setFields((f) => ({ ...f, [key]: undefined }));
  };

  const passwordOk = PASSWORD_RULES.every((r) => r.test(values.password));

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!passwordOk) {
      setError("A senha não atende aos requisitos abaixo do campo Senha.");
      return;
    }
    setLoading(true);
    setError(null);
    setFields({});
    try {
      await api("/api/auth/register", {
        method: "POST",
        body: values,
      });
      router.push("/login?registered=1");
    } catch (err) {
      setError(errorMessage(err));
      if (err instanceof ApiError && err.fields) setFields(err.fields);
      setLoading(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4" noValidate>
      <div className="space-y-2">
        <Label htmlFor="name">Nome completo</Label>
        <Input id="name" value={values.name} onChange={set("name")} autoComplete="name" required aria-invalid={Boolean(fields.name)} />
        <FieldError messages={fields.name} />
      </div>
      <div className="space-y-2">
        <Label htmlFor="email">E-mail</Label>
        <Input id="email" type="email" value={values.email} onChange={set("email")} autoComplete="email" required aria-invalid={Boolean(fields.email)} />
        <FieldError messages={fields.email} />
      </div>
      <div className="space-y-2">
        <Label htmlFor="password">Senha</Label>
        <Input
          id="password"
          type="password"
          value={values.password}
          onChange={set("password")}
          autoComplete="new-password"
          required
          aria-invalid={Boolean(fields.password) || (values.password.length > 0 && !passwordOk)}
          aria-describedby="password-rules"
        />
        <ul id="password-rules" className="space-y-0.5 text-xs">
          {PASSWORD_RULES.map((rule) => {
            const ok = rule.test(values.password);
            return (
              <li key={rule.label} className={cn("flex items-center gap-2 transition-colors duration-300", ok ? "text-ink" : "text-stone/80")}>
                {ok ? <Check className="size-3.5 text-gold-deep" strokeWidth={2} /> : <Circle className="size-3" strokeWidth={1.25} />}
                {rule.label}
              </li>
            );
          })}
        </ul>
        <FieldError messages={fields.password} />
      </div>

      {error && (
        <p role="alert" className="flex items-start gap-2 border-l-2 border-destructive py-1 pl-4 text-sm text-destructive">
          <AlertCircle className="mt-0.5 size-4 shrink-0" />
          {error}
        </p>
      )}
      <Button type="submit" size="lg" className="w-full" disabled={loading}>
        {loading && <Loader2 className="animate-spin" />} Criar conta
      </Button>
    </form>
  );
}
