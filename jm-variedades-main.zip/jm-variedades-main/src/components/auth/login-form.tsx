"use client";

import Link from "next/link";
import { useState } from "react";
import { signIn } from "next-auth/react";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export function LoginForm({ callbackUrl }: { callbackUrl: string }) {
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const form = new FormData(e.currentTarget);
    let result: Awaited<ReturnType<typeof signIn>>;
    try {
      result = await signIn("credentials", {
        email: form.get("email"),
        password: form.get("password"),
        redirect: false,
      });
    } catch {
      setError("Servidor indisponível. Verifique se o projeto está rodando e tente novamente.");
      setLoading(false);
      return;
    }
    if (!result || result.error) {
      // CredentialsSignin = credenciais recusadas; qualquer outro código = falha no servidor
      setError(
        !result || result.error === "CredentialsSignin"
          ? "E-mail ou senha inválidos, ou conta suspensa."
          : "Não foi possível entrar: o servidor não conseguiu acessar o banco de dados. " +
              "Inicie o projeto pelo run.bat e mantenha a janela do banco aberta.",
      );
      setLoading(false);
      return;
    }
    // Navegação completa para o header (server component) refletir a sessão
    window.location.assign(callbackUrl);
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="email">E-mail</Label>
        <Input id="email" name="email" type="email" autoComplete="email" required />
      </div>
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label htmlFor="password">Senha</Label>
          <Link href="/forgot-password" className="link text-xs">
            Esqueci minha senha
          </Link>
        </div>
        <Input id="password" name="password" type="password" autoComplete="current-password" required />
      </div>
      {error && (
        <p role="alert" className="border-l-2 border-destructive py-1 pl-4 text-sm text-destructive">
          {error}
        </p>
      )}
      <Button type="submit" size="lg" className="w-full" disabled={loading}>
        {loading && <Loader2 className="animate-spin" />} Entrar
      </Button>
    </form>
  );
}
