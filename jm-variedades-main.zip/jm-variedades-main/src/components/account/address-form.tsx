"use client";

import { useState } from "react";
import { Loader2 } from "lucide-react";
import type { Address } from "@prisma/client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FieldError } from "@/components/auth/auth-card";
import { ApiError, api, errorMessage } from "@/lib/api-client";
import { formatCep, onlyDigits } from "@/lib/utils";

interface ViaCepResponse {
  logradouro?: string;
  bairro?: string;
  localidade?: string;
  uf?: string;
  erro?: boolean | string;
}

/** Formulário de endereço com preenchimento automático pelo CEP (ViaCEP). */
export function AddressForm({ onCreated, onCancel }: { onCreated: (a: Address) => void; onCancel?: () => void }) {
  const [values, setValues] = useState({
    label: "Casa",
    recipient: "",
    cep: "",
    street: "",
    number: "",
    complement: "",
    district: "",
    city: "",
    state: "",
  });
  const [loading, setLoading] = useState(false);
  const [lookup, setLookup] = useState(false);
  const [fields, setFields] = useState<Record<string, string[] | undefined>>({});

  const set = (key: keyof typeof values) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setValues((v) => ({ ...v, [key]: e.target.value }));

  async function onCepChange(e: React.ChangeEvent<HTMLInputElement>) {
    const digits = onlyDigits(e.target.value).slice(0, 8);
    setValues((v) => ({ ...v, cep: formatCep(digits) }));
    if (digits.length !== 8) return;
    setLookup(true);
    try {
      const res = await fetch(`https://viacep.com.br/ws/${digits}/json/`);
      const data = (await res.json()) as ViaCepResponse;
      if (!data.erro) {
        setValues((v) => ({
          ...v,
          street: data.logradouro || v.street,
          district: data.bairro || v.district,
          city: data.localidade || v.city,
          state: data.uf || v.state,
        }));
      }
    } catch {
      /* preenchimento manual */
    } finally {
      setLookup(false);
    }
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setFields({});
    try {
      const address = await api<Address>("/api/addresses", { method: "POST", body: values });
      toast.success("Endereço salvo");
      onCreated(address);
    } catch (err) {
      toast.error(errorMessage(err));
      if (err instanceof ApiError && err.fields) setFields(err.fields);
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-3 sm:grid-cols-6">
      <Field label="CEP" className="sm:col-span-2" error={fields.cep}>
        <div className="relative">
          <Input value={values.cep} onChange={onCepChange} inputMode="numeric" placeholder="00000-000" required />
          {lookup && <Loader2 className="absolute top-2.5 right-2 size-4 animate-spin text-muted-foreground" />}
        </div>
      </Field>
      <Field label="Destinatário" className="sm:col-span-4" error={fields.recipient}>
        <Input value={values.recipient} onChange={set("recipient")} required />
      </Field>
      <Field label="Rua" className="sm:col-span-4" error={fields.street}>
        <Input value={values.street} onChange={set("street")} required />
      </Field>
      <Field label="Número" className="sm:col-span-2" error={fields.number}>
        <Input value={values.number} onChange={set("number")} required />
      </Field>
      <Field label="Complemento" className="sm:col-span-3">
        <Input value={values.complement} onChange={set("complement")} />
      </Field>
      <Field label="Bairro" className="sm:col-span-3" error={fields.district}>
        <Input value={values.district} onChange={set("district")} required />
      </Field>
      <Field label="Cidade" className="sm:col-span-3" error={fields.city}>
        <Input value={values.city} onChange={set("city")} required />
      </Field>
      <Field label="UF" className="sm:col-span-1" error={fields.state}>
        <Input value={values.state} onChange={set("state")} maxLength={2} required />
      </Field>
      <Field label="Apelido" className="sm:col-span-2">
        <Input value={values.label} onChange={set("label")} placeholder="Casa, Trabalho…" />
      </Field>
      <div className="flex gap-2 sm:col-span-6">
        <Button type="submit" disabled={loading}>
          {loading && <Loader2 className="animate-spin" />} Salvar endereço
        </Button>
        {onCancel && (
          <Button type="button" variant="ghost" onClick={onCancel}>
            Cancelar
          </Button>
        )}
      </div>
    </form>
  );
}

function Field({
  label,
  className,
  error,
  children,
}: {
  label: string;
  className?: string;
  error?: string[];
  children: React.ReactNode;
}) {
  return (
    <div className={`space-y-1.5 ${className ?? ""}`}>
      <Label>{label}</Label>
      {children}
      <FieldError messages={error} />
    </div>
  );
}
