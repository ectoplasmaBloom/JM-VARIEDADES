"use client";

import { useState } from "react";
import type { Address } from "@prisma/client";
import { MapPin, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { api, errorMessage } from "@/lib/api-client";
import { formatCep } from "@/lib/utils";
import { AddressForm } from "./address-form";

export function AddressBook({ initial }: { initial: Address[] }) {
  const [addresses, setAddresses] = useState(initial);
  const [adding, setAdding] = useState(initial.length === 0);

  async function remove(id: string) {
    if (!confirm("Excluir este endereço?")) return;
    try {
      await api(`/api/addresses/${id}`, { method: "DELETE" });
      setAddresses((list) => list.filter((a) => a.id !== id));
    } catch (e) {
      toast.error(errorMessage(e));
    }
  }

  return (
    <div className="space-y-3">
      {addresses.map((a) => (
        <Card key={a.id} className="py-4">
          <CardContent className="flex items-start gap-3 text-sm">
            <MapPin className="mt-0.5 size-5" />
            <div className="flex-1">
              <p className="flex items-center gap-2 font-medium">
                {a.label} {a.isDefault && <Badge variant="secondary">Padrão</Badge>}
              </p>
              <p className="text-muted-foreground">
                {a.recipient} · {a.street}, {a.number}
                {a.complement ? ` - ${a.complement}` : ""} · {a.district} · {a.city}/{a.state} · CEP {formatCep(a.cep)}
              </p>
            </div>
            <Button variant="ghost" size="icon" onClick={() => remove(a.id)} aria-label="Excluir endereço">
              <Trash2 className="text-destructive" />
            </Button>
          </CardContent>
        </Card>
      ))}
      {adding ? (
        <Card>
          <CardContent>
            <AddressForm
              onCreated={(a) => {
                setAddresses((list) => (a.isDefault ? [a, ...list.map((x) => ({ ...x, isDefault: false }))] : [...list, a]));
                setAdding(false);
              }}
              onCancel={addresses.length ? () => setAdding(false) : undefined}
            />
          </CardContent>
        </Card>
      ) : (
        <Button variant="outline" onClick={() => setAdding(true)}>
          <Plus /> Adicionar endereço
        </Button>
      )}
    </div>
  );
}
