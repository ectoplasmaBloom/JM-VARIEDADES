"use client";

import Image from "next/image";
import Link from "next/link";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { AlertTriangle, Loader2, Minus, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { api, errorMessage } from "@/lib/api-client";
import { formatBRL } from "@/lib/utils";
import type { CartDTO } from "@/server/services/cart.service";
import { CartShippingEstimate } from "./cart-shipping-estimate";

export function CartView({ cart, defaultCep }: { cart: CartDTO; defaultCep: string | null }) {
  const router = useRouter();
  const [busyId, setBusyId] = useState<string | null>(null);
  const [, startTransition] = useTransition();

  async function mutate(productId: string, request: () => Promise<unknown>) {
    setBusyId(productId);
    try {
      await request();
      startTransition(() => router.refresh());
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusyId(null);
    }
  }

  const setQty = (productId: string, quantity: number) =>
    mutate(productId, () => api(`/api/cart/items/${productId}`, { method: "PATCH", body: { quantity } }));
  const remove = (productId: string) =>
    mutate(productId, () => api(`/api/cart/items/${productId}`, { method: "DELETE" }));

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
      <Card className="py-2">
        <CardContent className="divide-y px-0">
          {cart.items.map((item) => (
            <div key={item.productId} className="flex gap-4 px-5 py-4">
              <Link href={`/products/${item.slug}`} className="relative size-20 shrink-0 overflow-hidden rounded-sm bg-sand">
                {item.image && <Image src={item.image} alt="" fill sizes="80px" className="object-contain p-1" />}
              </Link>
              <div className="flex min-w-0 flex-1 flex-col gap-1">
                <Link href={`/products/${item.slug}`} className="line-clamp-2 text-sm link-hover">
                  {item.title}
                </Link>
                {item.problem && (
                  <p className="flex items-center gap-1 text-xs text-destructive">
                    <AlertTriangle className="size-3.5" /> {item.problem}
                  </p>
                )}
                <div className="mt-auto flex flex-wrap items-center gap-3 pt-2">
                  <div className="flex items-center rounded-md border">
                    <button
                      className="p-1.5 disabled:opacity-40"
                      disabled={busyId === item.productId || item.quantity <= 1}
                      onClick={() => setQty(item.productId, item.quantity - 1)}
                      aria-label="Diminuir"
                    >
                      <Minus className="size-3.5" />
                    </button>
                    <span className="w-8 text-center text-sm tabular-nums">
                      {busyId === item.productId ? <Loader2 className="mx-auto size-3.5 animate-spin" /> : item.quantity}
                    </span>
                    <button
                      className="p-1.5 disabled:opacity-40"
                      disabled={busyId === item.productId || item.quantity >= item.stock}
                      onClick={() => setQty(item.productId, item.quantity + 1)}
                      aria-label="Aumentar"
                    >
                      <Plus className="size-3.5" />
                    </button>
                  </div>
                  <button
                    onClick={() => remove(item.productId)}
                    disabled={busyId === item.productId}
                    className="flex items-center gap-1 link text-xs"
                  >
                    <Trash2 className="size-3.5" /> Excluir
                  </button>
                </div>
              </div>
              <div className="text-right">
                <p className="font-medium">{formatBRL(item.subtotal)}</p>
                {item.quantity > 1 && <p className="text-xs text-muted-foreground">{formatBRL(item.unitPrice)} cada</p>}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="h-fit lg:sticky lg:top-28">
        <CardHeader>
          <CardTitle>Resumo da compra</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-sm">
          <div className="flex justify-between">
            <span>Produtos ({cart.itemCount})</span>
            <span>{formatBRL(cart.subtotal)}</span>
          </div>
          <CartShippingEstimate defaultCep={defaultCep} subtotal={cart.subtotal} itemsKey={cart.items.map((i) => `${i.productId}:${i.quantity}`).join(",")} />
          <Separator />
          {cart.hasProblems && (
            <p className="rounded-md bg-destructive/10 p-2 text-xs text-destructive">
              Ajuste os itens com problema de estoque antes de continuar.
            </p>
          )}
          {cart.hasProblems ? (
            <Button size="lg" className="w-full" disabled>
              Continuar a compra
            </Button>
          ) : (
            <Button asChild size="lg" className="w-full">
              <Link href="/checkout">Continuar a compra</Link>
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
