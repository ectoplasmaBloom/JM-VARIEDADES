"use client";

import { useCallback, useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { api, errorMessage } from "@/lib/api-client";
import { formatBRL, formatCep, onlyDigits } from "@/lib/utils";
import type { ShippingOptionView } from "@/components/product/shipping-calculator";

/** Estimativa de frete do carrinho (recalcula ao mudar itens/quantidades). */
export function CartShippingEstimate({
  defaultCep,
  subtotal,
  itemsKey,
}: {
  defaultCep: string | null;
  subtotal: number;
  itemsKey: string;
}) {
  const [cep, setCep] = useState(defaultCep ? formatCep(defaultCep) : "");
  const [cheapest, setCheapest] = useState<ShippingOptionView | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const calculate = useCallback(async (value: string) => {
    const digits = onlyDigits(value);
    if (digits.length !== 8) return setError("CEP inválido");
    setLoading(true);
    setError(null);
    try {
      const options = await api<ShippingOptionView[]>("/api/shipping/quote", {
        method: "POST",
        body: { destinationCep: digits },
      });
      setCheapest(options[0] ?? null);
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (onlyDigits(cep).length === 8) void calculate(cep);
    // recalcula quando os itens mudam
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [itemsKey, calculate]);

  return (
    <div className="space-y-2">
      <form
        className="flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          void calculate(cep);
        }}
      >
        <Input
          value={cep}
          onChange={(e) => setCep(formatCep(onlyDigits(e.target.value).slice(0, 8)))}
          placeholder="CEP"
          inputMode="numeric"
          aria-label="CEP para estimar frete"
          className="h-8"
        />
        <Button size="sm" variant="outline" disabled={loading}>
          {loading ? <Loader2 className="animate-spin" /> : "Calcular"}
        </Button>
      </form>
      {error && <p className="text-xs text-destructive">{error}</p>}
      <div className="flex justify-between">
        <span>Frete {cheapest ? `(${cheapest.service}, ${cheapest.deadlineDays} dias)` : ""}</span>
        <span>{cheapest ? formatBRL(cheapest.price) : "—"}</span>
      </div>
      <div className="flex justify-between text-base font-semibold">
        <span>Total estimado</span>
        <span>{formatBRL(subtotal + (cheapest?.price ?? 0))}</span>
      </div>
    </div>
  );
}
