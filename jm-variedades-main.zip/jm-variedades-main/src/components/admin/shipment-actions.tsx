"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import type { ShipmentStatus } from "@prisma/client";
import { Loader2, PackageCheck, Send } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { api, errorMessage } from "@/lib/api-client";

/** Ações da equipe sobre o envio: informar rastreio / marcar como entregue. */
export function ShipmentActions({
  shipmentId,
  status,
  trackingCode,
}: {
  shipmentId: string;
  status: ShipmentStatus;
  trackingCode: string | null;
}) {
  const router = useRouter();
  const [code, setCode] = useState(trackingCode ?? "");
  const [loading, setLoading] = useState(false);

  async function update(next: "SHIPPED" | "DELIVERED") {
    setLoading(true);
    try {
      await api(`/api/admin/shipments/${shipmentId}`, {
        method: "PATCH",
        body: { status: next, ...(next === "SHIPPED" ? { trackingCode: code } : {}) },
      });
      toast.success(next === "SHIPPED" ? "Envio registrado" : "Entrega confirmada");
      router.refresh();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setLoading(false);
    }
  }

  if (status === "READY_TO_SHIP") {
    return (
      <div className="flex gap-2">
        <Input
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          placeholder="Rastreio (AA123456789BR)"
          className="h-8 w-52"
          maxLength={13}
        />
        <Button size="sm" onClick={() => update("SHIPPED")} disabled={loading || code.length !== 13}>
          {loading ? <Loader2 className="animate-spin" /> : <Send />} Enviar
        </Button>
      </div>
    );
  }

  if (status === "SHIPPED") {
    return (
      <Button size="sm" variant="outline" onClick={() => update("DELIVERED")} disabled={loading}>
        {loading ? <Loader2 className="animate-spin" /> : <PackageCheck />} Marcar como entregue
      </Button>
    );
  }

  return null;
}
