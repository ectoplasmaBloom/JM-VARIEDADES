"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import type { Role, UserStatus } from "@prisma/client";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { api, errorMessage } from "@/lib/api-client";

export function UserActions({ userId, status, role }: { userId: string; status: UserStatus; role: Role }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function patch(body: { status?: UserStatus; role?: Role }, message: string) {
    setLoading(true);
    try {
      await api(`/api/admin/users/${userId}`, { method: "PATCH", body });
      toast.success(message);
      router.refresh();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex justify-end gap-1">
      {loading && <Loader2 className="size-4 animate-spin self-center" />}
      {role === "BUYER" ? (
        <Button
          size="sm"
          variant="ghost"
          disabled={loading}
          onClick={() =>
            confirm("Dar acesso ao painel da loja? A pessoa poderá gerenciar produtos, pedidos e contas.") &&
            patch({ role: "ADMIN" }, "Adicionado à equipe")
          }
        >
          Adicionar à equipe
        </Button>
      ) : (
        <Button size="sm" variant="ghost" disabled={loading} onClick={() => patch({ role: "BUYER" }, "Removido da equipe")}>
          Remover da equipe
        </Button>
      )}
      {status === "ACTIVE" ? (
        <Button
          size="sm"
          variant="outline"
          className="text-destructive"
          disabled={loading}
          onClick={() => confirm("Suspender esta conta? A pessoa não conseguirá mais entrar.") && patch({ status: "SUSPENDED" }, "Conta suspensa")}
        >
          Suspender
        </Button>
      ) : (
        <Button size="sm" variant="outline" disabled={loading} onClick={() => patch({ status: "ACTIVE" }, "Conta reativada")}>
          Reativar
        </Button>
      )}
    </div>
  );
}
