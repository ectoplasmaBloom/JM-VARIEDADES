"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import type { ProductStatus } from "@prisma/client";
import { Loader2, Pause, Play } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { api, errorMessage } from "@/lib/api-client";

/** Pausa (tira do catálogo) ou reativa um produto direto da lista. */
export function ProductStatusToggle({ productId, status }: { productId: string; status: ProductStatus }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const next: ProductStatus = status === "ACTIVE" ? "INACTIVE" : "ACTIVE";
  const label = next === "ACTIVE" ? "Reativar" : "Pausar";

  async function toggle() {
    setLoading(true);
    try {
      await api(`/api/admin/products/${productId}`, { method: "PATCH", body: { status: next } });
      toast.success(next === "ACTIVE" ? "Produto de volta ao catálogo" : "Produto pausado");
      router.refresh();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <Button variant="ghost" size="icon" onClick={toggle} disabled={loading} aria-label={label} title={label}>
      {loading ? <Loader2 className="animate-spin" /> : next === "ACTIVE" ? <Play /> : <Pause />}
    </Button>
  );
}
