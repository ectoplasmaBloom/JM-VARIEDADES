"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Undo2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { api, errorMessage } from "@/lib/api-client";

export function RefundButton({ orderId }: { orderId: string }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function refund() {
    if (!confirm("Estornar o pagamento deste pedido no Mercado Pago? O estoque será devolvido.")) return;
    setLoading(true);
    try {
      await api(`/api/admin/orders/${orderId}/refund`, { method: "POST" });
      toast.success("Estorno solicitado");
      router.refresh();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <Button size="sm" variant="ghost" onClick={refund} disabled={loading}>
      {loading ? <Loader2 className="animate-spin" /> : <Undo2 />} Estornar
    </Button>
  );
}
