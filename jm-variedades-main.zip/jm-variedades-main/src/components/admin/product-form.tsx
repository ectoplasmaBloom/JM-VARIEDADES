"use client";

import Image from "next/image";
import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ImagePlus, Loader2, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { FieldError } from "@/components/auth/auth-card";
import { ApiError, api, errorMessage } from "@/lib/api-client";

export interface ProductFormValues {
  title: string;
  description: string;
  price: number | "";
  stock: number | "";
  categoryId: string;
  images: string[];
  status: "ACTIVE" | "INACTIVE";
  weightGrams: number | "";
  lengthCm: number | "";
  widthCm: number | "";
  heightCm: number | "";
}

const EMPTY: ProductFormValues = {
  title: "",
  description: "",
  price: "",
  stock: 1,
  categoryId: "",
  images: [],
  status: "ACTIVE",
  weightGrams: 500,
  lengthCm: 20,
  widthCm: 15,
  heightCm: 10,
};

/** Formulário de cadastro/edição de produto com upload de imagens. */
export function ProductForm({
  productId,
  initial,
  categories,
}: {
  productId?: string;
  initial?: ProductFormValues;
  categories: Array<{ id: string; name: string }>;
}) {
  const router = useRouter();
  const fileRef = useRef<HTMLInputElement>(null);
  const [values, setValues] = useState<ProductFormValues>(initial ?? EMPTY);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [fields, setFields] = useState<Record<string, string[] | undefined>>({});

  const set =
    <K extends keyof ProductFormValues>(key: K) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
      const raw = e.target.value;
      const numeric = typeof EMPTY[key] === "number" || key === "price";
      setValues((v) => ({ ...v, [key]: numeric ? (raw === "" ? "" : Number(raw)) : raw }));
    };

  async function upload(files: FileList | null) {
    if (!files?.length) return;
    const form = new FormData();
    for (const f of Array.from(files).slice(0, 8 - values.images.length)) form.append("files", f);
    setUploading(true);
    try {
      const { urls } = await api<{ urls: string[] }>("/api/uploads", { method: "POST", body: form });
      setValues((v) => ({ ...v, images: [...v.images, ...urls].slice(0, 8) }));
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setFields({});
    try {
      if (productId) {
        await api(`/api/products/${productId}`, { method: "PATCH", body: values });
        toast.success("Produto atualizado");
      } else {
        await api("/api/products", { method: "POST", body: values });
        toast.success("Produto cadastrado");
      }
      router.push("/admin/products");
      router.refresh();
    } catch (err) {
      toast.error(errorMessage(err));
      if (err instanceof ApiError && err.fields) setFields(err.fields);
      setSaving(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Informações</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5 sm:col-span-2">
            <Label htmlFor="title">Título</Label>
            <Input id="title" value={values.title} onChange={set("title")} required maxLength={150} />
            <FieldError messages={fields.title} />
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label htmlFor="description">Descrição</Label>
            <Textarea id="description" value={values.description} onChange={set("description")} rows={6} required />
            <FieldError messages={fields.description} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="categoryId">Categoria</Label>
            <Select id="categoryId" value={values.categoryId} onChange={set("categoryId")} required>
              <option value="">Selecione…</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </Select>
            <FieldError messages={fields.categoryId} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="status">Status</Label>
            <Select id="status" value={values.status} onChange={set("status")}>
              <option value="ACTIVE">Ativo (visível no catálogo)</option>
              <option value="INACTIVE">Pausado</option>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="price">Preço (R$)</Label>
            <Input id="price" type="number" min="0.01" step="0.01" value={values.price} onChange={set("price")} required />
            <FieldError messages={fields.price} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="stock">Estoque</Label>
            <Input id="stock" type="number" min="0" step="1" value={values.stock} onChange={set("stock")} required />
            <FieldError messages={fields.stock} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Imagens</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="flex flex-wrap gap-3">
            {values.images.map((src, i) => (
              <div key={src} className="relative size-24 overflow-hidden rounded-sm bg-sand">
                <Image src={src} alt={`Imagem ${i + 1}`} fill sizes="96px" className="object-contain" />
                <button
                  type="button"
                  onClick={() => setValues((v) => ({ ...v, images: v.images.filter((x) => x !== src) }))}
                  className="absolute top-1 right-1 rounded-full bg-black/60 p-0.5 text-white"
                  aria-label="Remover imagem"
                >
                  <X className="size-3.5" />
                </button>
                {i === 0 && <span className="absolute bottom-0 w-full bg-ink/85 py-0.5 text-center text-[10px] tracking-[0.14em] text-ivory uppercase">Capa</span>}
              </div>
            ))}
            {values.images.length < 8 && (
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                disabled={uploading}
                className="grid size-24 place-items-center rounded-sm border border-dashed border-ink/25 text-stone hover:bg-card hover:border-primary link-hover"
              >
                {uploading ? <Loader2 className="animate-spin" /> : <ImagePlus />}
              </button>
            )}
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            multiple
            hidden
            onChange={(e) => upload(e.target.files)}
          />
          <p className="text-xs text-muted-foreground">Até 8 imagens JPG, PNG ou WEBP (máx. 4 MB cada). A primeira é a capa.</p>
          <FieldError messages={fields.images} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Embalagem (cálculo de frete)</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-4">
          {(
            [
              ["weightGrams", "Peso (g)"],
              ["lengthCm", "Comprimento (cm)"],
              ["widthCm", "Largura (cm)"],
              ["heightCm", "Altura (cm)"],
            ] as const
          ).map(([key, label]) => (
            <div key={key} className="space-y-1.5">
              <Label htmlFor={key}>{label}</Label>
              <Input id={key} type="number" min="1" step="1" value={values[key]} onChange={set(key)} required />
              <FieldError messages={fields[key]} />
            </div>
          ))}
        </CardContent>
      </Card>

      <div className="flex gap-2">
        <Button type="submit" size="lg" disabled={saving || uploading}>
          {saving && <Loader2 className="animate-spin" />} {productId ? "Salvar alterações" : "Publicar produto"}
        </Button>
        <Button type="button" size="lg" variant="ghost" onClick={() => router.back()}>
          Cancelar
        </Button>
      </div>
    </form>
  );
}
