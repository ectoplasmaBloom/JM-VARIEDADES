import "server-only";
import type { Role } from "@prisma/client";
import { auth } from "@/auth";
import { ForbiddenError, UnauthorizedError } from "@/domain/errors";
import { prisma } from "@/infrastructure/db/prisma";

export interface SessionUser {
  id: string;
  role: Role;
  name: string;
  email: string;
}

export async function currentUser(): Promise<SessionUser | null> {
  const session = await auth();
  if (!session?.user?.id) return null;
  return {
    id: session.user.id,
    role: session.user.role,
    name: session.user.name ?? "",
    email: session.user.email ?? "",
  };
}

/**
 * Exige usuário autenticado e ativo. O status é conferido no banco a cada
 * chamada para que uma suspensão feita pelo admin tenha efeito imediato,
 * e o perfil é lido do banco (o JWT pode estar desatualizado).
 */
export async function requireUser(): Promise<SessionUser> {
  const user = await currentUser();
  if (!user) throw new UnauthorizedError();

  const db = await prisma.user.findUnique({
    where: { id: user.id },
    select: { status: true, role: true },
  });
  if (!db || db.status !== "ACTIVE") throw new UnauthorizedError("Conta inativa ou suspensa");
  return { ...user, role: db.role };
}

export async function requireRole(...roles: Role[]): Promise<SessionUser> {
  const user = await requireUser();
  if (!roles.includes(user.role)) throw new ForbiddenError();
  return user;
}
