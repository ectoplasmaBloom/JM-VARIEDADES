import { z } from "zod";

/**
 * Schemas Zod de validação de entrada (camada de aplicação).
 * Toda entrada externa (body, query, form) passa por aqui antes dos serviços.
 */

const cep = z
  .string()
  .transform((v) => v.replace(/\D/g, ""))
  .refine((v) => /^\d{8}$/.test(v), "CEP inválido");

const password = z
  .string()
  .min(8, "A senha deve ter ao menos 8 caracteres")
  .max(72, "A senha deve ter no máximo 72 caracteres")
  .regex(/[A-Za-z]/, "A senha deve conter letras")
  .regex(/\d/, "A senha deve conter números");

export const cepSchema = cep;

// ---------- Autenticação ----------

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email("E-mail inválido"),
  password: z.string().min(1, "Informe a senha"),
});

/** Cadastro público cria sempre uma conta de cliente (a equipe é promovida no painel). */
export const registerSchema = z.object({
  name: z.string().trim().min(2, "Informe seu nome").max(100),
  email: z.string().trim().toLowerCase().email("E-mail inválido"),
  password,
});

export const forgotPasswordSchema = z.object({
  email: z.string().trim().toLowerCase().email("E-mail inválido"),
});

export const resetPasswordSchema = z.object({
  token: z.string().min(32).max(128),
  password,
});

// ---------- Catálogo ----------

export const productSchema = z.object({
  title: z.string().trim().min(3, "Título muito curto").max(150),
  description: z.string().trim().min(10, "Descrição muito curta").max(5000),
  price: z.coerce.number().positive("Preço deve ser maior que zero").max(1_000_000),
  stock: z.coerce.number().int().min(0, "Estoque não pode ser negativo").max(1_000_000),
  categoryId: z.string().min(1, "Selecione uma categoria"),
  images: z
    .array(
      z
        .string()
        .refine((u) => u.startsWith("/uploads/") || u.startsWith("/seed/") || /^https:\/\//.test(u), "URL inválida"),
    )
    .min(1, "Envie ao menos uma imagem")
    .max(8),
  status: z.enum(["ACTIVE", "INACTIVE"]).default("ACTIVE"),
  weightGrams: z.coerce.number().int().min(1).max(30000),
  lengthCm: z.coerce.number().int().min(1).max(100),
  widthCm: z.coerce.number().int().min(1).max(100),
  heightCm: z.coerce.number().int().min(1).max(100),
});

export const productUpdateSchema = productSchema.partial();

export const productQuerySchema = z.object({
  q: z.string().trim().max(100).optional(),
  category: z.string().trim().max(80).optional(),
  minPrice: z.coerce.number().min(0).optional(),
  maxPrice: z.coerce.number().min(0).optional(),
  sort: z.enum(["recent", "price_asc", "price_desc"]).default("recent"),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(48).default(12),
});

export type ProductQuery = z.infer<typeof productQuerySchema>;

// ---------- Carrinho / frete / checkout ----------

export const addCartItemSchema = z.object({
  productId: z.string().min(1),
  quantity: z.coerce.number().int().min(1).max(99).default(1),
});

export const updateCartItemSchema = z.object({
  quantity: z.coerce.number().int().min(1).max(99),
});

export const shippingQuoteSchema = z
  .object({
    destinationCep: cep,
    productId: z.string().optional(),
    quantity: z.coerce.number().int().min(1).max(99).default(1),
  });

export const addressSchema = z.object({
  label: z.string().trim().min(1).max(40).default("Casa"),
  recipient: z.string().trim().min(2, "Informe o destinatário").max(100),
  cep,
  street: z.string().trim().min(2, "Informe a rua").max(150),
  number: z.string().trim().min(1, "Informe o número").max(20),
  complement: z.string().trim().max(80).optional().or(z.literal("").transform(() => undefined)),
  district: z.string().trim().min(2, "Informe o bairro").max(80),
  city: z.string().trim().min(2, "Informe a cidade").max(80),
  state: z
    .string()
    .trim()
    .toUpperCase()
    .regex(/^[A-Z]{2}$/, "UF inválida"),
  isDefault: z.boolean().optional(),
});

export const checkoutSchema = z.object({
  addressId: z.string().min(1, "Selecione um endereço"),
  serviceCode: z.string().min(1, "Selecione o frete"),
});

// ---------- Painel da loja ----------

export const adminUserUpdateSchema = z.object({
  status: z.enum(["ACTIVE", "SUSPENDED"]).optional(),
  role: z.enum(["BUYER", "ADMIN"]).optional(),
});

export const adminProductUpdateSchema = z.object({
  status: z.enum(["ACTIVE", "INACTIVE"]),
});

export const shipmentUpdateSchema = z.object({
  status: z.enum(["READY_TO_SHIP", "SHIPPED", "DELIVERED"]),
  trackingCode: z
    .string()
    .trim()
    .toUpperCase()
    .regex(/^[A-Z]{2}\d{9}[A-Z]{2}$/, "Código de rastreio inválido (ex.: AA123456789BR)")
    .optional(),
});
