import "server-only";
import { createHash, randomBytes } from "node:crypto";
import bcrypt from "bcryptjs";
import type { Role, UserStatus } from "@prisma/client";
import { ConflictError, ForbiddenError, NotFoundError, ValidationError } from "@/domain/errors";
import { prisma } from "@/infrastructure/db/prisma";
import { sendMail } from "@/infrastructure/mail/mailer";
import { env } from "@/lib/env";
import { STORE } from "@/lib/store";
import type { SessionUser } from "@/server/session";
import type { addressSchema, registerSchema } from "@/server/validators";
import type { z } from "zod";

const BCRYPT_ROUNDS = 10;
const RESET_TTL_MS = 60 * 60 * 1000;

// ------------------------------------------------------------------ autenticação

export async function registerUser(input: z.infer<typeof registerSchema>) {
  const exists = await prisma.user.findUnique({ where: { email: input.email }, select: { id: true } });
  if (exists) throw new ConflictError("E-mail já cadastrado");

  return prisma.user.create({
    data: {
      name: input.name,
      email: input.email,
      passwordHash: await bcrypt.hash(input.password, BCRYPT_ROUNDS),
    },
    select: { id: true, email: true, role: true },
  });
}

const sha256 = (value: string) => createHash("sha256").update(value).digest("hex");

/**
 * Gera token de recuperação. Sempre responde igual para não revelar se o e-mail existe.
 * Em desenvolvimento sem SMTP, devolve o link para ser exibido na tela (null nos demais casos).
 */
export async function requestPasswordReset(email: string): Promise<string | null> {
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user || user.status !== "ACTIVE") return null;

  const token = randomBytes(32).toString("hex");
  await prisma.$transaction([
    prisma.passwordResetToken.deleteMany({ where: { userId: user.id } }),
    prisma.passwordResetToken.create({
      data: { userId: user.id, tokenHash: sha256(token), expiresAt: new Date(Date.now() + RESET_TTL_MS) },
    }),
  ]);

  const link = `${env().APP_URL}/reset-password?token=${token}`;
  await sendMail({
    to: user.email,
    subject: `Recuperação de senha - ${STORE.name}`,
    text: `Olá, ${user.name}!\n\nPara redefinir sua senha acesse: ${link}\n\nO link expira em 1 hora.`,
    html: `<p>Olá, ${escapeHtml(user.name)}!</p><p>Para redefinir sua senha clique em <a href="${link}">redefinir senha</a>.</p><p>O link expira em 1 hora.</p>`,
  });
  return process.env.NODE_ENV !== "production" && !env().SMTP_HOST ? link : null;
}

export async function resetPassword(token: string, password: string): Promise<void> {
  const record = await prisma.passwordResetToken.findUnique({ where: { tokenHash: sha256(token) } });
  if (!record || record.usedAt || record.expiresAt < new Date()) {
    throw new ValidationError("Link inválido ou expirado. Solicite uma nova recuperação.");
  }
  await prisma.$transaction([
    prisma.user.update({
      where: { id: record.userId },
      data: { passwordHash: await bcrypt.hash(password, BCRYPT_ROUNDS) },
    }),
    prisma.passwordResetToken.update({ where: { id: record.id }, data: { usedAt: new Date() } }),
  ]);
}

// ------------------------------------------------------------------ endereços

export async function listAddresses(userId: string) {
  return prisma.address.findMany({
    where: { userId },
    orderBy: [{ isDefault: "desc" }, { createdAt: "asc" }],
  });
}

export async function createAddress(userId: string, input: z.infer<typeof addressSchema>) {
  const count = await prisma.address.count({ where: { userId } });
  if (count >= 10) throw new ValidationError("Limite de 10 endereços atingido");
  const isDefault = input.isDefault ?? count === 0;

  return prisma.$transaction(async (tx) => {
    if (isDefault) await tx.address.updateMany({ where: { userId }, data: { isDefault: false } });
    return tx.address.create({ data: { ...input, userId, isDefault } });
  });
}

export async function deleteAddress(userId: string, id: string): Promise<void> {
  const address = await prisma.address.findUnique({ where: { id } });
  if (!address) throw new NotFoundError("Endereço");
  if (address.userId !== userId) throw new ForbiddenError();
  await prisma.address.delete({ where: { id } });
}

// ------------------------------------------------------------------ admin

export async function listUsers(role?: Role) {
  return prisma.user.findMany({
    where: role ? { role } : {},
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      status: true,
      createdAt: true,
      _count: { select: { orders: true } },
    },
    take: 500,
  });
}

export async function adminUpdateUser(
  admin: SessionUser,
  userId: string,
  input: { status?: UserStatus; role?: Role },
) {
  if (admin.id === userId) throw new ValidationError("Você não pode alterar a própria conta");
  return prisma.user.update({ where: { id: userId }, data: input, select: { id: true, status: true, role: true } });
}

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);
}
