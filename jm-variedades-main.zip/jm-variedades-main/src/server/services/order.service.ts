import "server-only";
import type { OrderStatus, Prisma, ShipmentStatus } from "@prisma/client";
import { ForbiddenError, NotFoundError, ValidationError } from "@/domain/errors";
import { prisma } from "@/infrastructure/db/prisma";
import type { SessionUser } from "@/server/session";

export interface ShippingAddressSnapshot {
  recipient: string;
  cep: string;
  street: string;
  number: string;
  complement?: string | null;
  district: string;
  city: string;
  state: string;
}

const detailInclude = {
  buyer: { select: { name: true, email: true } },
  items: { include: { product: { select: { slug: true } } } },
  payments: { orderBy: { createdAt: "desc" }, include: { transactions: { orderBy: { createdAt: "asc" } } } },
  shipments: { orderBy: { createdAt: "asc" } },
  statusHistory: { orderBy: { createdAt: "asc" } },
} satisfies Prisma.OrderInclude;

export type OrderDetail = Prisma.OrderGetPayload<{ include: typeof detailInclude }>;

/** Histórico de pedidos do comprador. */
export async function listBuyerOrders(buyerId: string) {
  return prisma.order.findMany({
    where: { buyerId },
    orderBy: { createdAt: "desc" },
    include: {
      items: { select: { title: true, quantity: true, imageUrl: true } },
      payments: { select: { externalId: true, status: true }, orderBy: { createdAt: "desc" }, take: 1 },
    },
  });
}

/**
 * Detalhe do pedido com controle de acesso:
 * - cliente: apenas os próprios pedidos
 * - equipe da loja (admin): todos
 */
export async function getOrderForUser(user: SessionUser, orderId: string): Promise<OrderDetail> {
  const order = await prisma.order.findUnique({ where: { id: orderId }, include: detailInclude });
  if (!order) throw new NotFoundError("Pedido");
  if (user.role !== "ADMIN" && order.buyerId !== user.id) throw new ForbiddenError();
  return order;
}

/** Pedidos da loja para o painel: itens, envio e dados do cliente. */
export async function listStoreOrders(status?: OrderStatus) {
  const orders = await prisma.order.findMany({
    where: status ? { status } : {},
    orderBy: { createdAt: "desc" },
    include: {
      buyer: { select: { name: true, email: true } },
      items: { select: { title: true, quantity: true, subtotal: true } },
      shipments: { orderBy: { createdAt: "asc" } },
    },
    take: 200,
  });
  return orders.map((o) => ({
    id: o.id,
    createdAt: o.createdAt,
    status: o.status,
    buyerName: o.buyer.name,
    buyerEmail: o.buyer.email,
    subtotal: Number(o.subtotal),
    shippingTotal: Number(o.shippingTotal),
    total: Number(o.total),
    items: o.items.map((i) => ({ title: i.title, quantity: i.quantity, subtotal: Number(i.subtotal) })),
    shipments: o.shipments.map((s) => ({
      id: s.id,
      status: s.status,
      service: s.service,
      price: Number(s.price),
      trackingCode: s.trackingCode,
    })),
  }));
}

/** Equipe da loja atualiza o envio (postagem / rastreio) de um pedido aprovado. */
export async function updateShipment(
  shipmentId: string,
  input: { status: ShipmentStatus; trackingCode?: string },
) {
  const shipment = await prisma.shipment.findUnique({ where: { id: shipmentId }, include: { order: true } });
  if (!shipment) throw new NotFoundError("Envio");
  if (shipment.order.status !== "APPROVED") {
    throw new ValidationError("Só é possível despachar pedidos com pagamento aprovado");
  }
  if (input.status === "SHIPPED" && !input.trackingCode && !shipment.trackingCode) {
    throw new ValidationError("Informe o código de rastreio para marcar como enviado");
  }
  return prisma.shipment.update({
    where: { id: shipmentId },
    data: { status: input.status, ...(input.trackingCode ? { trackingCode: input.trackingCode } : {}) },
  });
}

/**
 * Cancela pedidos PENDENTES sem pagamento após o TTL (executado pelo Vercel Cron).
 * Pedidos pendentes não reservam estoque, então não há devolução.
 */
export async function expirePendingOrders(ttlMinutes: number): Promise<number> {
  const limit = new Date(Date.now() - ttlMinutes * 60_000);
  const stale = await prisma.order.findMany({
    where: { status: "PENDING", createdAt: { lt: limit }, payments: { none: { status: { in: ["IN_PROCESS", "AUTHORIZED", "IN_MEDIATION"] } } } },
    select: { id: true },
  });
  let cancelled = 0;
  for (const { id } of stale) {
    await prisma.$transaction(async (tx) => {
      // updateMany condicional: se um webhook aprovou no meio tempo, nada muda
      const { count } = await tx.order.updateMany({
        where: { id, status: "PENDING" },
        data: { status: "CANCELLED" },
      });
      if (count === 0) return;
      cancelled++;
      await tx.orderStatusHistory.create({
        data: { orderId: id, fromStatus: "PENDING", toStatus: "CANCELLED", reason: "Expirado sem pagamento" },
      });
      await tx.shipment.updateMany({ where: { orderId: id }, data: { status: "CANCELLED" } });
    });
  }
  return cancelled;
}
