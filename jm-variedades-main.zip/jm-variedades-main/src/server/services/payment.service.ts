import "server-only";
import { Prisma, type OrderStatus } from "@prisma/client";
import {
  canTransition,
  orderStatusFromPayment,
  type GatewayPayment,
  type PaymentGateway,
} from "@/domain/payment";
import { prisma } from "@/infrastructure/db/prisma";
import { paymentGateway } from "@/infrastructure/payment";
import { toCents } from "@/lib/utils";

export type PaymentProcessingResult =
  | { outcome: "ignored"; reason: string }
  | { outcome: "recorded"; orderId: string; orderStatus: OrderStatus };

class InsufficientStockOnApproval extends Error {}

/**
 * Caso de uso: processar uma notificação de pagamento (webhook ou retorno).
 *
 * - Nunca confia no corpo da notificação: consulta o pagamento na API do MP.
 * - Salva o histórico completo (Payment + PaymentTransaction).
 * - Aplica a máquina de estados do pedido de forma idempotente, com lock de linha
 *   (SELECT ... FOR UPDATE) para suportar notificações duplicadas/concorrentes.
 * - Aprovado  -> baixa estoque (uma única vez) e aprova o pedido.
 *                Se faltar estoque nesse momento, estorna automaticamente.
 * - Recusado  -> cancela o pedido automaticamente.
 * - Estornado -> marca como reembolsado e devolve o estoque.
 */
export async function processPaymentNotification(
  externalId: string,
  source: string,
  gateway: PaymentGateway = paymentGateway(),
): Promise<PaymentProcessingResult> {
  const payment = await gateway.getPayment(externalId);
  if (!payment.orderId) return { outcome: "ignored", reason: "Pagamento sem external_reference" };

  const order = await prisma.order.findUnique({ where: { id: payment.orderId }, select: { id: true } });
  if (!order) return { outcome: "ignored", reason: `Pedido ${payment.orderId} não encontrado` };

  try {
    const status = await applyPayment(payment, source);
    return { outcome: "recorded", orderId: order.id, orderStatus: status };
  } catch (error) {
    if (!(error instanceof InsufficientStockOnApproval)) throw error;

    // Pagamento aprovado mas o estoque acabou (outra compra levou antes): estorna.
    await gateway.refund(payment.externalId);
    const status = await transitionOrder(order.id, "REFUNDED", "Estoque insuficiente na aprovação; pagamento estornado");
    return { outcome: "recorded", orderId: order.id, orderStatus: status };
  }
}

async function applyPayment(payment: GatewayPayment, source: string): Promise<OrderStatus> {
  return prisma.$transaction(
    async (tx) => {
      // Lock pessimista no pedido (query parametrizada: sem risco de SQL injection)
      await tx.$queryRaw`SELECT id FROM "Order" WHERE id = ${payment.orderId} FOR UPDATE`;
      const order = await tx.order.findUniqueOrThrow({
        where: { id: payment.orderId! },
        include: { items: true },
      });

      // 1) Histórico de transações
      const saved = await tx.payment.upsert({
        where: { externalId: payment.externalId },
        create: {
          orderId: order.id,
          externalId: payment.externalId,
          status: payment.status,
          statusDetail: payment.statusDetail,
          paymentMethod: payment.paymentMethod,
          paymentType: payment.paymentType,
          amount: payment.amount,
          approvedAt: payment.approvedAt,
        },
        update: {
          status: payment.status,
          statusDetail: payment.statusDetail,
          paymentMethod: payment.paymentMethod,
          paymentType: payment.paymentType,
          approvedAt: payment.approvedAt,
        },
      });
      await tx.paymentTransaction.create({
        data: {
          paymentId: saved.id,
          status: payment.status,
          detail: payment.statusDetail,
          source,
          rawPayload: JSON.parse(JSON.stringify(payment.raw ?? {})) as Prisma.InputJsonValue,
        },
      });

      // 2) Máquina de estados do pedido
      const target = orderStatusFromPayment(payment.status);
      if (target === order.status || !canTransition(order.status, target)) return order.status;

      if (target === "APPROVED") {
        if (payment.amount * 100 + 1 < toCents(order.total)) {
          await tx.orderStatusHistory.create({
            data: {
              orderId: order.id,
              fromStatus: order.status,
              toStatus: order.status,
              reason: `Pagamento ${payment.externalId} com valor divergente (${payment.amount}); não aprovado`,
            },
          });
          return order.status;
        }

        if (!order.stockDeducted) {
          for (const item of order.items) {
            // Decremento condicional: só baixa se houver estoque suficiente
            const updated = await tx.product.updateMany({
              where: { id: item.productId, stock: { gte: item.quantity } },
              data: { stock: { decrement: item.quantity } },
            });
            if (updated.count === 0) throw new InsufficientStockOnApproval();
          }
        }

        await tx.order.update({
          where: { id: order.id },
          data: {
            status: "APPROVED",
            stockDeducted: true,
            statusHistory: {
              create: { fromStatus: order.status, toStatus: "APPROVED", reason: `Pagamento ${payment.externalId} aprovado` },
            },
          },
        });
        await tx.shipment.updateMany({ where: { orderId: order.id }, data: { status: "READY_TO_SHIP" } });
        return "APPROVED";
      }

      if (target === "CANCELLED") {
        await tx.order.update({
          where: { id: order.id },
          data: {
            status: "CANCELLED",
            statusHistory: {
              create: {
                fromStatus: order.status,
                toStatus: "CANCELLED",
                reason: `Pagamento ${payment.externalId} ${payment.status === "REJECTED" ? "recusado" : "cancelado"} (${payment.statusDetail ?? "-"})`,
              },
            },
          },
        });
        await tx.shipment.updateMany({ where: { orderId: order.id }, data: { status: "CANCELLED" } });
        return "CANCELLED";
      }

      // REFUNDED
      await restock(tx, order.id);
      await tx.order.update({
        where: { id: order.id },
        data: {
          status: "REFUNDED",
          stockDeducted: false,
          statusHistory: {
            create: { fromStatus: order.status, toStatus: "REFUNDED", reason: `Pagamento ${payment.externalId} estornado` },
          },
        },
      });
      await tx.shipment.updateMany({ where: { orderId: order.id }, data: { status: "CANCELLED" } });
      return "REFUNDED";
    },
    { isolationLevel: Prisma.TransactionIsolationLevel.ReadCommitted, timeout: 15_000 },
  );
}

/** Transição administrativa (fora do fluxo de webhook), com devolução de estoque se necessário. */
export async function transitionOrder(orderId: string, to: OrderStatus, reason: string): Promise<OrderStatus> {
  return prisma.$transaction(async (tx) => {
    await tx.$queryRaw`SELECT id FROM "Order" WHERE id = ${orderId} FOR UPDATE`;
    const order = await tx.order.findUniqueOrThrow({ where: { id: orderId } });
    if (order.status === to) return to;

    if (to === "REFUNDED" || to === "CANCELLED") await restock(tx, orderId);
    await tx.order.update({
      where: { id: orderId },
      data: {
        status: to,
        stockDeducted: false,
        statusHistory: { create: { fromStatus: order.status, toStatus: to, reason } },
      },
    });
    if (to === "REFUNDED" || to === "CANCELLED") {
      await tx.shipment.updateMany({ where: { orderId }, data: { status: "CANCELLED" } });
    }
    return to;
  });
}

async function restock(tx: Prisma.TransactionClient, orderId: string): Promise<void> {
  const order = await tx.order.findUniqueOrThrow({ where: { id: orderId }, include: { items: true } });
  if (!order.stockDeducted) return;
  for (const item of order.items) {
    await tx.product.update({ where: { id: item.productId }, data: { stock: { increment: item.quantity } } });
  }
}
