import "server-only";
import { buildPackage, type PackageItem, type ShippingOption } from "@/domain/shipping";
import { NotFoundError, ValidationError } from "@/domain/errors";
import { prisma } from "@/infrastructure/db/prisma";
import { shippingProvider } from "@/infrastructure/shipping";
import { env } from "@/lib/env";

/** Opção de frete com os dados do volume, gravados no envio do pedido. */
export interface QuotedShippingOption extends ShippingOption {
  originCep: string;
  weightGrams: number;
}

/**
 * A loja despacha tudo de um único endereço (SHIPPING_ORIGIN_CEP):
 * os itens viram um só volume e cada serviço dos Correios é uma opção.
 */
export async function quoteItems(items: PackageItem[], destinationCep: string): Promise<QuotedShippingOption[]> {
  if (items.length === 0) throw new ValidationError("Nenhum item para calcular o frete");

  const originCep = env().SHIPPING_ORIGIN_CEP;
  const pkg = buildPackage(items);
  const options = await shippingProvider().quote({ originCep, destinationCep, pkg });
  return options
    .map((o) => ({ ...o, originCep, weightGrams: pkg.weightGrams }))
    .sort((a, b) => a.price - b.price);
}

/** Cálculo na página do produto. */
export async function quoteProduct(productId: string, quantity: number, destinationCep: string) {
  const product = await prisma.product.findFirst({ where: { id: productId, status: "ACTIVE", deletedAt: null } });
  if (!product) throw new NotFoundError("Produto");
  return quoteItems([{ ...dimensions(product), quantity }], destinationCep);
}

/** Cálculo no carrinho/checkout: usa os itens persistidos do carrinho. */
export async function quoteCart(userId: string, destinationCep: string) {
  const items = await prisma.cartItem.findMany({ where: { cart: { userId } }, include: { product: true } });
  return quoteItems(
    items.map(({ product, quantity }) => ({ ...dimensions(product), quantity })),
    destinationCep,
  );
}

function dimensions(p: { weightGrams: number; lengthCm: number; widthCm: number; heightCm: number }) {
  return { weightGrams: p.weightGrams, lengthCm: p.lengthCm, widthCm: p.widthCm, heightCm: p.heightCm };
}
