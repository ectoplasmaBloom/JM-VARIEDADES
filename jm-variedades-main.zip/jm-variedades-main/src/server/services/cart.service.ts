import "server-only";
import { NotFoundError, OutOfStockError } from "@/domain/errors";
import { prisma } from "@/infrastructure/db/prisma";
import { fromCents, toCents } from "@/lib/utils";

export interface CartItemDTO {
  productId: string;
  slug: string;
  title: string;
  image: string | null;
  unitPrice: number;
  quantity: number;
  stock: number;
  subtotal: number;
  /** Produto indisponível (pausado ou excluído) ou estoque insuficiente */
  problem: string | null;
}

export interface CartDTO {
  items: CartItemDTO[];
  itemCount: number;
  subtotal: number;
  hasProblems: boolean;
}

async function ensureCart(userId: string) {
  return prisma.cart.upsert({ where: { userId }, create: { userId }, update: {}, select: { id: true } });
}

export async function getCart(userId: string): Promise<CartDTO> {
  const cart = await prisma.cart.findUnique({
    where: { userId },
    include: {
      items: {
        orderBy: { createdAt: "asc" },
        include: { product: true },
      },
    },
  });

  const items: CartItemDTO[] = (cart?.items ?? []).map(({ product: p, quantity }) => {
    const available = p.status === "ACTIVE" && !p.deletedAt;
    const problem = !available
      ? "Produto indisponível"
      : p.stock < quantity
        ? p.stock === 0
          ? "Sem estoque"
          : `Apenas ${p.stock} em estoque`
        : null;
    return {
      productId: p.id,
      slug: p.slug,
      title: p.title,
      image: p.images[0] ?? null,
      unitPrice: Number(p.price),
      quantity,
      stock: p.stock,
      subtotal: fromCents(toCents(p.price) * quantity),
      problem,
    };
  });

  return {
    items,
    itemCount: items.reduce((n, i) => n + i.quantity, 0),
    subtotal: fromCents(items.reduce((sum, i) => sum + toCents(i.subtotal), 0)),
    hasProblems: items.some((i) => i.problem !== null),
  };
}

export async function getCartCount(userId: string): Promise<number> {
  const result = await prisma.cartItem.aggregate({
    where: { cart: { userId } },
    _sum: { quantity: true },
  });
  return result._sum.quantity ?? 0;
}

/** Regra: não permitir adicionar mais itens do que o estoque disponível. */
export async function addItem(userId: string, productId: string, quantity: number): Promise<void> {
  const product = await prisma.product.findFirst({
    where: { id: productId, status: "ACTIVE", deletedAt: null },
  });
  if (!product) throw new NotFoundError("Produto");

  const cart = await ensureCart(userId);
  const existing = await prisma.cartItem.findUnique({
    where: { cartId_productId: { cartId: cart.id, productId } },
  });
  const newQuantity = (existing?.quantity ?? 0) + quantity;
  if (newQuantity > product.stock) throw new OutOfStockError(product.title, product.stock);

  await prisma.cartItem.upsert({
    where: { cartId_productId: { cartId: cart.id, productId } },
    create: { cartId: cart.id, productId, quantity },
    update: { quantity: newQuantity },
  });
}

export async function updateItemQuantity(userId: string, productId: string, quantity: number): Promise<void> {
  const item = await prisma.cartItem.findFirst({
    where: { productId, cart: { userId } },
    include: { product: true },
  });
  if (!item) throw new NotFoundError("Item do carrinho");
  if (quantity > item.product.stock) throw new OutOfStockError(item.product.title, item.product.stock);
  await prisma.cartItem.update({ where: { id: item.id }, data: { quantity } });
}

export async function removeItem(userId: string, productId: string): Promise<void> {
  await prisma.cartItem.deleteMany({ where: { productId, cart: { userId } } });
}

export async function clearCart(userId: string): Promise<void> {
  await prisma.cartItem.deleteMany({ where: { cart: { userId } } });
}
