import "server-only";
import { randomBytes } from "node:crypto";
import { Prisma, type ProductStatus } from "@prisma/client";
import { NotFoundError, ValidationError } from "@/domain/errors";
import { prisma } from "@/infrastructure/db/prisma";
import { slugify } from "@/lib/utils";
import type { ProductQuery, productSchema, productUpdateSchema } from "@/server/validators";
import type { z } from "zod";

export interface ProductCardDTO {
  id: string;
  slug: string;
  title: string;
  price: number;
  image: string | null;
  stock: number;
  categoryName: string;
}

export interface ProductDetailDTO extends ProductCardDTO {
  description: string;
  images: string[];
  categorySlug: string;
  weightGrams: number;
  lengthCm: number;
  widthCm: number;
  heightCm: number;
}

export interface Paginated<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

/** Filtro base do catálogo público: ativo e não excluído. */
const PUBLIC_FILTER = {
  status: "ACTIVE",
  deletedAt: null,
} satisfies Prisma.ProductWhereInput;

const cardInclude = {
  category: { select: { name: true, slug: true } },
} satisfies Prisma.ProductInclude;

type ProductWithCard = Prisma.ProductGetPayload<{ include: typeof cardInclude }>;

function toCard(p: ProductWithCard): ProductCardDTO {
  return {
    id: p.id,
    slug: p.slug,
    title: p.title,
    price: Number(p.price),
    image: p.images[0] ?? null,
    stock: p.stock,
    categoryName: p.category.name,
  };
}

// ------------------------------------------------------------------ catálogo público

export async function listProducts(query: ProductQuery): Promise<Paginated<ProductCardDTO>> {
  const where: Prisma.ProductWhereInput = {
    ...PUBLIC_FILTER,
    ...(query.q ? { title: { contains: query.q, mode: "insensitive" } } : {}),
    ...(query.category ? { category: { slug: query.category } } : {}),
    ...(query.minPrice !== undefined || query.maxPrice !== undefined
      ? { price: { gte: query.minPrice, lte: query.maxPrice } }
      : {}),
  };

  const orderBy: Prisma.ProductOrderByWithRelationInput =
    query.sort === "price_asc"
      ? { price: "asc" }
      : query.sort === "price_desc"
        ? { price: "desc" }
        : { createdAt: "desc" };

  const [total, rows] = await prisma.$transaction([
    prisma.product.count({ where }),
    prisma.product.findMany({
      where,
      orderBy,
      include: cardInclude,
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
    }),
  ]);

  return {
    items: rows.map(toCard),
    total,
    page: query.page,
    pageSize: query.pageSize,
    totalPages: Math.max(1, Math.ceil(total / query.pageSize)),
  };
}

export async function getProductBySlug(slug: string): Promise<ProductDetailDTO | null> {
  const p = await prisma.product.findFirst({ where: { slug, ...PUBLIC_FILTER }, include: cardInclude });
  if (!p) return null;
  return {
    ...toCard(p),
    description: p.description,
    images: p.images,
    categorySlug: p.category.slug,
    weightGrams: p.weightGrams,
    lengthCm: p.lengthCm,
    widthCm: p.widthCm,
    heightCm: p.heightCm,
  };
}

export async function getPublicProductById(id: string): Promise<ProductDetailDTO | null> {
  const p = await prisma.product.findFirst({ where: { id, ...PUBLIC_FILTER }, select: { slug: true } });
  return p ? getProductBySlug(p.slug) : null;
}

export async function listRelatedProducts(categorySlug: string, excludeId: string): Promise<ProductCardDTO[]> {
  const rows = await prisma.product.findMany({
    where: { ...PUBLIC_FILTER, category: { slug: categorySlug }, id: { not: excludeId } },
    include: cardInclude,
    take: 4,
    orderBy: { createdAt: "desc" },
  });
  return rows.map(toCard);
}

/**
 * "public": só departamentos com produto à venda (menu, filtros, vitrine).
 * "all": todas as categorias (formulário de produto do painel).
 */
export async function listCategories(scope: "public" | "all" = "public") {
  return prisma.category.findMany({
    where: scope === "public" ? { products: { some: PUBLIC_FILTER } } : {},
    orderBy: { name: "asc" },
    select: { id: true, name: true, slug: true, icon: true },
  });
}

// ------------------------------------------------------------------ gestão (equipe da loja)

/** Lista do painel: inclui produtos pausados (os excluídos ficam só no histórico). */
export async function listManagedProducts(q?: string) {
  const rows = await prisma.product.findMany({
    where: { deletedAt: null, ...(q ? { title: { contains: q, mode: "insensitive" } } : {}) },
    include: { category: { select: { name: true } } },
    orderBy: { createdAt: "desc" },
    take: 500,
  });
  return rows.map((p) => ({
    id: p.id,
    slug: p.slug,
    title: p.title,
    price: Number(p.price),
    stock: p.stock,
    status: p.status,
    image: p.images[0] ?? null,
    categoryName: p.category.name,
  }));
}

export async function getProductForEdit(id: string) {
  const p = await prisma.product.findFirst({ where: { id, deletedAt: null } });
  if (!p) throw new NotFoundError("Produto");
  return { ...p, price: Number(p.price) };
}

export async function createProduct(input: z.infer<typeof productSchema>) {
  await assertCategory(input.categoryId);
  return prisma.product.create({
    data: { ...input, slug: uniqueSlug(input.title) },
    select: { id: true, slug: true },
  });
}

export async function updateProduct(id: string, input: z.infer<typeof productUpdateSchema>) {
  const product = await prisma.product.findFirst({ where: { id, deletedAt: null } });
  if (!product) throw new NotFoundError("Produto");
  if (input.categoryId) await assertCategory(input.categoryId);

  const updated = await prisma.product.update({
    where: { id },
    data: {
      ...input,
      ...(input.title && input.title !== product.title ? { slug: uniqueSlug(input.title) } : {}),
    },
    select: { id: true, slug: true },
  });
  // Produto pausado sai dos carrinhos
  if (input.status === "INACTIVE") await prisma.cartItem.deleteMany({ where: { productId: id } });
  return updated;
}

/** Pausa/reativa um produto direto da lista do painel. */
export async function setProductStatus(id: string, status: ProductStatus) {
  return updateProduct(id, { status });
}

/**
 * Exclusão lógica: o produto some do catálogo e dos carrinhos,
 * mas continua referenciado pelos pedidos já realizados.
 */
export async function deleteProduct(id: string): Promise<void> {
  const product = await prisma.product.findFirst({ where: { id, deletedAt: null } });
  if (!product) throw new NotFoundError("Produto");

  await prisma.$transaction([
    prisma.cartItem.deleteMany({ where: { productId: id } }),
    prisma.product.update({ where: { id }, data: { deletedAt: new Date(), status: "INACTIVE" } }),
  ]);
}

// ------------------------------------------------------------------ helpers

async function assertCategory(categoryId: string): Promise<void> {
  const exists = await prisma.category.count({ where: { id: categoryId } });
  if (!exists) throw new ValidationError("Categoria inválida", { categoryId: ["Categoria inválida"] });
}

function uniqueSlug(title: string): string {
  return `${slugify(title)}-${randomBytes(3).toString("hex")}`;
}
