import "server-only";
import { Prisma } from "@prisma/client";
import { prisma } from "@/infrastructure/db/prisma";

export interface DailySales {
  day: string;
  total: number;
}

const DAYS = 14;

function lastDays(rows: Array<{ day: Date; total: Prisma.Decimal | number | null }>): DailySales[] {
  const map = new Map(rows.map((r) => [r.day.toISOString().slice(0, 10), Number(r.total ?? 0)]));
  return Array.from({ length: DAYS }, (_, i) => {
    const d = new Date();
    d.setUTCHours(0, 0, 0, 0);
    d.setUTCDate(d.getUTCDate() - (DAYS - 1 - i));
    const key = d.toISOString().slice(0, 10);
    return { day: key, total: map.get(key) ?? 0 };
  });
}

/** Painel da loja: vendas aprovadas, pedidos, estoque e clientes. */
export async function storeDashboard() {
  const since = new Date(Date.now() - DAYS * 86_400_000);

  const [sold, units, ordersByStatus, toShip, productsCount, lowStock, customersCount, daily, topProducts, recentOrders] =
    await Promise.all([
      prisma.order.aggregate({ where: { status: "APPROVED" }, _sum: { total: true } }),
      prisma.orderItem.aggregate({ where: { order: { status: "APPROVED" } }, _sum: { quantity: true } }),
      prisma.order.groupBy({ by: ["status"], _count: { _all: true } }),
      prisma.shipment.count({ where: { status: { in: ["PENDING", "READY_TO_SHIP"] }, order: { status: "APPROVED" } } }),
      prisma.product.count({ where: { deletedAt: null } }),
      prisma.product.findMany({
        where: { deletedAt: null, stock: { lte: 5 } },
        select: { id: true, title: true, stock: true },
        orderBy: { stock: "asc" },
        take: 6,
      }),
      prisma.user.count({ where: { role: "BUYER" } }),
      prisma.$queryRaw<Array<{ day: Date; total: Prisma.Decimal | null }>>`
        SELECT date_trunc('day', "createdAt") AS day, SUM(total) AS total
        FROM "Order"
        WHERE status = 'APPROVED' AND "createdAt" >= ${since}
        GROUP BY 1 ORDER BY 1`,
      prisma.orderItem.groupBy({
        by: ["productId", "title"],
        where: { order: { status: "APPROVED" } },
        _sum: { quantity: true, subtotal: true },
        orderBy: { _sum: { quantity: "desc" } },
        take: 5,
      }),
      prisma.order.findMany({
        orderBy: { createdAt: "desc" },
        take: 8,
        include: { buyer: { select: { name: true } } },
      }),
    ]);

  const byStatus = (status: string) => ordersByStatus.find((r) => r.status === status)?._count._all ?? 0;

  return {
    totalSold: Number(sold._sum.total ?? 0),
    unitsSold: units._sum.quantity ?? 0,
    totalOrders: ordersByStatus.reduce((s, r) => s + r._count._all, 0),
    ordersByStatus: {
      PENDING: byStatus("PENDING"),
      APPROVED: byStatus("APPROVED"),
      CANCELLED: byStatus("CANCELLED"),
      REFUNDED: byStatus("REFUNDED"),
    },
    toShip,
    productsCount,
    lowStock,
    customersCount,
    daily: lastDays(daily),
    topProducts: topProducts.map((t) => ({
      productId: t.productId,
      title: t.title,
      quantity: t._sum.quantity ?? 0,
      revenue: Number(t._sum.subtotal ?? 0),
    })),
    recentOrders: recentOrders.map((o) => ({
      id: o.id,
      buyerName: o.buyer.name,
      total: Number(o.total),
      status: o.status,
      createdAt: o.createdAt,
    })),
  };
}
