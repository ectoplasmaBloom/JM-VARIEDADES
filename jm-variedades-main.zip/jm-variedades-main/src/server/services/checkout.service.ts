import "server-only";
import type { Prisma } from "@prisma/client";
import { NotFoundError, OutOfStockError, ValidationError } from "@/domain/errors";
import { prisma } from "@/infrastructure/db/prisma";
import { paymentGateway } from "@/infrastructure/payment";
import { fromCents, toCents } from "@/lib/utils";
import type { SessionUser } from "@/server/session";
import { getCart } from "./cart.service";
import { quoteCart } from "./shipping.service";

export interface CheckoutResult {
  orderId: string;
  paymentUrl: string;
}

/**
 * Caso de uso: finalizar compra.
 *  1. Valida carrinho e estoque (não permite compra sem estoque)
 *  2. Valida endereço do comprador
 *  3. Recalcula o frete no servidor (obrigatório; nunca confia no valor do cliente)
 *  4. Cria pedido PENDENTE com itens (snapshot), o envio da loja e histórico
 *  5. Cria a preferência no Mercado Pago e devolve a URL de pagamento
 *  6. Esvazia o carrinho
 * O estoque só é baixado quando o pagamento é aprovado (ver payment.service).
 */
export async function checkout(
  user: SessionUser,
  input: { addressId: string; serviceCode: string },
): Promise<CheckoutResult> {
  const cart = await getCart(user.id);
  if (cart.items.length === 0) throw new ValidationError("Seu carrinho está vazio");

  const problem = cart.items.find((i) => i.problem);
  if (problem) {
    if (problem.problem === "Produto indisponível") {
      throw new ValidationError(`"${problem.title}" não está mais disponível. Remova-o do carrinho.`);
    }
    throw new OutOfStockError(problem.title, problem.stock);
  }

  const address = await prisma.address.findFirst({ where: { id: input.addressId, userId: user.id } });
  if (!address) throw new NotFoundError("Endereço");

  const options = await quoteCart(user.id, address.cep);
  const shipping = options.find((o) => o.serviceCode === input.serviceCode);
  if (!shipping) throw new ValidationError("Opção de frete inválida. Recalcule o frete.");

  const subtotalCents = toCents(cart.subtotal);
  const shippingCents = toCents(shipping.price);

  const shippingAddress = {
    recipient: address.recipient,
    cep: address.cep,
    street: address.street,
    number: address.number,
    complement: address.complement,
    district: address.district,
    city: address.city,
    state: address.state,
  } satisfies Prisma.InputJsonObject;

  const order = await prisma.order.create({
    data: {
      buyerId: user.id,
      addressId: address.id,
      status: "PENDING",
      subtotal: fromCents(subtotalCents),
      shippingTotal: fromCents(shippingCents),
      total: fromCents(subtotalCents + shippingCents),
      shippingService: shipping.service,
      shippingAddress,
      items: {
        create: cart.items.map((item) => ({
          productId: item.productId,
          title: item.title,
          imageUrl: item.image,
          unitPrice: item.unitPrice,
          quantity: item.quantity,
          subtotal: item.subtotal,
        })),
      },
      shipments: {
        create: {
          service: shipping.service,
          serviceCode: shipping.serviceCode,
          originCep: shipping.originCep,
          destinationCep: address.cep,
          price: shipping.price,
          deadlineDays: shipping.deadlineDays,
          weightGrams: shipping.weightGrams,
        },
      },
      statusHistory: { create: { toStatus: "PENDING", reason: "Pedido criado" } },
    },
  });

  try {
    const session = await paymentGateway().createCheckout({
      orderId: order.id,
      items: cart.items.map((i) => ({
        id: i.productId,
        title: i.title,
        quantity: i.quantity,
        unitPrice: i.unitPrice,
        pictureUrl: i.image?.startsWith("https://") ? i.image : undefined,
      })),
      shippingCost: fromCents(shippingCents),
      payer: { name: user.name, email: user.email },
    });

    await prisma.$transaction([
      prisma.order.update({
        where: { id: order.id },
        data: { mpPreferenceId: session.preferenceId, paymentUrl: session.paymentUrl },
      }),
      prisma.cartItem.deleteMany({ where: { cart: { userId: user.id } } }),
    ]);

    return { orderId: order.id, paymentUrl: session.paymentUrl };
  } catch (error) {
    // Falha no gateway: cancela o pedido e mantém o carrinho para nova tentativa.
    await prisma.order.update({
      where: { id: order.id },
      data: {
        status: "CANCELLED",
        statusHistory: {
          create: { fromStatus: "PENDING", toStatus: "CANCELLED", reason: "Falha ao gerar pagamento" },
        },
      },
    });
    throw error;
  }
}
