import "server-only";
import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { ZodError, type ZodType, type ZodTypeDef } from "zod";
import { DomainError, ValidationError } from "@/domain/errors";

/**
 * Helpers das rotas REST: respostas padronizadas e tradução de erros.
 * Formato de erro: { error: { code, message, fields? } }
 */

export function ok<T>(data: T, status = 200): NextResponse {
  return NextResponse.json({ data }, { status });
}

export async function parseBody<T>(req: Request, schema: ZodType<T, ZodTypeDef, unknown>): Promise<T> {
  let json: unknown;
  try {
    json = await req.json();
  } catch {
    throw new ValidationError("Corpo da requisição inválido (JSON esperado)");
  }
  return parse(schema, json);
}

export function parseQuery<T>(req: Request, schema: ZodType<T, ZodTypeDef, unknown>): T {
  const params = Object.fromEntries(new URL(req.url).searchParams);
  return parse(schema, params);
}

export function parse<T>(schema: ZodType<T, ZodTypeDef, unknown>, input: unknown): T {
  const result = schema.safeParse(input);
  if (!result.success) {
    const flat = result.error.flatten();
    const first = flat.formErrors[0] ?? Object.values(flat.fieldErrors).flat()[0] ?? "Dados inválidos";
    throw new ValidationError(String(first), flat.fieldErrors as Record<string, string[] | undefined>);
  }
  return result.data;
}

type Handler<C> = (req: Request, ctx: C) => Promise<Response>;

/** Envolve um handler traduzindo exceções em respostas HTTP. */
export function route<C = unknown>(handler: Handler<C>): Handler<C> {
  return async (req, ctx) => {
    try {
      return await handler(req, ctx);
    } catch (error) {
      return toErrorResponse(error);
    }
  };
}

export function toErrorResponse(error: unknown): NextResponse {
  if (error instanceof DomainError) {
    return NextResponse.json(
      {
        error: {
          code: error.code,
          message: error.message,
          ...(error instanceof ValidationError && error.fields ? { fields: error.fields } : {}),
        },
      },
      { status: error.status },
    );
  }
  if (error instanceof ZodError) {
    return NextResponse.json(
      { error: { code: "VALIDATION_ERROR", message: error.issues[0]?.message ?? "Dados inválidos" } },
      { status: 422 },
    );
  }
  if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2025") {
    return NextResponse.json({ error: { code: "NOT_FOUND", message: "Registro não encontrado" } }, { status: 404 });
  }
  console.error("[api] erro inesperado", error);
  return NextResponse.json(
    { error: { code: "INTERNAL_ERROR", message: "Erro interno do servidor" } },
    { status: 500 },
  );
}
