import "server-only";
import { PrismaClient } from "@prisma/client";

/**
 * Singleton do Prisma Client. Em desenvolvimento o hot reload recria módulos,
 * então o client é guardado em globalThis para não esgotar conexões.
 * O Prisma usa queries parametrizadas, o que previne SQL Injection.
 */
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
