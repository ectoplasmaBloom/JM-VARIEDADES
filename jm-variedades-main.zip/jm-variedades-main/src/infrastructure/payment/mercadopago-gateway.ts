import "server-only";
import { MercadoPagoConfig, Payment, PaymentRefund, Preference } from "mercadopago";
import {
  mapGatewayStatus,
  type CheckoutSession,
  type CreateCheckoutInput,
  type GatewayPayment,
  type PaymentGateway,
} from "@/domain/payment";
import { ExternalServiceError } from "@/domain/errors";
import { env } from "@/lib/env";

/**
 * Adapter do Mercado Pago (Checkout Pro).
 * Docs: https://www.mercadopago.com.br/developers/pt/docs/checkout-pro/landing
 */
export class MercadoPagoGateway implements PaymentGateway {
  private readonly client: MercadoPagoConfig;

  constructor(accessToken: string) {
    if (!accessToken) {
      throw new ExternalServiceError("MP_ACCESS_TOKEN não configurado");
    }
    this.client = new MercadoPagoConfig({ accessToken, options: { timeout: 10_000 } });
  }

  async createCheckout(input: CreateCheckoutInput): Promise<CheckoutSession> {
    const { APP_URL, MP_NOTIFICATION_BASE_URL, MP_ACCESS_TOKEN } = env();
    const notificationBase = MP_NOTIFICATION_BASE_URL || APP_URL;
    const resultUrl = `${APP_URL}/checkout/result?order=${input.orderId}`;
    const isHttps = APP_URL.startsWith("https://");

    try {
      const preference = await new Preference(this.client).create({
        body: {
          external_reference: input.orderId,
          items: input.items.map((item) => ({
            id: item.id,
            title: item.title.slice(0, 250),
            quantity: item.quantity,
            unit_price: item.unitPrice,
            currency_id: "BRL",
            picture_url: item.pictureUrl,
          })),
          // O frete dos Correios é cobrado junto, como custo de envio.
          shipments: { mode: "not_specified", cost: input.shippingCost },
          payer: { name: input.payer.name, email: input.payer.email },
          back_urls: {
            success: `${resultUrl}&status=success`,
            pending: `${resultUrl}&status=pending`,
            failure: `${resultUrl}&status=failure`,
          },
          // auto_return exige back_url pública (https); em localhost o comprador clica em "voltar".
          ...(isHttps ? { auto_return: "approved" as const } : {}),
          // Notificações só chegam a URLs públicas (use um túnel em dev).
          ...(notificationBase.startsWith("https://")
            ? { notification_url: `${notificationBase}/api/webhooks/mercadopago?source_news=webhooks` }
            : {}),
          statement_descriptor: "MARKETPLACE",
          metadata: { order_id: input.orderId },
        },
        requestOptions: { idempotencyKey: `pref-${input.orderId}` },
      });

      const isTest = MP_ACCESS_TOKEN.startsWith("TEST-");
      const paymentUrl = isTest
        ? (preference.sandbox_init_point ?? preference.init_point)
        : preference.init_point;

      if (!preference.id || !paymentUrl) {
        throw new Error("Resposta sem id/init_point");
      }
      return { preferenceId: preference.id, paymentUrl };
    } catch (error) {
      throw new ExternalServiceError(`Falha ao criar preferência no Mercado Pago: ${describe(error)}`);
    }
  }

  async getPayment(externalId: string): Promise<GatewayPayment> {
    try {
      const p = await new Payment(this.client).get({ id: externalId });
      return {
        externalId: String(p.id),
        orderId: p.external_reference ?? null,
        status: mapGatewayStatus(p.status),
        statusDetail: p.status_detail ?? null,
        paymentMethod: p.payment_method_id ?? null,
        paymentType: p.payment_type_id ?? null,
        amount: Number(p.transaction_amount ?? 0),
        approvedAt: p.date_approved ? new Date(p.date_approved) : null,
        raw: p,
      };
    } catch (error) {
      throw new ExternalServiceError(`Falha ao consultar pagamento ${externalId}: ${describe(error)}`);
    }
  }

  async refund(externalId: string): Promise<void> {
    try {
      await new PaymentRefund(this.client).create({
        payment_id: externalId,
        requestOptions: { idempotencyKey: `refund-${externalId}` },
      });
    } catch (error) {
      throw new ExternalServiceError(`Falha ao estornar pagamento ${externalId}: ${describe(error)}`);
    }
  }
}

function describe(error: unknown): string {
  if (error instanceof Error) return error.message;
  if (typeof error === "object" && error && "message" in error) return String(error.message);
  return "erro desconhecido";
}
