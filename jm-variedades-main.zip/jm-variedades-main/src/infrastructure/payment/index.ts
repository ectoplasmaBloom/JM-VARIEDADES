import "server-only";
import type { PaymentGateway } from "@/domain/payment";
import { env } from "@/lib/env";
import { MercadoPagoGateway } from "./mercadopago-gateway";
import { MockPaymentGateway } from "./mock-gateway";

let instance: PaymentGateway | undefined;

/** Factory: escolhe o gateway pela variável PAYMENT_PROVIDER (mercadopago | mock). */
export function paymentGateway(): PaymentGateway {
  instance ??= env().PAYMENT_PROVIDER === "mock" ? new MockPaymentGateway() : new MercadoPagoGateway(env().MP_ACCESS_TOKEN);
  return instance;
}

export function isMockPayment(): boolean {
  return env().PAYMENT_PROVIDER === "mock";
}
