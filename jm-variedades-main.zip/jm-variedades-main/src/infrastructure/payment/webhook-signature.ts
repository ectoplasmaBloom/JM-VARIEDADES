import "server-only";
import { createHmac, timingSafeEqual } from "node:crypto";

/**
 * Valida o header x-signature enviado pelo Mercado Pago.
 * Formato: "ts=1704908010,v1=618c85345248dd820d5fd456117c2ab2ef8eda45a0282ff693eac24131a5e839"
 * Manifesto assinado: "id:{data.id};request-id:{x-request-id};ts:{ts};"
 * Docs: https://www.mercadopago.com.br/developers/pt/docs/your-integrations/notifications/webhooks
 */
export function verifyMercadoPagoSignature(params: {
  secret: string;
  signatureHeader: string | null;
  requestId: string | null;
  dataId: string | null;
  /** Tolerância de replay em segundos (0 = desativado) */
  maxAgeSeconds?: number;
}): boolean {
  const { secret, signatureHeader, requestId, dataId, maxAgeSeconds = 0 } = params;
  if (!signatureHeader) return false;

  const parts = Object.fromEntries(
    signatureHeader.split(",").map((part) => {
      const [key, ...rest] = part.trim().split("=");
      return [key, rest.join("=")];
    }),
  ) as Record<string, string | undefined>;

  const ts = parts.ts;
  const v1 = parts.v1;
  if (!ts || !v1) return false;

  if (maxAgeSeconds > 0) {
    const tsSeconds = ts.length > 10 ? Number(ts) / 1000 : Number(ts);
    if (Math.abs(Date.now() / 1000 - tsSeconds) > maxAgeSeconds) return false;
  }

  let manifest = "";
  if (dataId) manifest += `id:${/^[a-z0-9]+$/i.test(dataId) ? dataId.toLowerCase() : dataId};`;
  if (requestId) manifest += `request-id:${requestId};`;
  manifest += `ts:${ts};`;

  const expected = createHmac("sha256", secret).update(manifest).digest("hex");
  const a = Buffer.from(expected, "hex");
  const b = Buffer.from(v1, "hex");
  return a.length === b.length && timingSafeEqual(a, b);
}
