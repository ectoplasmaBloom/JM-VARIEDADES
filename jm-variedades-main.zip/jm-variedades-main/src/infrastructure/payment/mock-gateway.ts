import "server-only";
import type { PaymentStatus } from "@prisma/client";
import type {
  CheckoutSession,
  CreateCheckoutInput,
  GatewayPayment,
  PaymentGateway,
} from "@/domain/payment";
import { NotFoundError } from "@/domain/errors";
import { prisma } from "@/infrastructure/db/prisma";
import { env } from "@/lib/env";

/**
 * Gateway de pagamento SIMULADO para o MVP / apresentação acadêmica
 * (PAYMENT_PROVIDER=mock). Tem a mesma interface do Mercado Pago: o checkout
 * leva a uma página local (/checkout/mock) onde o comprador escolhe aprovar
 * ou recusar, e o resultado passa pelo mesmo caso de uso do webhook real
 * (processPaymentNotification) — estoque, cancelamento e estorno inclusos.
 */
interface SimulatedPayment {
  orderId: string;
  status: PaymentStatus;
  amount: number;
}

const globalStore = globalThis as unknown as { mockPayments?: Map<string, SimulatedPayment> };
const payments = (globalStore.mockPayments ??= new Map<string, SimulatedPayment>());

export class MockPaymentGateway implements PaymentGateway {
  async createCheckout(input: CreateCheckoutInput): Promise<CheckoutSession> {
    return {
      preferenceId: `mock-${input.orderId}`,
      paymentUrl: `${env().APP_URL}/checkout/mock?order=${input.orderId}`,
    };
  }

  /** Registra um pagamento simulado e devolve o id (numérico, como no MP). */
  async simulate(orderId: string, outcome: "approved" | "rejected" | "pending"): Promise<string> {
    const order = await prisma.order.findUnique({ where: { id: orderId }, select: { total: true } });
    if (!order) throw new NotFoundError("Pedido");
    const externalId = `${Date.now()}${Math.floor(Math.random() * 1000)}`;
    const status: PaymentStatus =
      outcome === "approved" ? "APPROVED" : outcome === "rejected" ? "REJECTED" : "IN_PROCESS";
    payments.set(externalId, { orderId, status, amount: Number(order.total) });
    return externalId;
  }

  async getPayment(externalId: string): Promise<GatewayPayment> {
    const simulated = payments.get(externalId) ?? (await this.fromDatabase(externalId));
    return {
      externalId,
      orderId: simulated.orderId,
      status: simulated.status,
      statusDetail: `simulado_${simulated.status.toLowerCase()}`,
      paymentMethod: "simulado",
      paymentType: "mock",
      amount: simulated.amount,
      approvedAt: simulated.status === "APPROVED" ? new Date() : null,
      raw: { simulated: true, externalId, ...simulated },
    };
  }

  async refund(externalId: string): Promise<void> {
    const simulated = payments.get(externalId) ?? (await this.fromDatabase(externalId));
    payments.set(externalId, { ...simulated, status: "REFUNDED" });
  }

  /** Após reiniciar o servidor a memória se perde: reconstrói a partir do banco. */
  private async fromDatabase(externalId: string): Promise<SimulatedPayment> {
    const saved = await prisma.payment.findUnique({ where: { externalId } });
    if (!saved) throw new NotFoundError("Pagamento simulado");
    const simulated = { orderId: saved.orderId, status: saved.status, amount: Number(saved.amount) };
    payments.set(externalId, simulated);
    return simulated;
  }
}
