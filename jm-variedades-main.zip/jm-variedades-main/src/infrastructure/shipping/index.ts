import "server-only";
import type { ShippingProvider } from "@/domain/shipping";
import { env } from "@/lib/env";
import { CorreiosShippingProvider } from "./correios-provider";
import { MockShippingProvider } from "./mock-provider";

let instance: ShippingProvider | undefined;

/** Factory: escolhe a implementação de frete pela variável SHIPPING_PROVIDER. */
export function shippingProvider(): ShippingProvider {
  if (instance) return instance;
  const e = env();

  instance =
    e.SHIPPING_PROVIDER === "correios"
      ? new CorreiosShippingProvider({
          baseUrl: e.CORREIOS_API_URL,
          user: e.CORREIOS_USER,
          accessCode: e.CORREIOS_ACCESS_CODE,
          postcard: e.CORREIOS_POSTCARD,
          services: e.CORREIOS_SERVICES.split(",").map((pair) => {
            const [code = "", name = code] = pair.split(":").map((s) => s.trim());
            return [code, name];
          }),
        })
      : new MockShippingProvider();

  return instance;
}
