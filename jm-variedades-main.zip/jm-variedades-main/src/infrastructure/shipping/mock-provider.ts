import type { ShippingOption, ShippingProvider, ShippingQuoteRequest } from "@/domain/shipping";

/**
 * Simulador de frete para desenvolvimento e para a apresentação acadêmica,
 * já que a API oficial dos Correios exige contrato.
 * Usa a "distância" entre as regiões do CEP (1º dígito) e o peso cubado.
 * Mesma interface do provider real: basta trocar SHIPPING_PROVIDER.
 */
export class MockShippingProvider implements ShippingProvider {
  readonly name = "mock";

  async quote({ originCep, destinationCep, pkg }: ShippingQuoteRequest): Promise<ShippingOption[]> {
    const regionDistance = Math.abs(Number(originCep[0]) - Number(destinationCep[0]));
    const sameCity = originCep.slice(0, 3) === destinationCep.slice(0, 3);

    // Peso cubado dos Correios: (C x L x A) / 6000, em kg
    const cubicKg = (pkg.lengthCm * pkg.widthCm * pkg.heightCm) / 6000;
    const billableKg = Math.max(pkg.weightGrams / 1000, cubicKg);

    const pacBase = 18.9 + regionDistance * 4.2 + billableKg * 3.1;
    const pacDays = (sameCity ? 2 : 4) + regionDistance;

    return [
      { serviceCode: "03298", service: "PAC", price: round(pacBase), deadlineDays: pacDays },
      {
        serviceCode: "03220",
        service: "SEDEX",
        price: round(pacBase * 1.75),
        deadlineDays: Math.max(1, Math.ceil(pacDays / 2.5)),
      },
    ];
  }
}

function round(value: number): number {
  return Math.round(value * 100) / 100;
}
