import "server-only";
import type { ShippingOption, ShippingProvider, ShippingQuoteRequest } from "@/domain/shipping";
import { ExternalServiceError } from "@/domain/errors";

/**
 * Adapter da API REST oficial dos Correios (CWS).
 * Requer contrato + credenciais do portal Meu Correios (código de acesso à API).
 *
 *  1. POST /token/v1/autentica/cartaopostagem  (Basic usuario:codigoAcesso, body { numero })
 *  2. GET  /preco/v1/nacional/{coProduto}?cepOrigem&cepDestino&psObjeto&tpObjeto&comprimento&largura&altura
 *  3. GET  /prazo/v1/nacional/{coProduto}?cepOrigem&cepDestino
 *
 * Docs: https://cws.correios.com.br (Swagger: token, preco, prazo)
 */

export interface CorreiosConfig {
  baseUrl: string;
  user: string;
  accessCode: string;
  postcard: string;
  /** Pares código -> nome, ex.: [["03298","PAC"],["03220","SEDEX"]] */
  services: Array<[code: string, name: string]>;
}

interface TokenResponse {
  token: string;
  expiraEm: string;
}

interface PriceResponse {
  coProduto: string;
  pcFinal?: string;
  txErro?: string;
}

interface DeadlineResponse {
  coProduto: string;
  prazoEntrega?: number;
  txErro?: string;
}

const REQUEST_TIMEOUT_MS = 8_000;

export class CorreiosShippingProvider implements ShippingProvider {
  readonly name = "correios";
  private token: { value: string; expiresAt: number } | null = null;

  constructor(private readonly config: CorreiosConfig) {
    if (!config.user || !config.accessCode || !config.postcard) {
      throw new ExternalServiceError(
        "Credenciais dos Correios ausentes (CORREIOS_USER, CORREIOS_ACCESS_CODE, CORREIOS_POSTCARD)",
      );
    }
  }

  async quote(request: ShippingQuoteRequest): Promise<ShippingOption[]> {
    const token = await this.getToken();
    const results = await Promise.allSettled(
      this.config.services.map(([code, name]) => this.quoteService(token, code, name, request)),
    );

    const options = results
      .filter((r): r is PromiseFulfilledResult<ShippingOption> => r.status === "fulfilled")
      .map((r) => r.value);

    if (options.length === 0) {
      const reason = results.find((r) => r.status === "rejected") as PromiseRejectedResult | undefined;
      throw new ExternalServiceError(
        `Correios não retornou opções de frete: ${reason ? String(reason.reason) : "sem serviços"}`,
      );
    }
    return options.sort((a, b) => a.price - b.price);
  }

  private async quoteService(
    token: string,
    code: string,
    name: string,
    { originCep, destinationCep, pkg }: ShippingQuoteRequest,
  ): Promise<ShippingOption> {
    const priceQuery = new URLSearchParams({
      cepOrigem: originCep,
      cepDestino: destinationCep,
      psObjeto: String(pkg.weightGrams),
      tpObjeto: "2", // 2 = pacote/caixa
      comprimento: String(pkg.lengthCm),
      largura: String(pkg.widthCm),
      altura: String(pkg.heightCm),
    });
    const deadlineQuery = new URLSearchParams({ cepOrigem: originCep, cepDestino: destinationCep });

    const [price, deadline] = await Promise.all([
      this.get<PriceResponse>(`/preco/v1/nacional/${code}?${priceQuery}`, token),
      this.get<DeadlineResponse>(`/prazo/v1/nacional/${code}?${deadlineQuery}`, token),
    ]);

    if (price.txErro || !price.pcFinal) throw new Error(price.txErro ?? "Preço indisponível");
    if (deadline.txErro || deadline.prazoEntrega === undefined) {
      throw new Error(deadline.txErro ?? "Prazo indisponível");
    }

    return {
      serviceCode: code,
      service: name,
      // A API devolve valores no formato brasileiro: "1.234,56"
      price: Number(price.pcFinal.replace(/\./g, "").replace(",", ".")),
      deadlineDays: deadline.prazoEntrega,
    };
  }

  private async getToken(): Promise<string> {
    if (this.token && this.token.expiresAt > Date.now() + 60_000) return this.token.value;

    const basic = Buffer.from(`${this.config.user}:${this.config.accessCode}`).toString("base64");
    const res = await fetch(`${this.config.baseUrl}/token/v1/autentica/cartaopostagem`, {
      method: "POST",
      headers: { Authorization: `Basic ${basic}`, "Content-Type": "application/json" },
      body: JSON.stringify({ numero: this.config.postcard }),
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      cache: "no-store",
    });
    if (!res.ok) {
      throw new ExternalServiceError(`Falha na autenticação dos Correios (HTTP ${res.status})`);
    }
    const data = (await res.json()) as TokenResponse;
    this.token = { value: data.token, expiresAt: new Date(data.expiraEm).getTime() };
    return data.token;
  }

  private async get<T>(path: string, token: string): Promise<T> {
    const res = await fetch(`${this.config.baseUrl}${path}`, {
      headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      cache: "no-store",
    });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new Error(`HTTP ${res.status} em ${path.split("?")[0]}: ${body.slice(0, 200)}`);
    }
    return (await res.json()) as T;
  }
}
