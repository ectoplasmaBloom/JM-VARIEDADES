import "server-only";
import { randomUUID } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { put } from "@vercel/blob";
import { env } from "@/lib/env";

export interface FileStorage {
  save(file: File, folder: string): Promise<string>;
}

const EXTENSIONS: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
};

/** Produção (Vercel): armazena no Vercel Blob e retorna a URL pública. */
class VercelBlobStorage implements FileStorage {
  constructor(private readonly token: string) {}

  async save(file: File, folder: string): Promise<string> {
    const ext = EXTENSIONS[file.type] ?? "bin";
    const blob = await put(`${folder}/${randomUUID()}.${ext}`, file, {
      access: "public",
      token: this.token,
      contentType: file.type,
    });
    return blob.url;
  }
}

/** Pasta dos uploads locais, servida pela rota /uploads/[...path] (funciona em dev e em next start). */
export const LOCAL_UPLOAD_DIR = path.join(process.cwd(), ".uploads");

/** Desenvolvimento/MVP local: grava em disco (o filesystem da Vercel é somente leitura). */
class LocalDiskStorage implements FileStorage {
  async save(file: File, folder: string): Promise<string> {
    const ext = EXTENSIONS[file.type] ?? "bin";
    const dir = path.join(LOCAL_UPLOAD_DIR, folder);
    await mkdir(dir, { recursive: true });
    const name = `${randomUUID()}.${ext}`;
    await writeFile(path.join(dir, name), Buffer.from(await file.arrayBuffer()));
    return `/uploads/${folder}/${name}`;
  }
}

export function fileStorage(): FileStorage {
  const token = env().BLOB_READ_WRITE_TOKEN;
  return token ? new VercelBlobStorage(token) : new LocalDiskStorage();
}

export const ALLOWED_IMAGE_TYPES = Object.keys(EXTENSIONS);

/**
 * Confere a assinatura binária (magic bytes) em vez de confiar no
 * Content-Type enviado pelo navegador, que pode ser forjado.
 */
export async function sniffImageType(file: File): Promise<string | null> {
  const b = new Uint8Array(await file.slice(0, 12).arrayBuffer());
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return "image/png";
  const ascii = String.fromCharCode(...b);
  if (ascii.startsWith("RIFF") && ascii.slice(8, 12) === "WEBP") return "image/webp";
  return null;
}
export const MAX_IMAGE_BYTES = 4 * 1024 * 1024;
