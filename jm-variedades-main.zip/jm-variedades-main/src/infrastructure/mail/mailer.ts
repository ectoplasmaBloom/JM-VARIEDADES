import "server-only";
import nodemailer from "nodemailer";
import { env } from "@/lib/env";

export interface MailMessage {
  to: string;
  subject: string;
  html: string;
  text: string;
}

/** Envia e-mail via SMTP. Sem SMTP_HOST configurado, apenas registra no console (dev). */
export async function sendMail(message: MailMessage): Promise<void> {
  const e = env();
  if (!e.SMTP_HOST) {
    console.info(`\n[mail] Para: ${message.to}\n[mail] Assunto: ${message.subject}\n${message.text}\n`);
    return;
  }

  const transport = nodemailer.createTransport({
    host: e.SMTP_HOST,
    port: e.SMTP_PORT,
    secure: e.SMTP_PORT === 465,
    auth: e.SMTP_USER ? { user: e.SMTP_USER, pass: e.SMTP_PASS } : undefined,
  });
  await transport.sendMail({ from: e.MAIL_FROM, ...message });
}
