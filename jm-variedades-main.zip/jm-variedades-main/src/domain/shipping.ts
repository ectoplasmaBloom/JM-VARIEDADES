/**
 * Contratos de frete (porta da Clean Architecture).
 * As implementações (Correios, mock) ficam em src/infrastructure/shipping.
 */

export interface ShippingPackage {
  weightGrams: number;
  lengthCm: number;
  widthCm: number;
  heightCm: number;
  /** Valor declarado em reais (opcional) */
  declaredValue?: number;
}

export interface ShippingQuoteRequest {
  originCep: string;
  destinationCep: string;
  pkg: ShippingPackage;
}

export interface ShippingOption {
  serviceCode: string;
  service: string;
  price: number;
  deadlineDays: number;
}

export interface ShippingProvider {
  readonly name: string;
  quote(request: ShippingQuoteRequest): Promise<ShippingOption[]>;
}

export interface PackageItem {
  weightGrams: number;
  lengthCm: number;
  widthCm: number;
  heightCm: number;
  quantity: number;
}

/** Limites mínimos/máximos aceitos pelos Correios para caixa/pacote. */
export const CORREIOS_LIMITS = {
  minLength: 15,
  minWidth: 10,
  minHeight: 1,
  maxSide: 100,
  maxSum: 200,
  minWeight: 300,
  maxWeight: 30000,
} as const;

/**
 * Consolida vários itens em um único volume:
 * peso somado, maior comprimento/largura e alturas empilhadas.
 */
export function buildPackage(items: PackageItem[]): ShippingPackage {
  let weight = 0;
  let length = 0;
  let width = 0;
  let height = 0;

  for (const item of items) {
    weight += item.weightGrams * item.quantity;
    length = Math.max(length, item.lengthCm);
    width = Math.max(width, item.widthCm);
    height += item.heightCm * item.quantity;
  }

  return {
    weightGrams: clamp(weight, CORREIOS_LIMITS.minWeight, CORREIOS_LIMITS.maxWeight),
    lengthCm: clamp(length, CORREIOS_LIMITS.minLength, CORREIOS_LIMITS.maxSide),
    widthCm: clamp(width, CORREIOS_LIMITS.minWidth, CORREIOS_LIMITS.maxSide),
    heightCm: clamp(height, CORREIOS_LIMITS.minHeight, CORREIOS_LIMITS.maxSide),
  };
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(Math.ceil(value), min), max);
}
