import type { OrderStatus, PaymentStatus } from "@prisma/client";

/**
 * Contrato do gateway de pagamento (porta).
 * Implementação: src/infrastructure/payment/mercadopago-gateway.ts
 */

export interface CheckoutItem {
  id: string;
  title: string;
  quantity: number;
  unitPrice: number;
  pictureUrl?: string;
}

export interface CreateCheckoutInput {
  orderId: string;
  items: CheckoutItem[];
  shippingCost: number;
  payer: { name: string; email: string };
}

export interface CheckoutSession {
  preferenceId: string;
  paymentUrl: string;
}

export interface GatewayPayment {
  externalId: string;
  orderId: string | null;
  status: PaymentStatus;
  statusDetail: string | null;
  paymentMethod: string | null;
  paymentType: string | null;
  amount: number;
  approvedAt: Date | null;
  raw: unknown;
}

export interface PaymentGateway {
  createCheckout(input: CreateCheckoutInput): Promise<CheckoutSession>;
  getPayment(externalId: string): Promise<GatewayPayment>;
  refund(externalId: string): Promise<void>;
}

/** Converte o status textual do Mercado Pago para o enum interno. */
export function mapGatewayStatus(status: string | undefined | null): PaymentStatus {
  switch (status) {
    case "approved":
      return "APPROVED";
    case "authorized":
      return "AUTHORIZED";
    case "in_process":
      return "IN_PROCESS";
    case "in_mediation":
      return "IN_MEDIATION";
    case "rejected":
      return "REJECTED";
    case "cancelled":
      return "CANCELLED";
    case "refunded":
      return "REFUNDED";
    case "charged_back":
      return "CHARGED_BACK";
    default:
      return "PENDING";
  }
}

/**
 * Regra de negócio: qual status do pedido corresponde a um status de pagamento.
 * - aprovado              -> APPROVED
 * - recusado / cancelado  -> CANCELLED (cancelamento automático)
 * - estornado / chargeback-> REFUNDED
 * - demais                -> PENDING
 */
export function orderStatusFromPayment(status: PaymentStatus): OrderStatus {
  switch (status) {
    case "APPROVED":
      return "APPROVED";
    case "REJECTED":
    case "CANCELLED":
      return "CANCELLED";
    case "REFUNDED":
    case "CHARGED_BACK":
      return "REFUNDED";
    default:
      return "PENDING";
  }
}

/** Transições permitidas da máquina de estados do pedido. */
const TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  PENDING: ["APPROVED", "CANCELLED"],
  APPROVED: ["REFUNDED"],
  CANCELLED: ["APPROVED"], // pagamento aprovado após cancelamento (ex.: retentativa no MP)
  REFUNDED: [],
};

export function canTransition(from: OrderStatus, to: OrderStatus): boolean {
  return from === to || TRANSITIONS[from].includes(to);
}

export const ORDER_STATUS_LABEL: Record<OrderStatus, string> = {
  PENDING: "Pendente",
  APPROVED: "Aprovado",
  CANCELLED: "Cancelado",
  REFUNDED: "Reembolsado",
};
