/**
 * Erros de domínio. A camada HTTP traduz cada um para um status code,
 * mantendo as regras de negócio independentes de framework.
 */
export abstract class DomainError extends Error {
  abstract readonly status: number;
  abstract readonly code: string;

  constructor(message: string) {
    super(message);
    this.name = new.target.name;
  }
}

export class ValidationError extends DomainError {
  readonly status = 422;
  readonly code = "VALIDATION_ERROR";

  constructor(
    message: string,
    readonly fields?: Record<string, string[] | undefined>,
  ) {
    super(message);
  }
}

export class UnauthorizedError extends DomainError {
  readonly status = 401;
  readonly code = "UNAUTHORIZED";
  constructor(message = "Autenticação necessária") {
    super(message);
  }
}

export class ForbiddenError extends DomainError {
  readonly status = 403;
  readonly code = "FORBIDDEN";
  constructor(message = "Você não tem permissão para esta ação") {
    super(message);
  }
}

export class NotFoundError extends DomainError {
  readonly status = 404;
  readonly code = "NOT_FOUND";
  constructor(entity = "Recurso") {
    super(`${entity} não encontrado`);
  }
}

export class ConflictError extends DomainError {
  readonly status = 409;
  readonly code = "CONFLICT";
}

export class OutOfStockError extends DomainError {
  readonly status = 409;
  readonly code = "OUT_OF_STOCK";
  constructor(productTitle: string, available: number) {
    super(
      available > 0
        ? `Estoque insuficiente para "${productTitle}" (disponível: ${available})`
        : `"${productTitle}" está sem estoque`,
    );
  }
}

export class ExternalServiceError extends DomainError {
  readonly status = 502;
  readonly code = "EXTERNAL_SERVICE_ERROR";
}
