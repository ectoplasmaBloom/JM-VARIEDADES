// Teste ponta a ponta (E2E) de todos os botões/fluxos da plataforma.
// Cada botão é exercitado pela mesma requisição que o navegador faz ao clicar,
// e cada página é conferida pelo HTML renderizado.
//
// Pré-requisitos: projeto rodando (run.bat) com PAYMENT_PROVIDER="mock" e o seed aplicado.
// Uso: npm run test:e2e            (testa http://localhost:3000)
//      node tests/e2e.mjs http://192.168.0.10:3000

import { readFileSync } from "node:fs";

const ORIGIN = process.argv[2] ?? "http://localhost:3000";
const SERVER_LOG = process.argv[3];
const results = [];
let section = "";

function check(name, ok, detail = "") {
  results.push({ section, name, ok: Boolean(ok), detail });
  console.log(`${ok ? "  OK  " : "  FALHA"} ${name}${!ok && detail ? `  -> ${String(detail).slice(0, 300)}` : ""}`);
}
function title(t) {
  section = t;
  console.log(`\n=== ${t}`);
}

class Client {
  constructor(name) {
    this.name = name;
    this.jar = new Map();
  }
  cookie() {
    return [...this.jar].map(([k, v]) => `${k}=${v}`).join("; ");
  }
  async raw(path, init = {}) {
    const res = await fetch(ORIGIN + path, { ...init, redirect: "manual", headers: { ...(init.headers ?? {}), cookie: this.cookie() } });
    for (const c of res.headers.getSetCookie()) {
      const [pair] = c.split(";");
      const i = pair.indexOf("=");
      const value = pair.slice(i + 1);
      if (/max-age=0|expires=thu, 01 jan 1970/i.test(c) || value === "") this.jar.delete(pair.slice(0, i));
      else this.jar.set(pair.slice(0, i), value);
    }
    return res;
  }
  async page(path) {
    const res = await this.raw(path);
    return { status: res.status, location: res.headers.get("location"), html: await res.text() };
  }
  async api(path, method = "GET", body) {
    const isForm = body instanceof FormData;
    const res = await this.raw(path, {
      method,
      headers: body && !isForm ? { "Content-Type": "application/json" } : {},
      body: body === undefined ? undefined : isForm ? body : JSON.stringify(body),
    });
    const json = await res.json().catch(() => ({}));
    return { status: res.status, data: json.data, error: json.error };
  }
  /** Mesmo fluxo do signIn("credentials", { redirect: false }) do next-auth/react */
  async login(email, password) {
    await this.raw("/api/auth/providers");
    const { csrfToken } = await (await this.raw("/api/auth/csrf")).json();
    const res = await this.raw("/api/auth/callback/credentials?", {
      method: "post",
      headers: { "Content-Type": "application/x-www-form-urlencoded", "X-Auth-Return-Redirect": "1" },
      body: new URLSearchParams({ email, password, csrfToken, callbackUrl: `${ORIGIN}/login` }),
    });
    const data = await res.json();
    return new URL(data.url).searchParams.get("error");
  }
  async logout() {
    const { csrfToken } = await (await this.raw("/api/auth/csrf")).json();
    const res = await this.raw("/api/auth/signout", {
      method: "post",
      headers: { "Content-Type": "application/x-www-form-urlencoded", "X-Auth-Return-Redirect": "1" },
      body: new URLSearchParams({ csrfToken, callbackUrl: ORIGIN }),
    });
    return res.status;
  }
  async session() {
    return (await (await this.raw("/api/auth/session")).json())?.user ?? null;
  }
}

const has = (html, ...texts) => texts.every((t) => html.includes(t));
const missing = (html, ...texts) => texts.filter((t) => !html.includes(t)).join(", ");
const uniq = Date.now();
// PNG 1x1 válido
const PNG = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==", "base64");

async function stockOf(id) {
  return (await new Client("x").api(`/api/products/${id}`)).data?.stock;
}

// ======================================================================
title("Visitante: páginas públicas e navegação");
const guest = new Client("visitante");
{
  const home = await guest.page("/");
  check("Home abre (200)", home.status === 200, home.status);
  check("Home: marca JM VARIEDADES", has(home.html, ">JM<", ">VARIEDADES<", "JM VARIEDADES"), missing(home.html, ">JM<", ">VARIEDADES<", "JM VARIEDADES"));
  check("Home: botões Ver produtos / Ver departamentos / Entre / Crie a sua conta", has(home.html, "Ver produtos", "Ver departamentos", "Entre", "Crie a sua conta"), missing(home.html, "Ver produtos", "Ver departamentos", "Entre", "Crie a sua conta"));
  check("Home: sem convite para vendedores (loja única)", !/Quero vender|Para lojistas|vendedor/i.test(home.html));
  check("Âncora Ver departamentos existe na página", home.html.includes('id="departamentos"'));
  const catLink = home.html.match(/href="(\/products\?category=[a-z-]+)"/)?.[1];
  check("Home: atalhos de departamento presentes", catLink, "nenhum link de categoria");
  const cat = await guest.page(catLink.replace(/&amp;/g, "&"));
  check("Clique em departamento abre catálogo filtrado", cat.status === 200 && cat.html.includes("resultado(s)"), cat.status);
  const productLink = home.html.match(/href="(\/products\/[a-z0-9-]+)"/)?.[1];
  check("Home: cards de produto com link", productLink);

  const search = await guest.page("/products?q=mouse");
  check("Busca do cabeçalho (q=mouse) encontra produto", search.status === 200 && search.html.includes("Mouse Sem Fio"), search.status);
  const empty = await guest.page("/products?q=zzzznaoexiste");
  check("Busca sem resultado mostra estado vazio", empty.html.includes("Nenhum produto encontrado"));
  const filtered = await guest.page("/products?minPrice=100&maxPrice=300&sort=price_asc");
  check("Filtro de preço + ordenação (botão Aplicar)", filtered.status === 200 && has(filtered.html, "Aplicar", "Limpar"), filtered.status);
  const apiFiltered = await guest.api("/api/products?minPrice=100&maxPrice=300&sort=price_asc&pageSize=48");
  const prices = apiFiltered.data.items.map((i) => i.price);
  check("Filtro de preço respeita faixa e ordem", prices.every((p) => p >= 100 && p <= 300) && prices.every((p, i) => i === 0 || p >= prices[i - 1]), prices.join(","));
  const page2 = await guest.page("/products?page=2");
  check("Paginação: página 2 abre", page2.status === 200 && page2.html.includes('aria-current="page"'), page2.status);
  const apiPage2 = await guest.api("/api/products?page=2");
  check("Paginação: página 2 tem itens diferentes da 1", apiPage2.data.items.length > 0 && apiPage2.data.page === 2);
  const legacy = await guest.api("/api/products?q=Smartphone");
  check("Produtos da versão marketplace saíram do catálogo", legacy.data.total === 0, legacy.data.total);

  const prod = await guest.page(productLink);
  check("Página do produto abre", prod.status === 200, prod.status);
  check("Produto: Comprar agora / Adicionar ao carrinho / Calcular frete", has(prod.html, "Comprar agora", "Adicionar ao carrinho", "Calcular frete"), missing(prod.html, "Comprar agora", "Adicionar ao carrinho", "Calcular frete"));
  check("Produto: vendido e entregue pela JM VARIEDADES", prod.html.includes("Vendido e entregue por <!-- -->JM VARIEDADES") || prod.html.includes("Vendido e entregue por JM VARIEDADES"));
  check("404 de produto inexistente", (await guest.page("/products/nao-existe-xyz")).status === 404);
  check("Página 404 tem botão Voltar ao início", (await guest.page("/rota-inexistente")).html.includes("Voltar ao início"));

  for (const p of ["/login", "/register", "/forgot-password", "/reset-password"]) {
    const r = await guest.page(p);
    check(`Página ${p} abre`, r.status === 200, r.status);
  }
  const reg = await guest.page("/register");
  check("Cadastro sem opção Quero vender (só clientes)", !reg.html.includes("Quero vender") && !reg.html.includes("Nome da loja"));
  check("Login: botões Entrar / Esqueci minha senha / Cadastre-se", has((await guest.page("/login")).html, "Entrar", "Esqueci minha senha", "Cadastre-se"));
  check("Reset sem token mostra link inválido", (await guest.page("/reset-password")).html.includes("Link inválido"));
  check("Área antiga /seller não existe mais", (await guest.page("/seller")).status === 404);
  check("API antiga /api/seller não existe mais", (await guest.api("/api/seller/products")).status === 404);
}

title("Visitante: ações que exigem login");
{
  const anyProduct = (await guest.api("/api/products?q=fone")).data.items[0];
  const quote = await guest.api("/api/shipping/quote", "POST", { destinationCep: "20040-020", productId: anyProduct.id, quantity: 1 });
  check("Calcular frete na página do produto (sem login)", quote.status === 200 && quote.data.length >= 1 && quote.data[0].price > 0, JSON.stringify(quote.error));
  const badCep = await guest.api("/api/shipping/quote", "POST", { destinationCep: "123", productId: anyProduct.id });
  check("Frete com CEP inválido mostra erro", badCep.status === 422, badCep.status);
  check("Adicionar ao carrinho sem login → 401 (tela leva ao login)", (await guest.api("/api/cart", "POST", { productId: anyProduct.id })).status === 401);
  for (const p of ["/cart", "/checkout", "/orders", "/account/addresses", "/admin"]) {
    const r = await guest.page(p);
    check(`${p} sem login redireciona para /login`, r.status >= 300 && r.status < 400 && r.location?.includes("/login"), `${r.status} ${r.location}`);
  }
}

// ======================================================================
title("Cadastro, login, recuperação de senha");
const buyerEmail = `comprador${uniq}@teste.dev`;
const sneakyEmail = `esperto${uniq}@teste.dev`;
const buyer = new Client("comprador");
{
  const weak = await guest.api("/api/auth/register", "POST", { name: "Fulano", email: buyerEmail, password: "abc" });
  check("Criar conta com senha fraca mostra erro", weak.status === 422 && weak.error?.fields?.password, JSON.stringify(weak.error));
  const reg = await guest.api("/api/auth/register", "POST", { name: "Fulano Teste", email: buyerEmail, password: "Teste123" });
  check("Criar conta (cliente)", reg.status === 201 && reg.data.role === "BUYER", JSON.stringify(reg.error ?? reg.data));
  const dup = await guest.api("/api/auth/register", "POST", { name: "Fulano Teste", email: buyerEmail, password: "Teste123" });
  check("E-mail duplicado é recusado", dup.status === 409, dup.status);
  const sneaky = await guest.api("/api/auth/register", "POST", { name: "Esperto", email: sneakyEmail, password: "Teste123", role: "ADMIN" });
  check("Cadastro público nunca cria conta da equipe (role ignorado)", sneaky.status === 201 && sneaky.data.role === "BUYER", JSON.stringify(sneaky.data));

  check("Entrar com senha errada → erro de credenciais", (await buyer.login(buyerEmail, "Errada123")) === "CredentialsSignin");
  check("Entrar com senha certa", (await buyer.login(buyerEmail, "Teste123")) === null && (await buyer.session())?.email === buyerEmail);
  const menu = await buyer.page("/");
  check("Cabeçalho logado mostra menu do usuário e carrinho", menu.html.includes("Fulano") && menu.html.includes('aria-label="Carrinho"'));
  check("Sair (logout)", (await buyer.logout()) === 200 && (await buyer.session()) === null);

  const forgot = await guest.api("/api/auth/forgot-password", "POST", { email: buyerEmail });
  check("Esqueci minha senha → Enviar link", forgot.status === 200, JSON.stringify(forgot.error));
  const unknown = await guest.api("/api/auth/forgot-password", "POST", { email: "ninguem@teste.dev" });
  check("Recuperação para e-mail inexistente responde igual (não revela)", unknown.status === 200);
  let token = forgot.data?.devResetLink?.match(/token=([a-f0-9]+)/)?.[1];
  if (!token && SERVER_LOG) {
    const log = readFileSync(SERVER_LOG, "utf8");
    const matches = [...log.matchAll(/reset-password\?token=([a-f0-9]{64})/g)];
    token = matches.at(-1)?.[1];
  }
  check("Link de redefinição gerado", token);
  check("Página do link de redefinição abre", (await guest.page(`/reset-password?token=${token}`)).html.includes("Salvar nova senha"));
  const reset = await guest.api("/api/auth/reset-password", "POST", { token, password: "NovaSenha1" });
  check("Salvar nova senha", reset.status === 200, JSON.stringify(reset.error));
  check("Link de redefinição não pode ser reutilizado", (await guest.api("/api/auth/reset-password", "POST", { token, password: "Outra1234" })).status === 422);
  check("Senha antiga não entra mais", (await buyer.login(buyerEmail, "Teste123")) === "CredentialsSignin");
  check("Nova senha entra", (await buyer.login(buyerEmail, "NovaSenha1")) === null);
}

// ======================================================================
title("Cliente: endereços");
let addressId;
{
  const pageAddr = await buyer.page("/account/addresses");
  check("Página Meus endereços abre", pageAddr.status === 200 && pageAddr.html.includes("Salvar endereço"), pageAddr.status);
  const invalid = await buyer.api("/api/addresses", "POST", { recipient: "Fulano", cep: "1234", street: "Rua", number: "1", district: "Centro", city: "Rio", state: "RJ" });
  check("Salvar endereço com CEP inválido mostra erro", invalid.status === 422 && invalid.error?.fields?.cep);
  const created = await buyer.api("/api/addresses", "POST", { label: "Casa", recipient: "Fulano Teste", cep: "20040-020", street: "Avenida Rio Branco", number: "100", complement: "", district: "Centro", city: "Rio de Janeiro", state: "rj" });
  check("Salvar endereço", created.status === 201 && created.data.isDefault === true, JSON.stringify(created.error));
  addressId = created.data?.id;
  const second = await buyer.api("/api/addresses", "POST", { label: "Trabalho", recipient: "Fulano", cep: "01310-100", street: "Av Paulista", number: "1000", district: "Bela Vista", city: "São Paulo", state: "SP" });
  check("Adicionar segundo endereço", second.status === 201 && second.data.isDefault === false);
  check("Excluir endereço", (await buyer.api(`/api/addresses/${second.data.id}`, "DELETE")).status === 200);
  check("Lista de endereços atualizada", (await buyer.api("/api/addresses")).data.length === 1);
}

// ======================================================================
title("Cliente: carrinho");
const fone = (await guest.api("/api/products?q=fone")).data.items[0];
const airFryer = (await guest.api("/api/products?q=air%20fryer")).data.items[0];
const soldOut = (await guest.api("/api/products?q=skincare")).data.items[0];
{
  check("Produto esgotado de exemplo existe (Kit Skincare)", soldOut?.stock === 0, JSON.stringify(soldOut));
  const emptyCart = await buyer.page("/cart");
  check("Carrinho vazio mostra botão Ver produtos", emptyCart.html.includes("Seu carrinho está vazio") && emptyCart.html.includes("Ver produtos"));
  const prodPage = await buyer.page(`/products/${fone.slug}`);
  check("Produto (logado) abre com CEP do endereço padrão p/ frete automático", prodPage.status === 200);
  const add = await buyer.api("/api/cart", "POST", { productId: fone.id, quantity: 2 });
  check("Adicionar ao carrinho (qtd 2)", add.status === 201 && add.data.itemCount === 2, JSON.stringify(add.error));
  const buyNow = await buyer.api("/api/cart", "POST", { productId: airFryer.id, quantity: 1 });
  check("Comprar agora (outro produto)", buyNow.status === 201 && buyNow.data.items.length === 2);
  check("Sem estoque não entra no carrinho", (await buyer.api("/api/cart", "POST", { productId: soldOut.id })).status === 409);
  check("Acima do estoque não entra no carrinho", (await buyer.api("/api/cart", "POST", { productId: fone.id, quantity: 99 })).status === 409);
  const cartPage = await buyer.page("/cart");
  check("Página do carrinho: itens, Excluir, Calcular, Continuar a compra", has(cartPage.html, fone.title, "Excluir", "Calcular", "Continuar a compra"), missing(cartPage.html, fone.title, "Excluir", "Calcular", "Continuar a compra"));
  check("Carrinho sem 'Vendido por' (loja única)", !cartPage.html.includes("Vendido por"));
  check("Header mostra quantidade no carrinho", cartPage.html.includes(">3<"));
  const plus = await buyer.api(`/api/cart/items/${fone.id}`, "PATCH", { quantity: 3 });
  check("Botão + aumenta quantidade", plus.status === 200 && plus.data.items.find((i) => i.productId === fone.id).quantity === 3);
  const minus = await buyer.api(`/api/cart/items/${fone.id}`, "PATCH", { quantity: 1 });
  check("Botão − diminui quantidade e recalcula subtotal", minus.status === 200 && minus.data.subtotal === Math.round((fone.price + airFryer.price) * 100) / 100, minus.data?.subtotal);
  const est = await buyer.api("/api/shipping/quote", "POST", { destinationCep: "20040020" });
  check("Calcular frete do carrinho (um volume, saindo do CEP da loja)", est.status === 200 && est.data.length >= 1 && /^\d{8}$/.test(est.data[0].originCep) && est.data[0].weightGrams > 0, JSON.stringify(est.error ?? est.data?.[0]));
  const del = await buyer.api(`/api/cart/items/${airFryer.id}`, "DELETE");
  check("Excluir item do carrinho", del.status === 200 && del.data.items.length === 1);
  const clear = await buyer.api("/api/cart", "DELETE");
  check("Esvaziar carrinho (API)", clear.status === 200 && clear.data.items.length === 0);
  check("Checkout com carrinho vazio volta ao carrinho", (await buyer.page("/checkout")).status >= 300);
}

// ======================================================================
title("Cliente: checkout + pagamento (aprovado, recusado, pendente)");
async function placeOrder(items) {
  for (const [id, q] of items) await buyer.api("/api/cart", "POST", { productId: id, quantity: q });
  const checkoutPage = await buyer.page("/checkout");
  const quote = await buyer.api("/api/shipping/quote", "POST", { destinationCep: "20040020" });
  const res = await buyer.api("/api/checkout", "POST", { addressId, serviceCode: quote.data[0].serviceCode });
  return { checkoutPage, quote, res };
}
let approvedOrderId;
{
  const stockBefore = await stockOf(fone.id);
  const { checkoutPage, quote, res } = await placeOrder([[fone.id, 2], [airFryer.id, 1]]);
  check("Página de checkout: endereço, frete, Novo endereço, Pagar", has(checkoutPage.html, "Endereço de entrega", "Frete (Correios)", "Novo endereço", "Pagar com Mercado Pago"), missing(checkoutPage.html, "Endereço de entrega", "Frete (Correios)", "Novo endereço", "Pagar com Mercado Pago"));
  check("Frete inválido é recusado", (await buyer.api("/api/checkout", "POST", { addressId, serviceCode: "99999" })).status === 422);
  check("Botão Pagar cria pedido e leva ao pagamento", res.status === 201 && res.data.paymentUrl.includes("/checkout/mock"), JSON.stringify(res.error));
  approvedOrderId = res.data?.orderId;
  const created = await buyer.api(`/api/orders/${approvedOrderId}`);
  check("Pedido tem um único envio da loja, com o frete cotado", created.data?.shipments?.length === 1 && Number(created.data.shipments[0].price) === quote.data[0].price && Number(created.data.shippingTotal) === quote.data[0].price, JSON.stringify(created.data?.shipments));
  check("Carrinho é esvaziado após gerar o pagamento", (await buyer.api("/api/cart")).data.items.length === 0);
  const mockPage = await buyer.page(new URL(res.data.paymentUrl).pathname + new URL(res.data.paymentUrl).search);
  check("Tela de pagamento: Aprovar / Processamento / Recusar", has(mockPage.html, "Aprovar pagamento", "Deixar em processamento", "Recusar pagamento"), missing(mockPage.html, "Aprovar pagamento", "Deixar em processamento", "Recusar pagamento"));
  const pay = await buyer.api("/api/payments/mock", "POST", { orderId: approvedOrderId, outcome: "approved" });
  check("Aprovar pagamento", pay.status === 200 && pay.data.orderStatus === "APPROVED", JSON.stringify(pay.error ?? pay.data));
  check("Tela de resultado: Pagamento aprovado + Ver pedido", has((await buyer.page(`/checkout/result?order=${approvedOrderId}`)).html, "Pagamento aprovado", "Ver pedido"));
  check("Estoque baixado após aprovação", (await stockOf(fone.id)) === stockBefore - 2, `${stockBefore} -> ${await stockOf(fone.id)}`);
  check("Pagar de novo pedido já aprovado é recusado", (await buyer.api("/api/payments/mock", "POST", { orderId: approvedOrderId, outcome: "approved" })).status === 422);
}
let rejectedOrderId;
{
  const stockBefore = await stockOf(fone.id);
  const { res } = await placeOrder([[fone.id, 1]]);
  rejectedOrderId = res.data.orderId;
  const pay = await buyer.api("/api/payments/mock", "POST", { orderId: rejectedOrderId, outcome: "rejected" });
  check("Recusar pagamento → pedido cancelado automaticamente", pay.data?.orderStatus === "CANCELLED", JSON.stringify(pay));
  check("Tela de resultado: não aprovado + Voltar ao carrinho", has((await buyer.page(`/checkout/result?order=${rejectedOrderId}`)).html, "Pagamento não aprovado", "Voltar ao carrinho"));
  check("Estoque intacto após recusa", (await stockOf(fone.id)) === stockBefore);
}
let pendingOrderId;
{
  const { res } = await placeOrder([[fone.id, 1]]);
  pendingOrderId = res.data.orderId;
  const pay = await buyer.api("/api/payments/mock", "POST", { orderId: pendingOrderId, outcome: "pending" });
  check("Deixar em processamento → pedido pendente", pay.data?.orderStatus === "PENDING", JSON.stringify(pay));
  const result = await buyer.page(`/checkout/result?order=${pendingOrderId}`);
  check("Tela de resultado: em processamento + Tentar pagar novamente", has(result.html, "Pagamento em processamento", "Tentar pagar novamente", "Acompanhar pedido"));
  const detail = await buyer.page(`/orders/${pendingOrderId}`);
  check("Detalhe do pedido pendente tem botão Pagar agora", detail.html.includes("Pagar agora"));
  const other = new Client("outro cliente");
  await other.login("comprador@marketplace.dev", "Senha123");
  check("Pagamento simulado só do próprio pedido", (await other.api("/api/payments/mock", "POST", { orderId: pendingOrderId, outcome: "approved" })).status === 403);
  check("Cliente não abre pedido de outro cliente", (await other.api(`/api/orders/${pendingOrderId}`)).status === 403);
  const retry = await buyer.api("/api/payments/mock", "POST", { orderId: pendingOrderId, outcome: "approved" });
  check("Pagar agora (nova tentativa) aprova o pedido", retry.data?.orderStatus === "APPROVED", JSON.stringify(retry));
}
{
  const list = await buyer.page("/orders");
  check("Minhas compras lista os pedidos com Ver detalhes", list.status === 200 && list.html.includes("Ver detalhes") && list.html.includes(approvedOrderId.slice(-8).toUpperCase()));
  const apiList = await buyer.api("/api/orders");
  check("API de pedidos do cliente", apiList.status === 200 && apiList.data.length === 3, apiList.data?.length);
  const detail = await buyer.page(`/orders/${approvedOrderId}`);
  check("Detalhe: itens, frete, pagamento, histórico", has(detail.html, "Aprovado", "Envios (Correios)", "Pagamentos (Mercado Pago)", "Histórico do pedido"), missing(detail.html, "Aprovado", "Envios (Correios)", "Pagamentos (Mercado Pago)", "Histórico do pedido"));
  check("Detalhe sem coluna Vendedor", !detail.html.includes("Vendedor"));
  const apiDetail = await buyer.api(`/api/orders/${approvedOrderId}`);
  check("Detalhe tem código do pagamento e valor do frete", apiDetail.data?.payments?.[0]?.externalId && Number(apiDetail.data.shippingTotal) > 0);
  check("Cliente não vê o painel da loja", (await buyer.page("/admin")).location?.includes("denied"));
  check("Cliente não usa APIs do painel", (await buyer.api("/api/admin/orders")).status === 403);
}

// ======================================================================
title("Equipe da loja: painel");
const admin = new Client("equipe");
let newProductId;
{
  check("Login da equipe (admin)", (await admin.login("admin@marketplace.dev", "Senha123")) === null);
  const pages = {
    "/admin": ["Painel da loja", "Total vendido", "A despachar", "Clientes", "Vendas aprovadas por dia", "Mais vendidos", "Estoque baixo", "Pedidos recentes"],
    "/admin/orders": ["Pedidos", "Todos", "Aprovado", "Estornar"],
    "/admin/orders?status=APPROVED": ["Rastreio", "Enviar"],
    "/admin/products": ["Novo produto", "Pausar", "Editar", "Excluir"],
    "/admin/products?q=mouse": ["Mouse Sem Fio"],
    "/admin/products?q=zzzznaoexiste": ["Nenhum produto encontrado"],
    "/admin/products/new": ["Publicar produto", "Embalagem", "Imagens"],
    "/admin/users": ["Clientes e equipe", "Suspender", "Adicionar à equipe", "Você"],
    "/admin/users?role=ADMIN": ["Equipe"],
  };
  for (const [p, texts] of Object.entries(pages)) {
    const r = await admin.page(p);
    check(`Página ${p} abre com seus botões`, r.status === 200 && has(r.html, ...texts), `${r.status} faltando: ${missing(r.html, ...texts)}`);
  }
  check("Painel sem menções a vendedores", !/vendedor|Vendedor|Bloquear/.test((await admin.page("/admin/products")).html));

  const form = new FormData();
  form.append("files", new Blob([PNG], { type: "image/png" }), "foto.png");
  const up = await admin.api("/api/uploads", "POST", form);
  check("Upload de imagem do produto", up.status === 201 && up.data.urls[0].startsWith("/uploads/products/"), JSON.stringify(up.error ?? up.data));
  const imgUrl = up.data?.urls?.[0];
  const img = await admin.raw(imgUrl);
  check("Imagem enviada é servida", img.status === 200 && img.headers.get("content-type") === "image/png", img.status);
  const optimized = await admin.raw(`/_next/image?url=${encodeURIComponent(imgUrl)}&w=256&q=75`);
  check("Imagem enviada aparece via next/image", optimized.status === 200, optimized.status);
  const fakeForm = new FormData();
  fakeForm.append("files", new Blob(["nao sou imagem"], { type: "image/png" }), "falso.png");
  check("Upload de arquivo falso é recusado", (await admin.api("/api/uploads", "POST", fakeForm)).status === 422);
  check("Cliente não faz upload", (await buyer.api("/api/uploads", "POST", form)).status === 403);

  const cats = (await guest.api("/api/categories")).data;
  const invalidProduct = await admin.api("/api/products", "POST", { title: "X", description: "curta", price: 0, stock: -1, categoryId: cats[0].id, images: [], weightGrams: 100, lengthCm: 10, widthCm: 10, heightCm: 5 });
  check("Publicar produto inválido mostra erros", invalidProduct.status === 422);
  const created = await admin.api("/api/products", "POST", {
    title: `Carregador Turbo ${uniq}`, description: "Carregador rápido USB-C com cabo.", price: 79.9, stock: 10, categoryId: cats[0].id,
    images: [imgUrl], status: "ACTIVE", weightGrams: 150, lengthCm: 10, widthCm: 8, heightCm: 5,
  });
  check("Publicar produto", created.status === 201, JSON.stringify(created.error));
  newProductId = created.data?.id;
  check("Produto novo aparece no catálogo", (await guest.api(`/api/products?q=${uniq}`)).data.total === 1);
  check("Produto novo aparece na lista do painel", (await admin.page("/admin/products")).html.includes(`Carregador Turbo ${uniq}`));
  const edit = await admin.page(`/admin/products/${newProductId}/edit`);
  check("Botão Editar abre o formulário preenchido", edit.status === 200 && edit.html.includes("Salvar alterações") && edit.html.includes(`Carregador Turbo ${uniq}`), edit.status);
  check("Editar produto inexistente → 404", (await admin.page("/admin/products/naoexiste/edit")).status === 404);
  const upd = await admin.api(`/api/products/${newProductId}`, "PATCH", { price: 69.9, stock: 4, status: "INACTIVE" });
  check("Salvar alterações (preço, estoque, pausar)", upd.status === 200 && (await guest.api(`/api/products?q=${uniq}`)).data.total === 0, JSON.stringify(upd.error));
  const reactivate = await admin.api(`/api/admin/products/${newProductId}`, "PATCH", { status: "ACTIVE" });
  check("Botão Reativar (lista) volta ao catálogo", reactivate.status === 200 && (await guest.api(`/api/products?q=${uniq}`)).data.items[0]?.price === 69.9);
  check("Status inválido (BLOCKED) é recusado", (await admin.api(`/api/admin/products/${newProductId}`, "PATCH", { status: "BLOCKED" })).status === 422);
  await buyer.api("/api/cart", "POST", { productId: newProductId, quantity: 1 });
  const pause = await admin.api(`/api/admin/products/${newProductId}`, "PATCH", { status: "INACTIVE" });
  check("Botão Pausar (lista) tira do catálogo e dos carrinhos", pause.status === 200 && (await guest.api(`/api/products?q=${uniq}`)).data.total === 0 && (await buyer.api("/api/cart")).data.items.length === 0);
  check("Produto pausado continua na lista do painel", (await admin.api(`/api/admin/products?q=${uniq}`)).data[0]?.status === "INACTIVE");
  await admin.api(`/api/admin/products/${newProductId}`, "PATCH", { status: "ACTIVE" });
  check("Publicar sem login → 401", (await guest.api("/api/products", "POST", {})).status === 401);
  check("Cliente não publica produto", (await buyer.api("/api/products", "POST", {})).status === 403);
  check("Cliente não edita produto", (await buyer.api(`/api/products/${newProductId}`, "PATCH", { price: 1 })).status === 403);

  const orders = await admin.api("/api/admin/orders");
  const approved = orders.data.find((o) => o.id === approvedOrderId);
  check("Pedidos: pedido aprovado com todos os itens e um envio", approved && approved.items.length === 2 && approved.shipments.length === 1, JSON.stringify(approved));
  check("Pedidos: filtro Aprovados", (await admin.api("/api/admin/orders?status=APPROVED")).data.every((o) => o.status === "APPROVED"));
  const ship = approved.shipments[0];
  check("Enviar com rastreio inválido é recusado", (await admin.api(`/api/admin/shipments/${ship.id}`, "PATCH", { status: "SHIPPED", trackingCode: "123" })).status === 422);
  check("Enviar sem rastreio é recusado", (await admin.api(`/api/admin/shipments/${ship.id}`, "PATCH", { status: "SHIPPED" })).status === 422);
  const shipped = await admin.api(`/api/admin/shipments/${ship.id}`, "PATCH", { status: "SHIPPED", trackingCode: "AA123456789BR" });
  check("Botão Enviar (com rastreio)", shipped.status === 200 && shipped.data.status === "SHIPPED", JSON.stringify(shipped.error));
  const delivered = await admin.api(`/api/admin/shipments/${ship.id}`, "PATCH", { status: "DELIVERED" });
  check("Botão Marcar como entregue", delivered.status === 200 && delivered.data.status === "DELIVERED");
  check("Cliente vê rastreio no pedido", (await buyer.page(`/orders/${approvedOrderId}`)).html.includes("AA123456789BR"));
  check("Cliente não altera envio", (await buyer.api(`/api/admin/shipments/${ship.id}`, "PATCH", { status: "DELIVERED" })).status === 403);
  const rejectedShip = (await admin.api(`/api/orders/${rejectedOrderId}`)).data.shipments[0];
  check("Não despacha pedido sem pagamento aprovado", (await admin.api(`/api/admin/shipments/${rejectedShip.id}`, "PATCH", { status: "SHIPPED", trackingCode: "AA123456789BR" })).status === 422);

  const stats = await admin.api("/api/admin/stats");
  check("Visão geral contabiliza vendas, pedidos e clientes", stats.status === 200 && stats.data.totalSold > 0 && stats.data.ordersByStatus.APPROVED >= 2 && stats.data.customersCount >= 2 && stats.data.unitsSold >= 3, JSON.stringify(stats.data));
  check("Estoque baixo lista o produto esgotado", stats.data.lowStock.some((p) => p.id === soldOut.id));

  const users = (await admin.api("/api/admin/users")).data;
  const newBuyer = users.find((u) => u.email === buyerEmail);
  const me = users.find((u) => u.email === "admin@marketplace.dev");
  check("Lista de clientes não tem vendedores", users.every((u) => u.role === "BUYER" || u.role === "ADMIN"));
  check("Filtro Equipe", (await admin.api("/api/admin/users?role=ADMIN")).data.every((u) => u.role === "ADMIN"));
  check("Equipe não altera a própria conta", (await admin.api(`/api/admin/users/${me.id}`, "PATCH", { status: "SUSPENDED" })).status === 422);
  check("Perfil SELLER não existe mais", (await admin.api(`/api/admin/users/${newBuyer.id}`, "PATCH", { role: "SELLER" })).status === 422);

  const suspend = await admin.api(`/api/admin/users/${newBuyer.id}`, "PATCH", { status: "SUSPENDED" });
  check("Botão Suspender", suspend.status === 200 && suspend.data.status === "SUSPENDED");
  check("Usuário suspenso perde acesso imediatamente", (await buyer.api("/api/cart")).status === 401);
  check("Usuário suspenso não consegue entrar", (await new Client("x").login(buyerEmail, "NovaSenha1")) === "CredentialsSignin");
  check("Botão Reativar", (await admin.api(`/api/admin/users/${newBuyer.id}`, "PATCH", { status: "ACTIVE" })).data?.status === "ACTIVE");
  check("Usuário reativado volta a acessar", (await buyer.api("/api/cart")).status === 200);
  check("Botão Adicionar à equipe", (await admin.api(`/api/admin/users/${newBuyer.id}`, "PATCH", { role: "ADMIN" })).data?.role === "ADMIN");
  check("Novo membro acessa o painel (perfil relido do banco)", (await buyer.api("/api/admin/stats")).status === 200);
  check("Botão Remover da equipe", (await admin.api(`/api/admin/users/${newBuyer.id}`, "PATCH", { role: "BUYER" })).data?.role === "BUYER");
  check("Removido perde acesso ao painel", (await buyer.api("/api/admin/stats")).status === 403);

  const stockBefore = await stockOf(fone.id);
  const refund = await admin.api(`/api/admin/orders/${approvedOrderId}/refund`, "POST");
  check("Botão Estornar → pedido reembolsado", refund.status === 200 && refund.data.orderStatus === "REFUNDED", JSON.stringify(refund.error ?? refund.data));
  check("Estorno devolve o estoque", (await stockOf(fone.id)) === stockBefore + 2, `${stockBefore} -> ${await stockOf(fone.id)}`);
  check("Estornar pedido sem pagamento aprovado é recusado", (await admin.api(`/api/admin/orders/${rejectedOrderId}/refund`, "POST")).status === 422);
  check("Filtro de pedidos por status", (await admin.api("/api/admin/orders?status=REFUNDED")).data.some((o) => o.id === approvedOrderId));
  check("Equipe abre qualquer pedido", (await admin.page(`/orders/${approvedOrderId}`)).html.includes("Reembolsado"));

  const del = await admin.api(`/api/products/${newProductId}`, "DELETE");
  check("Botão Excluir produto", del.status === 200 && (await guest.api(`/api/products?q=${uniq}`)).data.total === 0);
  check("Produto excluído some da lista do painel", !(await admin.page("/admin/products")).html.includes(`Carregador Turbo ${uniq}`));
  check("Excluir de novo → 404", (await admin.api(`/api/products/${newProductId}`, "DELETE")).status === 404);
}

// ======================================================================
title("Integrações e rotas de sistema");
{
  check("Webhook Mercado Pago (GET de verificação)", (await guest.api("/api/webhooks/mercadopago")).status === 200);
  const wh = await guest.raw("/api/webhooks/mercadopago?type=merchant_order&data.id=1", { method: "POST", body: "{}" });
  check("Webhook ignora eventos que não são pagamento", wh.status === 200);
  check("Cron sem segredo é bloqueado", (await guest.raw("/api/cron/expire-orders")).status === 401);
  const cats = (await guest.api("/api/categories")).data;
  check("API de departamentos (8, só com produtos)", cats.length === 8, cats.map((c) => c.name).join(", "));
  check("Pagamento simulado exige login", (await guest.api("/api/payments/mock", "POST", { orderId: pendingOrderId, outcome: "approved" })).status === 401);
  check("Logout da equipe", (await admin.logout()) === 200 && (await admin.session()) === null);
}

const failed = results.filter((r) => !r.ok);
console.log(`\n==== RESULTADO: ${results.length - failed.length}/${results.length} verificações passaram`);
if (failed.length) {
  console.log("Falhas:");
  for (const f of failed) console.log(` - [${f.section}] ${f.name}: ${f.detail}`);
}
process.exit(failed.length ? 1 : 0);
