@echo off
setlocal
chcp 65001 >nul
title JM VARIEDADES
cd /d "%~dp0"

rem ==============================================================
rem  JM VARIEDADES - confere o ambiente e roda o projeto no IP da
rem  maquina (acessivel por outros dispositivos da mesma rede).
rem
rem  run.bat          modo desenvolvimento (next dev)
rem  run.bat prod     build de producao + next start
rem  run.bat seed     apenas prepara o banco (migrations + seed)
rem
rem  Opcoes (variaveis de ambiente):
rem    set PORT=3001        usa outra porta (padrao 3000)
rem    set LAN_IP=10.0.0.5  forca um IP especifico
rem    set NO_BROWSER=1     nao abre o navegador
rem
rem  Banco: se o Supabase nao estiver configurado no .env, usa um
rem  PostgreSQL local automaticamente (dados em .local-db).
rem ==============================================================

set "MODE=%~1"
if "%MODE%"=="" set "MODE=dev"
if "%PORT%"=="" set "PORT=3000"

echo.
echo ==============================================
echo   JM VARIEDADES - modo: %MODE%
echo ==============================================
echo.
echo --- Verificando o ambiente ---------------------

rem --- 1. Node.js e npm -------------------------------------------
where node >nul 2>&1
if errorlevel 1 (
  echo [erro] Node.js nao encontrado. Instale a versao 20 ou superior: https://nodejs.org
  goto :fail
)
node scripts\preflight.mjs node
if errorlevel 1 goto :fail

where npm >nul 2>&1
if errorlevel 1 (
  echo [erro] npm nao encontrado. Reinstale o Node.js: https://nodejs.org
  goto :fail
)
for /f "delims=" %%v in ('npm -v') do echo [ok] npm %%v

rem --- 2. Bibliotecas ---------------------------------------------
node scripts\preflight.mjs deps
if errorlevel 1 (
  echo [..] Instalando/atualizando bibliotecas - npm install...
  call npm install
  if errorlevel 1 (
    echo [erro] Falha no npm install. Verifique sua conexao com a internet.
    goto :fail
  )
  node scripts\preflight.mjs stamp
  node scripts\preflight.mjs deps
  if errorlevel 1 goto :fail
)

rem --- 3. Arquivo .env --------------------------------------------
node scripts\ensure-env.mjs
if errorlevel 2 goto :local_db
if errorlevel 1 goto :fail
echo [ok] Usando o banco configurado no .env - Supabase
goto :db_ready

:local_db
rem Supabase ainda nao configurado: sobe um PostgreSQL local (dados em .local-db)
rem As variaveis do processo tem prioridade sobre o .env (Prisma e Next.js)
if "%LOCAL_DB_PORT%"=="" set "LOCAL_DB_PORT=54329"
set "POSTGRES_PRISMA_URL=postgresql://postgres:postgres@localhost:%LOCAL_DB_PORT%/marketplace"
set "POSTGRES_URL_NON_POOLING=postgresql://postgres:postgres@localhost:%LOCAL_DB_PORT%/marketplace"
rem Testa o protocolo do PostgreSQL (nao so a porta): um processo orfao pode
rem segurar a porta sem atender, caso a janela do banco tenha sido fechada a forca
node scripts\preflight.mjs pgready %LOCAL_DB_PORT%
if not errorlevel 1 (
  echo [ok] PostgreSQL local ja estava rodando na porta %LOCAL_DB_PORT%
  goto :db_ready
)
node scripts\preflight.mjs listening %LOCAL_DB_PORT%
if not errorlevel 1 echo [aviso] Banco local travado na porta %LOCAL_DB_PORT% - reiniciando...
node scripts\local-db-cleanup.mjs
echo [..] Iniciando PostgreSQL local - abre uma janela minimizada "JM VARIEDADES - banco local"...
start "JM VARIEDADES - banco local" /min cmd /c "node scripts\local-db.mjs || pause"
node scripts\preflight.mjs waitpg %LOCAL_DB_PORT% 120
if errorlevel 1 (
  echo        Se outro programa estiver usando a porta, rode: set LOCAL_DB_PORT=54330 e depois run.bat
  goto :fail
)
echo [ok] PostgreSQL local rodando na porta %LOCAL_DB_PORT%

:db_ready

rem --- 4. Banco de dados ------------------------------------------
echo [..] Gerando Prisma Client...
call npx prisma generate >nul 2>&1
if errorlevel 1 goto :fail
echo [ok] Prisma Client gerado

echo [..] Aplicando migrations no banco...
call npx prisma migrate deploy >"%TEMP%\marketplace-migrate.log" 2>&1
if errorlevel 1 (
  type "%TEMP%\marketplace-migrate.log"
  echo [erro] Nao foi possivel conectar ao banco. Confira as URLs do Supabase no .env
  echo        ou apague as duas linhas POSTGRES_ do .env para usar o banco local.
  goto :fail
)
echo [ok] Banco conectado e migrations aplicadas

rem O seed e idempotente: so cria o que ainda nao existe
echo [..] Conferindo dados de exemplo - seed...
call npx prisma db seed >"%TEMP%\marketplace-seed.log" 2>&1
if errorlevel 1 (
  type "%TEMP%\marketplace-seed.log"
  goto :fail
)
echo [ok] Dados de exemplo prontos

if /i "%MODE%"=="seed" (
  echo.
  echo [ok] Banco pronto.
  goto :end
)

rem --- 5. Rede: IP da maquina e porta -------------------------------
if "%LAN_IP%"=="" (
  for /f "delims=" %%i in ('node scripts\preflight.mjs ip') do set "LAN_IP=%%i"
)
echo [ok] IP da maquina na rede: %LAN_IP%

node scripts\preflight.mjs port %PORT%
if errorlevel 1 goto :fail

rem Libera a porta no Firewall do Windows (precisa de administrador)
netsh advfirewall firewall show rule name="Marketplace %PORT%" >nul 2>&1
if not errorlevel 1 goto :firewall_ok
net session >nul 2>&1
if errorlevel 1 goto :firewall_noadmin
netsh advfirewall firewall add rule name="Marketplace %PORT%" dir=in action=allow protocol=TCP localport=%PORT% profile=private,domain >nul
echo [ok] Porta %PORT% liberada no firewall - redes privadas e de dominio
goto :firewall_done
:firewall_noadmin
echo [aviso] Sem permissao de administrador para liberar a porta %PORT% no firewall.
echo         Se outros dispositivos nao conseguirem acessar, rode o run.bat uma vez
echo         como administrador: botao direito, Executar como administrador.
goto :firewall_done
:firewall_ok
echo [ok] Porta %PORT% ja liberada no firewall
:firewall_done

rem URL publica usada nos links (Mercado Pago, e-mails, Auth.js) e origem liberada no next dev
set "APP_URL=http://%LAN_IP%:%PORT%"
set "AUTH_URL=http://%LAN_IP%:%PORT%"
set "DEV_ORIGIN_HOST=%LAN_IP%"

rem --- 6. Build de producao (somente modo prod) ---------------------
if /i "%MODE%"=="prod" (
  echo [..] Gerando build de producao...
  call npx next build
  if errorlevel 1 goto :fail
)

rem --- 7. Servidor --------------------------------------------------
echo.
echo ==============================================
echo   Projeto rodando em:
echo     Nesta maquina:   http://localhost:%PORT%
echo     Na rede local:   http://%LAN_IP%:%PORT%
echo.
echo   Usuarios de teste - senha: Senha123
echo     comprador@marketplace.dev   (cliente)
echo     admin@marketplace.dev       (equipe - painel em /admin)
echo.
echo   Para parar: Ctrl+C
echo ==============================================
echo.

rem Abre o navegador alguns segundos depois, quando o servidor ja respondeu
if not "%NO_BROWSER%"=="1" start "" /min cmd /c "timeout /t 10 /nobreak >nul & start http://%LAN_IP%:%PORT%"

rem -H 0.0.0.0 escuta em todas as interfaces (localhost e IP da rede)
if /i "%MODE%"=="prod" (
  call npx next start -H 0.0.0.0 -p %PORT%
) else (
  call npx next dev -H 0.0.0.0 -p %PORT%
)
goto :end

:fail
echo.
echo [falhou] Corrija o problema acima e rode o run.bat novamente.
pause
exit /b 1

:end
endlocal
